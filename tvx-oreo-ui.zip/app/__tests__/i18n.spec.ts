import { expect } from 'chai';
import mock from 'mock-require';

import { formatTranslationMessages } from '../i18n';

const esTranslationMessages = {
  message1: 'mensaje predeterminado',
  message2: '',
};

describe('formatTranslationMessages', () => {
  beforeEach(() => {
    mock('../translations/en.json', {
      message1: 'default message',
      message2: 'default message 2',
    });
  });

  afterEach(() => {
    mock.stop('../translations/en.json');
  });

  it('should build only defaults when DEFAULT_LOCALE', () => {
    const result = formatTranslationMessages('en', { a: 'a' });

    expect(result).to.eql({ a: 'a' });
  });

  it('should combine default locale and current locale when not DEFAULT_LOCALE', () => {
    const translationsMock = mock.reRequire('../i18n');

    const result = translationsMock.formatTranslationMessages(
      '',
      esTranslationMessages,
    );

    expect(result).to.eql({
      message1: 'mensaje predeterminado',
      message2: 'default message 2',
    });
  });
});
