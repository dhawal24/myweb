/**
 * Asynchronously loads the component for PersonalDetaild
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
