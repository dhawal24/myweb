import { createCustomAction } from 'typesafe-actions';

import { SUBMIT_PERSONAL_DETAILS } from './constants';
import { PersonalDetailsType } from './types';

export const submitPersonalDetails = createCustomAction(
  SUBMIT_PERSONAL_DETAILS,
  type => (personalDetails: PersonalDetailsType) => ({
    type,
    personalDetails,
  }),
);
