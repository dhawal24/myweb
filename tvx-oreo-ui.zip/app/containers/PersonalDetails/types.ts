import { FormattedMessage } from 'react-intl';

import { SelectFieldOptionsType } from '../../components/SelectField';

export interface FormField {
  id: keyof PersonalDetailsType;
  message: FormattedMessage.MessageDescriptor;
  component: React.FunctionComponent<any>;
  name?: string;
  type?: string;
  options?: SelectFieldOptionsType[];
  order?: number;
  width?: string;
}

/**
 * redux types
 */

export interface PersonalDetailsType {
  firstName: string;
  lastName: string;
  mobileNumber: string;
  email: string;
  address1: string;
  address2: string;
  city: string;
  county: string;
  postCode: string;
  birthDate: string;
}
