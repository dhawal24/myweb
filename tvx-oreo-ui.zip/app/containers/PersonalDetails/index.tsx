/*
 * PersonalDetailsPage
 *
 */

import React, { useState } from 'react';
import { FormattedMessage } from 'react-intl';
import { connect } from 'react-redux';
import { Box } from '@material-ui/core';

import Container from 'components/Container';
import { useInjectReducer } from 'utils/injectReducer';

import { FlowStepperActions } from '../../components/FlowStepper/types';
import StepperControls from '../../components/StepperControls';

import { PersonalDetailsFields } from './constants';
import { FormField, PersonalDetailsType } from './types';
import { submitPersonalDetails } from './actions';
import personalDetailsReducer from './reducer';
import { selectPersonalDetails } from './selectors';

interface StateProps {
  personalDetails: PersonalDetailsType;
}

interface DispatchProps {
  submitPersonalDetails: (personalDetails: PersonalDetailsType) => void;
}

export interface Props extends StateProps, DispatchProps, FlowStepperActions {}

export const PersonalDetails: React.FC<Props> = (props: Props) => {
  useInjectReducer({
    key: 'personalDetails',
    reducer: personalDetailsReducer,
  });
  const [hasError, setHasError] = useState(fillInitialErrorMap());
  const [personalDetails, setPersonalDetails] = useState<PersonalDetailsType>(
    props.personalDetails,
  );

  const onFieldChange = (
    event: React.ChangeEvent<
      HTMLInputElement | { name?: string; value: unknown }
    >,
    fieldId: keyof PersonalDetailsType,
  ) => {
    const inputValue = getFieldValue(event);

    if (inputValue !== null) {
      setPersonalDetails({
        ...personalDetails,
        [fieldId]: inputValue,
      });
    }

    setHasError((prevState: any) => ({
      ...prevState,
      [fieldId]: inputValue === '',
    }));
  };

  const handleError = (fieldId: keyof PersonalDetailsType) => {
    setHasError((prevState: any) => ({
      ...prevState,
      [fieldId]: !personalDetails[fieldId],
    }));
  };

  const handleSubmit = () => {
    document.body.scrollTop = 0;

    if (areFieldsValid(personalDetails)) {
      props.submitPersonalDetails({
        ...personalDetails,
      });
      props.next();
    } else {
      Object.keys(personalDetails).forEach(fieldId =>
        handleError(fieldId as keyof PersonalDetailsType),
      );
    }
  };

  return (
    <Container p={4} logo height="auto" cardSpacing={4}>
      <Box width={450} m="auto" display="inline-block">
        {PersonalDetailsFields.map((field: FormField) => {
          // eslint-disable-next-line @typescript-eslint/no-unused-vars
          const {
            message,
            component,
            order,
            width,
            ...fieldProperties
          } = field;
          const isInvalid = hasError[field.id];
          return (
            <Box
              width={width || '100%'}
              py={0.5}
              px={1}
              display="inline-block"
              key={field.id}
            >
              <field.component
                error={isInvalid}
                {...fieldProperties}
                label={<FormattedMessage {...message} />}
                onChange={(e: any) => onFieldChange(e, field.id)}
                onBlur={() => handleError(field.id)}
                placeholder={
                  field.id === 'birthDate' ? 'dd/mm/yyyy' : undefined
                }
                value={personalDetails[field.id]}
                required
                fullWidth
              />
            </Box>
          );
        })}
        <StepperControls onClickNext={handleSubmit} onClickBack={props.back} />
      </Box>
    </Container>
  );
};

/**
 * Returns a map of personal details fields with a boolean value
 */
export const fillInitialErrorMap = () =>
  PersonalDetailsFields.map(field => field.id).reduce(
    (obj, key) => ({ ...obj, [key]: false }),
    {},
  ) as {
    [fieldId: string]: boolean;
  };

/**
 * Return true when all fields of given PersonalDetailsType are valued, false otherwise
 * TODO define validation regex in PersonalDetailsFields and apply it here
 * @param personalDetails - the object to be checked
 */
export const areFieldsValid = (personalDetails: PersonalDetailsType) =>
  Object.values(personalDetails).filter(field => !field).length === 0;

/**
 * Returns field value from given event
 * @param event - a field event
 */
export const getFieldValue = (
  event: React.ChangeEvent<
    HTMLInputElement | { name?: string; value: unknown }
  >,
): string => event.target.value as string;

const mapStateToProps = (state: any) => ({
  personalDetails: selectPersonalDetails(state),
});

const mapDispatchToProps = {
  submitPersonalDetails,
};

const withConnect = connect<StateProps, DispatchProps, FlowStepperActions>(
  mapStateToProps,
  mapDispatchToProps,
);

export default withConnect(PersonalDetails);
