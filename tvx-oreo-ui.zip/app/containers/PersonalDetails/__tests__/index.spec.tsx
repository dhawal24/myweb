import React from 'react';
import { IntlProvider } from 'react-intl';
import { render } from '@testing-library/react';
import { spy } from 'sinon';
import { expect } from 'chai';
import { Provider } from 'react-redux';

import {
  areFieldsValid,
  fillInitialErrorMap,
  getFieldValue,
  PersonalDetails,
} from '../index';
import { PersonalDetailsType } from '../types';
import store from '../../../store';

const mockPersonalDetails: PersonalDetailsType = {
  firstName: 'first',
  lastName: 'last',
  mobileNumber: '123',
  email: 'email@domain.com',
  address1: 'address1',
  address2: 'address2',
  city: 'city',
  county: 'county',
  postCode: 'postCode',
  birthDate: 'birthDate',
};

describe('<PersonalDetails />', () => {
  it('should render and match the snapshot', () => {
    const next = spy();
    const submitPersonalDetails = spy();
    const {
      container: { firstChild },
    } = render(
      <Provider store={store}>
        <IntlProvider locale="en">
          <PersonalDetails
            next={next}
            personalDetails={mockPersonalDetails}
            submitPersonalDetails={submitPersonalDetails}
          />
        </IntlProvider>
      </Provider>,
    );
    expect(firstChild).to.matchSnapshot();
  });
});

describe('PersonalDetails areFieldsValid function', () => {
  it('should return true if all fields are empty', () => {
    const emptyPersonalDetails: PersonalDetailsType = {
      firstName: '',
      lastName: '',
      mobileNumber: '',
      email: '',
      address1: '',
      address2: '',
      city: '',
      county: '',
      postCode: '',
      birthDate: '',
    };
    expect(areFieldsValid(emptyPersonalDetails)).to.eql(false);
  });

  it('should return false if at least one field is empty', () => {
    expect(
      areFieldsValid({
        ...mockPersonalDetails,
        firstName: '',
      }),
    ).to.eql(false);
  });

  it('should return true if all fields have values', () => {
    expect(areFieldsValid(mockPersonalDetails)).to.eql(true);
  });
});

describe('PersonalDetails fillInitialErrorMap function', () => {
  it('should match mock map of personal details with false value', () => {
    const mockPersonalDetailsError = {
      firstName: false,
      lastName: false,
      mobileNumber: false,
      email: false,
      address1: false,
      address2: false,
      city: false,
      county: false,
      postCode: false,
      birthDate: false,
    };
    expect(fillInitialErrorMap()).to.eql(mockPersonalDetailsError);
  });
});

describe('PersonalDetails getFieldValue function', () => {
  it('should match value of the field in given event', () => {
    const value = 'value';
    expect(
      getFieldValue({ target: { value } } as React.ChangeEvent<
        HTMLInputElement | HTMLSelectElement
      >),
    ).to.eql(value);
  });
});
