import { expect } from 'chai';

import * as selectors from '../selectors';
import { initialState } from '../reducer';
import { RootState } from '../../../store';

const mockState: RootState = {
  personalDetails: {
    firstName: 'first',
    lastName: 'last',
    mobileNumber: '123',
    email: 'email@domain.com',
    address1: 'address1',
    address2: 'address2',
    city: 'city',
    county: 'county',
    postCode: 'postCode',
    birthDate: 'birthDate',
  },
};

describe('PersonalDetails selectors', () => {
  it('should match the initial state when given state is invalid', () => {
    expect(selectors.selectPersonalDetails({})).to.eql(initialState);
  });

  it('should match personalDetails state from given root state', () => {
    expect(selectors.selectPersonalDetails(mockState)).to.eql(
      mockState.personalDetails,
    );
  });
});
