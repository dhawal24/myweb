import { expect } from 'chai';

import personalDetailsReducer from '../reducer';
import { submitPersonalDetails } from '../actions';
import { PersonalDetailsType } from '../types';

const mockPersonalDetails: PersonalDetailsType = {
  firstName: 'first',
  lastName: 'last',
  mobileNumber: '123',
  email: 'email@domain.com',
  address1: 'address1',
  address2: 'address2',
  city: 'city',
  county: 'county',
  postCode: 'postCode',
  birthDate: 'birthDate',
};

describe('PersonalDetails reducer', () => {
  it('should return given state for an invalid action', () => {
    expect(personalDetailsReducer(mockPersonalDetails, { type: null })).to.eql(
      mockPersonalDetails,
    );
  });

  it('should match expected action for personal details submit event', () => {
    expect(
      personalDetailsReducer(
        mockPersonalDetails,
        submitPersonalDetails(mockPersonalDetails),
      ),
    ).to.eql({
      ...mockPersonalDetails,
    });
  });
});
