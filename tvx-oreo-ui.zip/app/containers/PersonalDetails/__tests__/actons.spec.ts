import { expect } from 'chai';

import * as actions from '../actions';
import { SUBMIT_PERSONAL_DETAILS } from '../constants';

const mockPersonalDetails = {
  firstName: 'first',
  lastName: 'last',
  mobileNumber: '123',
  email: 'email@domain.com',
  address1: 'address1',
  address2: 'address2',
  city: 'city',
  county: 'county',
  postCode: 'postCode',
  birthDate: 'birthDate',
};

describe('PersonalDetails actions', () => {
  it('should create an action to submit product details', () => {
    const expectedAction = {
      type: SUBMIT_PERSONAL_DETAILS,
      personalDetails: mockPersonalDetails,
    };
    expect(actions.submitPersonalDetails(mockPersonalDetails)).to.eql(
      expectedAction,
    );
  });
});
