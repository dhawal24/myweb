import produce from 'immer';
import { ActionType, createReducer, getType } from 'typesafe-actions';

import { PersonalDetailsType } from './types';
import * as actions from './actions';

export const initialState: PersonalDetailsType = {
  firstName: '',
  lastName: '',
  mobileNumber: '',
  email: '',
  address1: '',
  address2: '',
  city: '',
  county: '',
  postCode: '',
  birthDate: '',
};

export const submitPersonalDetailsHandler = (
  state: PersonalDetailsType,
  action: ActionType<typeof actions.submitPersonalDetails>,
) =>
  produce(state, draft => {
    Object.keys(draft).map(
      // eslint-disable-next-line no-return-assign
      fieldName =>
        (draft[fieldName as keyof PersonalDetailsType] =
          action.personalDetails[fieldName as keyof PersonalDetailsType]),
    );
  });

export default createReducer<any, any>(initialState, {
  [getType(actions.submitPersonalDetails)]: submitPersonalDetailsHandler,
});
