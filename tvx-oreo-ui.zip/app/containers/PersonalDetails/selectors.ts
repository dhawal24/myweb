import { RootState } from '../../store';

import { initialState } from './reducer';
import { PersonalDetailsType } from './types';

export const selectPersonalDetails = (state: RootState): PersonalDetailsType =>
  state.personalDetails || initialState;
