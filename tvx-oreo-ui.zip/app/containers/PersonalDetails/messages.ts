/*
 * PersonalDetailsPage Messages
 *
 * This contains all the text for the PersonalDetailsPage container.
 */
import { defineMessages } from 'react-intl';

const messages = defineMessages({
  header: {
    id: 'app.containers.PersonalDetails.header',
    defaultMessage: 'Enter your personal details',
  },
  firstName: {
    id: 'app.containers.PersonalDetails.firstName',
    defaultMessage: 'First Name',
  },
  lastName: {
    id: 'app.containers.PersonalDetails.lastName',
    defaultMessage: 'Last Name',
  },
  mobileNumber: {
    id: 'app.containers.PersonalDetails.mobileNumber',
    defaultMessage: 'Mobile Number',
  },
  email: {
    id: 'app.containers.PersonalDetails.email',
    defaultMessage: 'Email Address',
  },
  address1: {
    id: 'app.containers.PersonalDetails.address1',
    defaultMessage: 'Address Line 1',
  },
  address2: {
    id: 'app.containers.PersonalDetails.address2',
    defaultMessage: 'Address Line 2',
  },
  city: {
    id: 'app.containers.PersonalDetails.city',
    defaultMessage: 'City',
  },
  county: {
    id: 'app.containers.PersonalDetails.county',
    defaultMessage: 'County',
  },
  postcode: {
    id: 'app.containers.PersonalDetails.postcode',
    defaultMessage: 'Postcode',
  },
  birthDate: {
    id: 'app.containers.PersonalDetails.birthDate',
    defaultMessage: 'Date of birth',
  },
});

export default messages;
