import InputField from 'components/InputField';
import SelectField from 'components/SelectField';

import messages from './messages';
import { FormField } from './types';

const firstName: FormField = {
  id: 'firstName',
  message: messages.firstName,
  name: 'firstName',
  type: 'text',
  component: InputField,
  width: '50%',
};

const lastName: FormField = {
  id: 'lastName',
  message: messages.lastName,
  name: 'lastName',
  type: 'text',
  component: InputField,
  width: '50%',
};

const mobileNumber: FormField = {
  id: 'mobileNumber',
  message: messages.mobileNumber,
  name: 'mobileNumber',
  type: 'text',
  component: InputField,
};

const email: FormField = {
  id: 'email',
  message: messages.email,
  name: 'email',
  type: 'email',
  component: InputField,
};

const address1: FormField = {
  id: 'address1',
  message: messages.address1,
  name: 'address1',
  type: 'text',
  component: InputField,
};

const address2: FormField = {
  id: 'address2',
  message: messages.address2,
  name: 'address2',
  type: 'text',
  component: InputField,
};

const city: FormField = {
  id: 'city',
  message: messages.city,
  name: 'city',
  type: 'text',
  component: InputField,
  width: '50%',
};

const county: FormField = {
  id: 'county',
  message: messages.county,
  name: 'county',
  component: SelectField,
  width: '50%',
  options: [
    { key: 'Bedfordshire' },
    { key: 'Cleveland' },
    { key: 'Dorset' },
    { key: 'Greater London' },
    { key: 'Hampshire' },
    { key: 'Herefordshire' },
    { key: 'Kent' },
    { key: 'Middlesex' },
    { key: 'Northamptonshire' },
    { key: 'Somerset' },
  ],
};

const postcode: FormField = {
  id: 'postCode',
  message: messages.postcode,
  name: 'postCode',
  type: 'text',
  component: InputField,
};

const birthDate: FormField = {
  id: 'birthDate',
  message: messages.birthDate,
  name: 'birthDate',
  type: 'text',
  component: InputField,
};

export const PersonalDetailsFields: FormField[] = [
  { ...firstName, order: 1 },
  { ...lastName, order: 2 },
  { ...mobileNumber, order: 3 },
  { ...email, order: 4 },
  { ...address1, order: 5 },
  { ...address2, order: 6 },
  { ...city, order: 7 },
  { ...county, order: 8 },
  { ...postcode, order: 9 },
  { ...birthDate, order: 10 },
];

/**
 * redux actions
 */

export const SUBMIT_PERSONAL_DETAILS =
  'tvx-oreo-ui/PersonalDetails/SUBMIT_PERSONAL_DETAILS';
