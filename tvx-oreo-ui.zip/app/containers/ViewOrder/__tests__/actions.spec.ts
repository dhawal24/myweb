import { expect } from 'chai';

import HttpError from 'utils/HttpError';

import {
  FETCH_ORDERS_FAILURE,
  FETCH_ORDERS_REQUEST,
  FETCH_ORDERS_SUCCESS,
} from '../constants';
import {
  fetchOrdersFailure,
  fetchOrdersRequest,
  fetchOrdersSuccess,
} from '../actions';

const mockOrder = {
  orderReferenceCode: 'GB-0000000000112',
  partnerResource: 'http://localhost:8080/partner/1',
  externalReference: 'test',
  orderStatusCode: 106,
  domCurrISOCode: 'AUD',
  domCurrTotalOrdAmt: 5,
  orderChannelCode: 1,
  customerResource: 'http://localhost:8080/customer/1',
  orderBasket: [
    {
      domCurrAmt: 458,
      foreignCurrAmt: 25.2,
      foreignCurrISOCode: 'USD',
      productType: 'Prod',
      rateDenom: 'test',
      exchangeRate: 2.2,
      rateType: 1,
      spotRate: 2.1,
    },
  ],
  fulfillment: {
    fulfillmentDate: '2020-01-01T00:00:00.000Z',
    fulfillmentType: 1,
  },
  createdDate: '2019-08-07T08:45:40.345Z',
  orderResource: 'http://localhost:8080/orders/GB-0000000000112',
};

describe('View Order actions test', () => {
  it('should create request action', () => {
    const expectedAction = {
      type: FETCH_ORDERS_REQUEST,
      ordersParam: 'orders',
    };
    expect(fetchOrdersRequest(expectedAction.ordersParam)).to.eql(
      expectedAction,
    );
  });

  it('should create success action and match payload', () => {
    const expectedAction = {
      type: FETCH_ORDERS_SUCCESS,
      orders: [mockOrder],
    };
    expect(fetchOrdersSuccess(expectedAction.orders)).to.eql(expectedAction);
  });

  it('should create error action and match the error', () => {
    const expectedAction = {
      type: FETCH_ORDERS_FAILURE,
      error: new HttpError('1', 'message'),
    };
    expect(fetchOrdersFailure(expectedAction.error)).to.eql(expectedAction);
  });
});
