import { expect } from 'chai';

import HttpError from 'utils/HttpError';

import * as selectors from '../selectors';
import { initialState } from '../reducer';

const mockOrders = [
  {
    orderReferenceCode: 'GB-0000000000112',
    partnerResource: 'http://localhost:8080/partner/1',
    externalReference: 'test',
    orderStatusCode: 106,
    domCurrISOCode: 'AUD',
    domCurrTotalOrdAmt: 5,
    orderChannelCode: 1,
    customerResource: 'http://localhost:8080/customer/1',
    orderBasket: [
      {
        domCurrAmt: 458,
        foreignCurrAmt: 25.2,
        foreignCurrISOCode: 'USD',
        productType: 'Prod',
        rateDenom: 'test',
        exchangeRate: 2.2,
        rateType: 1,
        spotRate: 2.1,
      },
    ],
    fulfillment: {
      fulfillmentDate: '2020-01-01T00:00:00.000Z',
      fulfillmentType: 1,
    },
    createdDate: '2019-08-07T08:45:40.345Z',
    orderResource: 'http://localhost:8080/orders/GB-0000000000112',
  },
];

const mockError = new HttpError('101', 'Unable to find request param');

const mockState = {
  viewOrders: {
    loading: false,
    error: mockError,
    orders: mockOrders,
  },
};

describe('ViewOrders selectors', () => {
  it('should match the initial state when given state is invalid', () => {
    expect(selectors.selectViewOrders({})).to.eql(initialState);
  });

  it('should match array of orders from given mock state', () => {
    expect(selectors.selectOrders(mockState)).to.eql(
      mockState.viewOrders.orders,
    );
  });

  it('should match error from given mock state', () => {
    expect(selectors.selectError(mockState)).to.eql(mockState.viewOrders.error);
  });

  it('should match loading field from given mock state', () => {
    expect(selectors.selectLoading(mockState)).to.eql(
      mockState.viewOrders.loading,
    );
  });
});
