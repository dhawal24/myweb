import { expect } from 'chai';

import HttpError from 'utils/HttpError';

import viewOrdersReducer, { initialState } from '../reducer';
import { ViewOrdersState } from '../types';
import {
  fetchOrdersFailure,
  fetchOrdersRequest,
  fetchOrdersSuccess,
} from '../actions';

const mockOrders = [
  {
    orderReferenceCode: 'GB-0000000000112',
    partnerResource: 'http://localhost:8080/partner/1',
    externalReference: 'test',
    orderStatusCode: 106,
    domCurrISOCode: 'AUD',
    domCurrTotalOrdAmt: 5,
    orderChannelCode: 1,
    customerResource: 'http://localhost:8080/customer/1',
    orderBasket: [
      {
        domCurrAmt: 458,
        foreignCurrAmt: 25.2,
        foreignCurrISOCode: 'USD',
        productType: 'Prod',
        rateDenom: 'test',
        exchangeRate: 2.2,
        rateType: 1,
        spotRate: 2.1,
      },
    ],
    fulfillment: {
      fulfillmentDate: '2020-01-01T00:00:00.000Z',
      fulfillmentType: 1,
    },
    createdDate: '2019-08-07T08:45:40.345Z',
    orderResource: 'http://localhost:8080/orders/GB-0000000000112',
  },
];

const mockError = new HttpError('101', 'Unable to find request param');

const mockState: ViewOrdersState = {
  loading: false,
  error: null,
  orders: null,
};

describe('ViewOrder reducer test', () => {
  it('should return the initial state for invalid action', () => {
    expect(viewOrdersReducer(mockState, { type: null })).to.eql(initialState);
  });

  it('should return the change loading field', () => {
    expect(viewOrdersReducer(mockState, fetchOrdersRequest('1'))).to.eql({
      ...mockState,
      loading: true,
    });
  });

  it('should provide orders', () => {
    expect(viewOrdersReducer(mockState, fetchOrdersSuccess(mockOrders))).to.eql(
      {
        ...mockState,
        orders: mockOrders,
      },
    );
  });

  it('should return initial state for invalid given state', () => {
    expect(viewOrdersReducer(undefined, fetchOrdersRequest('1'))).to.eql({
      ...initialState,
      loading: true,
    });
  });

  it('should set error state field with the provided error', () => {
    expect(viewOrdersReducer(mockState, fetchOrdersFailure(mockError))).to.eql({
      ...mockState,
      error: mockError,
    });
  });
});
