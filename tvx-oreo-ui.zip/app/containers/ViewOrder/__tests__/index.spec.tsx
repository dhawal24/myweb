import React from 'react';
import { render } from '@testing-library/react';
import { expect } from 'chai';
import { Provider } from 'react-redux';
import { IntlProvider } from 'react-intl';

import store from '../../../store';
import ViewOrder from '../index';

describe('<ViewOrder />', () => {
  it('should render and match the snapshot', () => {
    const {
      container: { firstChild },
    } = render(
      <Provider store={store}>
        <IntlProvider locale="en">
          <ViewOrder />
        </IntlProvider>
      </Provider>,
    );
    expect(firstChild).to.matchSnapshot();
  });
});
