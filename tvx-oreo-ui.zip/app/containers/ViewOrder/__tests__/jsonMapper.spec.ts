import { expect } from 'chai';

import mapper from '../utils/jsonMapper';
import { Order } from '../types';
const order: Order = {
  orderReferenceCode: 'GB-0000000000112',
  partnerResource: 'http://localhost:8080/partner/1',
  externalReference: 'test',
  orderStatusCode: 106,
  domCurrISOCode: 'AUD',
  domCurrTotalOrdAmt: 5,
  orderChannelCode: 1,
  customerResource: 'http://localhost:8080/customer/1',
  orderBasket: [
    {
      domCurrAmt: 458,
      foreignCurrAmt: 25.2,
      foreignCurrISOCode: 'USD',
      productType: 'Prod',
      rateDenom: 'test',
      exchangeRate: 2.2,
      rateType: 1,
      spotRate: 2.1,
    },
  ],
  fulfillment: {
    fulfillmentDate: '2020-01-01T00:00:00.000Z',
    fulfillmentType: 1,
  },
  createdDate: '2019-08-07T08:45:40.345Z',
  orderResource: 'http://localhost:8080/orders/GB-0000000000112',
};
const expectedOutput = [
  {
    'GB-0000000000112': {
      orderStatus: 'Scheduled',
      domCurrTotalOrdAmt: 5,
      orderChannel: 'Web',
      basket: [
        {
          label: 'basketId',
          value: 0,
          data: {
            domCurrAmt: 458,
            foreignCurrAmt: 25.2,
            foreignCurrISOCode: 'USD',
            productType: 'Prod',
            rateDenom: 'test',
            exchangeRate: 2.2,
            spotRate: 2.1,
            rateType: 'Indirect',
          },
        },
      ],
      fulfillment: {
        fulfillmentDate: '2020-01-01T00:00:00.000Z',
        fulfillmentType: 'Home Delivery',
      },
    },
  },
];

describe('jsonMapper', () => {
  it('should return the mapped array without any error items', () => {
    const mapperInput = [order];
    const result = mapper(mapperInput);
    expect(result).to.be.an('array');
    expect(result).to.be.eql(expectedOutput);
  });

  it('should successfully map an error item', () => {
    const mapperInput = [
      {
        orderReferenceCode: 'GB-0000000001131',
        Error: {
          code: '103',
          message:
            'Unable to retrieve the Order information for GB-0000000001131',
        },
      },
    ];

    const expected = [
      {
        'GB-0000000001131': {
          error:
            'Unable to retrieve the Order information for GB-0000000001131',
        },
      },
    ];

    const result = mapper(mapperInput);
    expect(result).to.be.an('array');
    expect(result).to.be.eql(expected);
  });
});
