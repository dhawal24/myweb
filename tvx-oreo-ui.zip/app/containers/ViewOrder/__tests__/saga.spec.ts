import { expectSaga, testSaga } from 'redux-saga-test-plan';

import { fetchOrdersRequest } from '../actions';
import viewOrdersSaga, { fetchOrders } from '../saga';
import { FETCH_ORDERS_REQUEST } from '../constants';

describe('ViewOrders saga', () => {
  it('should dispatch request action', () => {
    expectSaga(viewOrdersSaga)
      .dispatch(fetchOrdersRequest('1'))
      .run();
  });

  it('should take view orders saga and provide appropriate action', () => {
    testSaga(viewOrdersSaga)
      .next()
      .takeLatest(FETCH_ORDERS_REQUEST, fetchOrders);
  });
});
