import { ActionType, createReducer, getType } from 'typesafe-actions';
import produce from 'immer';

import { ViewOrdersState } from './types';
import * as actions from './actions';

export const initialState: ViewOrdersState = {
  loading: false,
  error: null,
  orders: null,
};

export const fetchOrdersRequestHandler = (state: ViewOrdersState) =>
  produce(state, draft => {
    draft.loading = true;
  });

export const fetchOrdersSuccessHandler = (
  state: ViewOrdersState,
  action: ActionType<typeof actions.fetchOrdersSuccess>,
) =>
  produce(state, draft => {
    draft.orders = action.orders;
    draft.error = null;
    draft.loading = false;
  });

export const fetchOrdersFailureHandler = (
  state: ViewOrdersState,
  action: ActionType<typeof actions.fetchOrdersFailure>,
) =>
  produce(state, draft => {
    draft.error = action.error;
    draft.loading = false;
  });

export default createReducer<any, any>(initialState, {
  [getType(actions.fetchOrdersRequest)]: fetchOrdersRequestHandler,
  [getType(actions.fetchOrdersSuccess)]: fetchOrdersSuccessHandler,
  [getType(actions.fetchOrdersFailure)]: fetchOrdersFailureHandler,
});
