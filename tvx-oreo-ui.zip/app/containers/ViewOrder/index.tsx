import React from 'react';
import { FormattedMessage } from 'react-intl';
import {
  Box,
  Button,
  Divider,
  IconButton,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Typography,
} from '@material-ui/core';
import { Add, Close } from '@material-ui/icons';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';

import OrderTree from 'components/OrderTree';
import HttpError from 'utils/HttpError';

import Container from '../../components/Container';
import { RootState } from '../../store';
import { useInjectSaga } from '../../utils/injectSaga';
import { SagaInjectorMode } from '../../utils/constants';
import { useInjectReducer } from '../../utils/injectReducer';
import InputField from '../../components/InputField';

import jsonMapper from './utils/jsonMapper';
import { fetchOrdersRequest } from './actions';
import { ViewOrdersState } from './types';
import messages from './messages';
import { selectError, selectLoading, selectOrders } from './selectors';
import viewOrdersSaga from './saga';
import viewOrdersReducer from './reducer';

interface Props extends ViewOrdersState {
  fetchOrdersRequest: (ordersParam: string) => void;
}

export const ViewOrder: React.FC<Props> = props => {
  useInjectSaga({
    key: 'viewOrdersSaga',
    saga: viewOrdersSaga,
    mode: SagaInjectorMode.Daemon,
  });
  useInjectReducer({
    key: 'viewOrders',
    reducer: viewOrdersReducer,
  });

  const [fields, setFields] = React.useState(['']);
  const [showResults, setShowResults] = React.useState(false);
  const [errors, setErrors] = React.useState([false]);

  const onInputChange = (index: number) => (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    setFields([
      ...fields.slice(0, index),
      (fields[index] = event.target.value),
      ...fields.slice(index + 1),
    ]);
    setErrors([
      ...errors.slice(0, index),
      (errors[index] = errors[index] && event.target.value.length === 0),
      ...errors.slice(index + 1),
    ]);
  };

  const onAddMore = () => {
    setFields([...fields, '']);
    setErrors([...errors, false]);
  };
  const onRemoveItem = (index: number) => () => {
    fields.splice(index, 1);
    return setFields([...fields]);
  };

  const handleSubmit = () => {
    const isValid = fields.filter(field => field.length === 0).length === 0;
    setErrors(fields.map(field => field.length === 0));
    if (isValid) {
      props.fetchOrdersRequest(fields.join());
      setShowResults(true);
    } else {
      setShowResults(false);
    }
  };
  return (
    <Container p={2} logo>
      <Box width={550}>
        <Box px={2}>
          <Typography variant="h4">
            <FormattedMessage {...messages.title} />
          </Typography>
        </Box>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>
                <FormattedMessage {...messages.label} />
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {fields.map((item, index) => (
              <TableRow>
                <TableCell padding="none">
                  <Box display="flex" alignItems="center" px={2} py={1}>
                    <InputField
                      fullWidth
                      id={`order${index}`}
                      name="orderReference"
                      value={fields[index]}
                      placeholder={messages.label.defaultMessage}
                      onChange={onInputChange(index)}
                      error={errors && errors[index]}
                    />
                    <Box px={1}>
                      <IconButton
                        disabled={fields.length < 2}
                        onClick={onRemoveItem(index)}
                      >
                        <Close fontSize="small" />
                      </IconButton>
                    </Box>
                  </Box>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        <Box px={2} py={2} display="flex" justifyContent="space-between">
          <Button variant="outlined" startIcon={<Add />} onClick={onAddMore}>
            <FormattedMessage {...messages.addLabel} />
          </Button>
          <Button
            color="primary"
            variant="contained"
            onClick={handleSubmit}
            disabled={props.loading}
          >
            Submit
          </Button>
        </Box>

        {showResults && !props.loading && (
          <Box>
            <Box px={3}>
              <Typography variant="h6" gutterBottom>
                <FormattedMessage {...messages.ordersTitle} />
              </Typography>
            </Box>
            <Divider orientation="horizontal" variant="fullWidth" />
            <Box p={3}>
              {props.orders ? (
                jsonMapper(props.orders).map(item =>
                  Object.keys(item).map(itemContent => (
                    <OrderTree
                      data={item[itemContent]}
                      itemKey={itemContent}
                      key={itemContent}
                      root
                      messages={messages}
                    />
                  )),
                )
              ) : (
                <Typography color="error" variant="h6">
                  {props.error && (props.error as HttpError).message
                    ? (props.error as HttpError).message
                    : `Sorry, there was a technical error in getting the information.`}
                </Typography>
              )}
            </Box>
          </Box>
        )}
      </Box>
    </Container>
  );
};

const mapStateToProps = createStructuredSelector<RootState, ViewOrdersState>({
  orders: selectOrders,
  loading: selectLoading,
  error: selectError,
});

const mapDispatchToProps = {
  fetchOrdersRequest,
};

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default withConnect(ViewOrder);
