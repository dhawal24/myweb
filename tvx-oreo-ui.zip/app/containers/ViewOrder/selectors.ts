import { createSelector } from 'reselect';

import { RootState } from '../../store';

import { initialState } from './reducer';

export const selectViewOrders = (state: RootState) =>
  state.viewOrders || initialState;

export const selectLoading = createSelector(
  selectViewOrders,
  state => state.loading,
);

export const selectError = createSelector(
  selectViewOrders,
  state => state.error,
);

export const selectOrders = createSelector(
  selectViewOrders,
  state => state.orders,
);
