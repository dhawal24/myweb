import { createCustomAction } from 'typesafe-actions';

import HttpError from 'utils/HttpError';

import {
  FETCH_ORDERS_FAILURE,
  FETCH_ORDERS_REQUEST,
  FETCH_ORDERS_SUCCESS,
} from './constants';
import { Order } from './types';

export const fetchOrdersRequest = createCustomAction(
  FETCH_ORDERS_REQUEST,
  type => (ordersParam: string) => ({
    type,
    ordersParam,
  }),
);

export const fetchOrdersSuccess = createCustomAction(
  FETCH_ORDERS_SUCCESS,
  type => (orders: Order[]) => ({
    type,
    orders,
  }),
);

export const fetchOrdersFailure = createCustomAction(
  FETCH_ORDERS_FAILURE,
  type => (error: HttpError) => ({
    type,
    error,
  }),
);
