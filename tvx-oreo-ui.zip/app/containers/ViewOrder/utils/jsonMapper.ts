import {
  Types,
  Order,
  Basket,
  MappedOrder,
  MappedBasket,
  SuccessfulOrder,
  ErrorOrder,
} from '../types';

const FulfillmentTypes: Types = {
  1: 'Home Delivery',
};

const RateTypes: Types = {
  1: 'Indirect',
};
const OrderChannelTypes: Types = {
  1: 'Web',
};

const OrderStatusTypes: Types = {
  106: 'Scheduled',
};

export default (orderData: Order[]) => {
  const result: MappedOrder[] = [];
  orderData.map((item: Order) => {
    const resultItem: MappedOrder = {};

    if ((<ErrorOrder>item).Error) {
      const sourceItem = item as ErrorOrder;

      const { Error, orderReferenceCode } = sourceItem;
      resultItem[orderReferenceCode!] = { error: Error.message };
      result.push(resultItem);
    } else {
      const sourceItem = item as SuccessfulOrder;
      const {
        orderReferenceCode,
        orderStatusCode,
        domCurrTotalOrdAmt,
        orderChannelCode,
        orderBasket,
        fulfillment,
      } = sourceItem;

      const basket: MappedBasket[] = [];

      orderBasket.map((basketItem: Basket, index: number) => {
        const { basketId, rateType, ...otherItems } = basketItem;
        basket[index] = {
          label: 'basketId',
          value: basketId || index,
          data: {
            ...otherItems,
            rateType: RateTypes[rateType],
          },
        };
      });

      resultItem[orderReferenceCode] = {
        orderStatus: OrderStatusTypes[orderStatusCode],
        domCurrTotalOrdAmt,
        orderChannel: OrderChannelTypes[orderChannelCode],
        basket,
        fulfillment: {
          ...fulfillment,
          fulfillmentType: FulfillmentTypes[fulfillment.fulfillmentType],
        },
      };

      result.push(resultItem);
    }
  });
  return result;
};
