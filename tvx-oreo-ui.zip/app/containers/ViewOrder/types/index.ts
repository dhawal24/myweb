import HttpError from 'utils/HttpError';

interface Address {
  address1: string;
  address2: string;
  city: string;
  state: string;
  country: string;
  postalCode: string;
}

interface CustomerInfo {
  firstName: string;
  lastName: string;
  mobileNo: string;
  emailId: string;
  dob: string;
}

export interface Basket {
  basketId?: string;
  domCurrAmt: number;
  foreignCurrAmt: number;
  foreignCurrISOCode: string;
  productType: string;
  rateDenom: string;
  exchangeRate: number;
  rateType: number;
  spotRate: number;
}

interface Fulfillment {
  fulfillmentDate: string;
  fulfillmentType: number;
}

export interface Types {
  [key: number]: string;
}

export type Order = ErrorOrder | SuccessfulOrder;

declare interface ErrorType {
  message: string;
  code: string;
}

export interface ErrorOrder {
  orderReferenceCode?: string;
  Error: ErrorType;
}

export interface SuccessfulOrder {
  orderReferenceCode: string;
  partnerResource: string;
  externalReference: string;
  orderStatusCode: number;
  domCurrTotalOrdAmt: number;
  domCurrISOCode: string;
  orderChannelCode: number;
  orderBasket: Basket[];
  fulfillment: Fulfillment;
  customerResource: string;
  createdDate: string;
  orderResource: string;
}

interface BasketRateType extends Omit<Basket, 'rateType'> {
  rateType: string;
}

export interface MappedBasket {
  label: string;
  value: string | number;
  data: BasketRateType;
}

interface MappedFulfillment extends Omit<Fulfillment, 'fulfillmentType'> {
  fulfillmentType: string;
}

interface MappedOrderError {
  error: string;
}

interface MappedOrderItem {
  partnerName?: string;
  country?: string;
  countryIsoCode?: string;
  orderStatus: string;
  domCurrTotalOrdAmt: number;
  orderChannel: string;
  customerDetails?: CustomerInfo;
  customerAddress?: Address;
  basket: MappedBasket[];
  fulfillment: MappedFulfillment;
}

export interface MappedOrder {
  [key: string]: MappedOrderItem | MappedOrderError;
}

/*
=================== Redux types ===================
*/

export interface ViewOrdersState {
  loading: boolean;
  error?: Error | HttpError | null;
  orders?: Order[] | null;
}
