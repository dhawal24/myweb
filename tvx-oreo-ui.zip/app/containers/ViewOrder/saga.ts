import { put, takeLatest } from 'redux-saga/effects';
import { getType } from 'typesafe-actions';

import HttpError from 'utils/HttpError';

import {
  fetchOrdersFailure,
  fetchOrdersRequest,
  fetchOrdersSuccess,
} from './actions';
import { getOrders } from './api';

export function* fetchOrders(action: any) {
  try {
    const orders = yield getOrders(action.ordersParam);
    yield put(fetchOrdersSuccess(orders));
  } catch (e) {
    yield put(fetchOrdersFailure(new HttpError('500', 'Server error')));
  }
}

export default function* viewOrdersSaga() {
  yield takeLatest(getType(fetchOrdersRequest), fetchOrders);
}
