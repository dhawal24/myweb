import HttpError from 'utils/HttpError';

import env from '../../../env.json';

export const getOrders = async (ordersParam: string) => {
  try {
    const data = await fetch(`${env.API.orders}/${ordersParam}`);
    return await data.json();
  } catch (e) {
    throw new HttpError('500', 'Server error');
  }
};
