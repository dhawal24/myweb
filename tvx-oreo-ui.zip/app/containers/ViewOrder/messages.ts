/*
 * ProductPage Messages
 *
 * This contains all the text for the ProductPage container.
 */
import { defineMessages } from 'react-intl';

const messages = defineMessages({
  title: {
    id: 'app.containers.ViewOrder.title',
    defaultMessage: 'View Order',
  },
  label: {
    id: 'app.containers.ViewOrder.label',
    defaultMessage: 'Order Reference',
  },
  deleteLabel: {
    id: 'app.containers.ViewOrder.deleteLabel',
    defaultMessage: 'Delete',
  },
  addLabel: {
    id: 'app.containers.ViewOrder.addLabel',
    defaultMessage: 'Add More',
  },
  submit: {
    id: 'app.containers.ViewOrder.submit',
    defaultMessage: 'Submit',
  },
  required: {
    id: 'app.containers.ViewOrder.required',
    defaultMessage: 'Please enter a reference number',
  },
  ordersTitle: {
    id: 'app.containers.ViewOrder.ordersTitle',
    defaultMessage: 'Response',
  },
  partnerName: {
    id: 'app.containers.ViewOrder.partnerName',
    defaultMessage: 'Partner Name',
  },
  country: {
    id: 'app.containers.ViewOrder.country',
    defaultMessage: 'Country',
  },
  countryIsoCode: {
    id: 'app.containers.ViewOrder.countryIsoCode',
    defaultMessage: 'Country ISO Code',
  },
  orderStatus: {
    id: 'app.containers.ViewOrder.orderStatus',
    defaultMessage: 'Order Status',
  },
  orderChannel: {
    id: 'app.containers.ViewOrder.orderChannel',
    defaultMessage: 'Order Channel',
  },
  domCurrTotalOrdAmt: {
    id: 'app.containers.ViewOrder.domCurrTotalOrdAmt',
    defaultMessage: 'Order Total Amount',
  },
  customerDetails: {
    id: 'app.containers.ViewOrder.customerDetails',
    defaultMessage: 'Customer Details',
  },
  firstName: {
    id: 'app.containers.ViewOrder.firstName',
    defaultMessage: 'Customer first name',
  },
  lastName: {
    id: 'app.containers.ViewOrder.lastName',
    defaultMessage: 'Customer last name',
  },
  emailId: {
    id: 'app.containers.ViewOrder.emailId',
    defaultMessage: 'Customer Email Address',
  },
  mobileNo: {
    id: 'app.containers.ViewOrder.mobileNo',
    defaultMessage: 'Customer mobile number',
  },
  dob: {
    id: 'app.containers.ViewOrder.dob',
    defaultMessage: 'Date of Birth',
  },
  customerAddress: {
    id: 'app.containers.ViewOrder.customerAddress',
    defaultMessage: 'Customer Address',
  },
  address1: {
    id: 'app.containers.ViewOrder.address1',
    defaultMessage: 'Address Line 1',
  },
  address2: {
    id: 'app.containers.ViewOrder.address2',
    defaultMessage: 'Address Line 2',
  },
  city: {
    id: 'app.containers.ViewOrder.city',
    defaultMessage: 'City',
  },
  state: {
    id: 'app.containers.ViewOrder.state',
    defaultMessage: 'State',
  },
  postalCode: {
    id: 'app.containers.ViewOrder.postalCode',
    defaultMessage: 'Post Code',
  },
  basket: {
    id: 'app.containers.ViewOrder.basket',
    defaultMessage: 'Basket Information',
  },
  basketId: {
    id: 'app.containers.ViewOrder.baskedId',
    defaultMessage: 'Basket ID',
  },
  productType: {
    id: 'app.containers.ViewOrder.productType',
    defaultMessage: 'Product Type',
  },
  foreignCurrISOCode: {
    id: 'app.containers.ViewOrder.foreignCurrISOCode',
    defaultMessage: 'Currency Code',
  },
  rateDenom: {
    id: 'app.containers.ViewOrder.rateDenom',
    defaultMessage: 'Rate Denom',
  },
  foreignCurrAmt: {
    id: 'app.containers.ViewOrder.foreignCurrAmt',
    defaultMessage: 'Foreign Currency Amount',
  },
  domCurrAmt: {
    id: 'app.containers.ViewOrder.domCurrAmt',
    defaultMessage: 'Domestic Currency Amount',
  },
  spotRate: {
    id: 'app.containers.ViewOrder.spotRate',
    defaultMessage: 'Rate',
  },
  exchangeRate: {
    id: 'app.containers.ViewOrder.exchangeRate',
    defaultMessage: 'Exchange Rate',
  },
  rateType: {
    id: 'app.containers.ViewOrder.rateType',
    defaultMessage: 'Rate Type',
  },
  fulfillment: {
    id: 'app.containers.ViewOrder.fulfillment',
    defaultMessage: 'Fulfillment Information',
  },
  fulfillmentType: {
    id: 'app.containers.ViewOrder.fulfillmentType',
    defaultMessage: 'Fulfillment Type',
  },
  fulfillmentDate: {
    id: 'app.containers.ViewOrder.fulfillmentDate',
    defaultMessage: 'Fulfillment Date',
  },
  error: {
    id: 'app.containers.ViewOrder.error',
    defaultMessage: 'Error',
  },
});

export default messages;
