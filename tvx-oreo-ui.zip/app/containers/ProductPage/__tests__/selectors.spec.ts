import { expect } from 'chai';

import * as selectors from '../selectors';
import { initialState } from '../reducer';

const mockState = {
  productDetails: {
    currencyCode: 'EUR',
    amount: 1,
    exchangeRate: 2,
  },
};

describe('Fulfillment selectors', () => {
  it('should match the initial state when given state is empty', () => {
    expect(selectors.selectProductDetails({})).to.eql(initialState);
  });

  it('should match the productDetails state from global state', () => {
    const mockGlobalState = {
      productDetails: mockState,
    };
    expect(selectors.selectProductDetails(mockGlobalState)).to.eql(mockState);
  });

  it('should match currencyCode value from given state', () => {
    expect(selectors.selectCurrencyCode(mockState)).to.eql(
      mockState.productDetails.currencyCode,
    );
  });

  it('should match amount value from given state', () => {
    expect(selectors.selectAmount(mockState)).to.eql(
      mockState.productDetails.amount,
    );
  });

  it('should match exchangeRate value from given state', () => {
    expect(selectors.selectExchangeRate(mockState)).to.eql(
      mockState.productDetails.exchangeRate,
    );
  });
});
