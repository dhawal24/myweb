import { expect } from 'chai';

import * as actions from '../actions';
import { SET_PRODUCT_DETAILS } from '../constants';

describe('ProductPage actions', () => {
  it('should create an action to set product details', () => {
    const mockProductDetails = {
      currencyCode: 'EUR',
      amount: 1,
      exchangeRate: 1,
    };

    const expectedAction = {
      type: SET_PRODUCT_DETAILS,
      ...mockProductDetails,
    };
    expect(
      actions.setProductDetails(
        mockProductDetails.currencyCode,
        mockProductDetails.amount,
        mockProductDetails.exchangeRate,
      ),
    ).to.eql(expectedAction);
  });
});
