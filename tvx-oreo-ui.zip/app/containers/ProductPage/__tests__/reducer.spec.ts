import { expect } from 'chai';

import productReducer, { setProductDetailsHandler } from '../reducer';
import { setProductDetails } from '../actions';

const mockInitialState = {
  currencyCode: '',
  amount: null,
  exchangeRate: null,
};

describe('ProductPage reducer', () => {
  it('should match initial state when action is invalid', () => {
    expect(productReducer(mockInitialState, { type: null })).to.eql(
      mockInitialState,
    );
  });

  it('should match given state for set product details action', () => {
    const mockProductDetails = {
      currencyCode: 'EUR',
      amount: 1,
      exchangeRate: 1,
    };
    expect(
      setProductDetailsHandler(
        mockInitialState,
        setProductDetails(
          mockProductDetails.currencyCode,
          mockProductDetails.amount,
          mockProductDetails.exchangeRate,
        ),
      ),
    ).to.eql(mockProductDetails);
  });
});
