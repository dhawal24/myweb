import React from 'react';
import { render } from '@testing-library/react';
import { expect } from 'chai';
import { Provider } from 'react-redux';
import { IntlProvider } from 'react-intl';
import { spy } from 'sinon';

import { ProductPage, convertAmount, getCurrency } from '../index';
import store from '../../../store';
import { CurrencyType } from '../constants';

describe('<ProductPage />', () => {
  it('should render and match the snapshot', () => {
    const setProductDetails = spy();
    const {
      container: { firstChild },
    } = render(
      <Provider store={store}>
        <IntlProvider locale="en">
          <ProductPage
            next={() => {}}
            currencyCode="EUR"
            amount={1}
            ratesDetails = {{
              partnerRateCode: 'CAD',
              partnerExchangeRate: 1.63633,
            }}
            setProductDetails={setProductDetails}
            exchangeRate={1}
          />
        </IntlProvider>
      </Provider>,
    );
    expect(firstChild).to.matchSnapshot();
  });
});

describe('<ProductPage /> convertAmount()', () => {
  it('should return empty string when null amount is provided', () => {
    expect(convertAmount(null, 1)).to.eql('');
  });

  it('should return empty string when nullable exchange rate is provided', () => {
    expect(convertAmount(1, null)).to.eql('');
  });

  it('should match rounded result of converted amount', () => {
    const amount = 2;
    const exchangeRate = 1.7997;
    const expectedAmount = '3.60';
    expect(convertAmount(amount, exchangeRate)).to.eql(expectedAmount);
  });
});

describe('<ProductPage /> getCurrency()', () => {
  const mockCurrencyList: Array<CurrencyType> = [
    { id: 1, name: 'US Dollar', rate: 1.25175, code: 'USD' },
    { id: 2, name: 'Australia Dollar', rate: 1.7997, code: 'AUD' },
  ];
  it('should return undefined when currency code is not present in the currencyList', () => {
    expect(getCurrency('123', mockCurrencyList)).to.eql(undefined);
  });

  it('should provide appropriate CurrencyType object for given code', () => {
    expect(getCurrency('USD', mockCurrencyList)).to.eql(mockCurrencyList[0]);
  });
});
