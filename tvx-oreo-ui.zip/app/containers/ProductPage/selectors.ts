import { createSelector } from 'reselect';

import { RootState } from '../../store';

import { initialState } from './reducer';

export const selectProductDetails = (state: RootState) =>
  state.productDetails || initialState;

export const selectCurrencyCode = createSelector(
  selectProductDetails,
  state => state.currencyCode,
);

export const selectAmount = createSelector(
  selectProductDetails,
  state => state.amount,
);

export const selectExchangeRate = createSelector(
  selectProductDetails,
  state => state.exchangeRate,
);
