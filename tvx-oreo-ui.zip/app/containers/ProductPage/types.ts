export interface ProductDetailsType {
  currencyCode: string;
  amount: number | null;
  exchangeRate: number | null;
}
