export interface CurrencyType {
  id: number;
  name: string;
  rate: number;
  code: string;
}

const currencyList: Array<CurrencyType> = [
  { id: 1, name: 'US Dollar', rate: 0.82, code: 'USD' },
  { id: 2, name: 'Australia Dollar', rate: 0.89, code: 'AUD' },
  { id: 3, name: 'Canada Dollar', rate: 0.62, code: 'CAD' },
  { id: 4, name: 'Euro', rate: 0.89, code: 'EUR' },
];

export default currencyList;

/**
 * redux action types
 */
export const SET_PRODUCT_DETAILS = 'SET_PRODUCT_DETAILS';
