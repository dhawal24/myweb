import { ActionType, createReducer, getType } from 'typesafe-actions';
import produce from 'immer';

import * as actions from './actions';
import { ProductDetailsType } from './types';

export type ProductDetailsState = Readonly<ProductDetailsType>;

export const initialState: ProductDetailsState = {
  currencyCode: '',
  amount: null,
  exchangeRate: null,
};

export const setProductDetailsHandler = (
  state: ProductDetailsState,
  action: ActionType<typeof actions.setProductDetails>,
) =>
  produce(state, draft => {
    draft.currencyCode = action.currencyCode;
    draft.amount = action.amount;
    draft.exchangeRate = action.exchangeRate;
  });

export default createReducer<any, any>(initialState, {
  [getType(actions.setProductDetails)]: setProductDetailsHandler,
});
