import { createCustomAction } from 'typesafe-actions';

import { SET_PRODUCT_DETAILS } from './constants';

export const setProductDetails = createCustomAction(
  SET_PRODUCT_DETAILS,
  type => (
    currencyCode: string,
    amount: number | null,
    exchangeRate: number | null,
  ) => ({
    type,
    currencyCode,
    amount,
    exchangeRate,
  }),
);
