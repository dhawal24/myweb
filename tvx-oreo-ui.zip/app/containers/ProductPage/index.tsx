/**
 * HomePage
 *
 * This is the first thing users see of our App, at the '/' route
 *
 */

import React, { useState } from 'react';
import { push } from 'connected-react-router';
import { FormattedMessage } from 'react-intl';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { Box, Collapse, Typography } from '@material-ui/core';

import Container from '../../components/Container';
import { FlowStepperActions } from '../../components/FlowStepper/types';
import { RootState } from '../../store';
import { useInjectReducer } from '../../utils/injectReducer';
import StepperControls from '../../components/StepperControls';
import InputField from '../../components/InputField';
import SelectField, {
  SelectFieldOptionsType,
} from '../../components/SelectField';

import messages from './messages';
import currencyList, { CurrencyType } from './constants';
import { setProductDetails } from './actions';
import { RateDetailsType } from 'containers/RatesPage/types';
import productReducer from './reducer';
import {
  selectAmount,
  selectCurrencyCode,
  selectExchangeRate,
} from './selectors';

import { ProductDetailsType } from 'containers/ProductPage/types';

interface StateProps {
  ratesDetails: RateDetailsType;
}

interface DispatchProps {
  setProductDetails: (
    currencyCode: string,
    amount: number | null,
    exchangeRate: number | null,
  ) => void;
}

interface Props extends StateProps, ProductDetailsType, DispatchProps, FlowStepperActions {}

export const ProductPage: React.FC<Props> = (props: Props) => {
  useInjectReducer({
    key: 'productDetails',
    reducer: productReducer,
  });

  const [amount, setAmount] = useState(props.amount ? props.amount : 1);
  const [exchangeRate, setExchangeRate] = useState(props.exchangeRate);
  const [currencyCode, setCurrencyCode] = useState(props.currencyCode);

  const convertedAmount = convertAmount(amount, exchangeRate);

  const { ratesDetails } = props;

  console.log(ratesDetails);

  const handleChangeCurrency = (
    event: React.ChangeEvent<{ name?: string; value: unknown }>,
  ) => {
    const code = event.target.value ? (event.target.value as string) : '';
    const currency = getCurrency(code, currencyList);

    if (currency) {
      setExchangeRate(currency.rate);
      setCurrencyCode(code);
    }
  };

  const handleAmountChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = event.target;
    setAmount(parseFloat(value));
  };

  function handleSubmit() {
    props.setProductDetails(currencyCode, amount, exchangeRate);
    props.next();
  }

  const gbpExchangeHelper = currencyCode
    ? `1 GBP = ${exchangeRate} ${currencyCode}`
    : '';

  return (
    <Container p={4} logo cardSpacing={4}>
      <Box
        width={450}
        height={350}
        m="auto"
        display="flex"
        alignItems="center"
        justifyContent="center"
        flexDirection="column"
      >
        <Box width="100%" py={1}>
          <SelectField
            id="currency"
            name="currency"
            label={
              currencyCode ? (
                <FormattedMessage {...messages.currency} />
              ) : (
                'Select Currency'
              )
            }
            options={mapCurrencyOptions(currencyList)}
            value={currencyCode}
            onChange={handleChangeCurrency}
          />
        </Box>
        <Box width="100%">
          <Collapse in={!!currencyCode}>
            <Box width="100%" py={1}>
              <InputField
                id="amount"
                name="amount"
                type="text"
                label={<FormattedMessage {...messages.quantity} />}
                value={amount || ''}
                onChange={handleAmountChange}
                helperText={gbpExchangeHelper}
                fullWidth
                required
              />
            </Box>
            <Box
              width="100%"
              py={1}
              px={2}
              bgcolor="#E8EBEF"
              borderRadius="borderRadius"
            >
              <Box width="100%">
                <Typography variant="caption">How much you will pay</Typography>
              </Box>
              <Typography variant="h5">
                {convertedAmount
                  ? `${convertedAmount} GBP`
                  : 'Please add an amount'}
              </Typography>
            </Box>
          </Collapse>
          <StepperControls
            isBackHidden
            isNextDisabled={!convertedAmount}
            onClickNext={handleSubmit}
            onClickBack={props.back}
          />
        </Box>
      </Box>
    </Container>
  );
};

/**
 * Gets currency from currencyList by given code
 * Will return undefined if currency code is not presents
 * @param code - currency identifier
 * @param currencies - a list of CurrencyType objects
 */
export const getCurrency = (
  code: string,
  currencies: Array<CurrencyType>,
): CurrencyType | undefined => currencies.find(t => t.code === code);

/**
 * Converts the amount by exchange rate
 */
export const convertAmount = (
  amount: number | null,
  exchangeRate: number | null,
): string => {
  if (!amount) return '';
  if (!exchangeRate) return '';
  return (amount * exchangeRate).toFixed(2);
};

export const mapCurrencyOptions = (
  currencies: Array<CurrencyType>,
): Array<SelectFieldOptionsType> =>
  currencies.map(
    currency =>
      ({ key: currency.code, value: currency.name } as SelectFieldOptionsType),
  );

const mapStateToProps = createStructuredSelector<RootState, ProductDetailsType>(
  {
    currencyCode: selectCurrencyCode,
    amount: selectAmount,
    exchangeRate: selectExchangeRate,
  },
);

const mapDispatchToProps = {
  setProductDetails,
  push,
};

const withConnect = connect<
  ProductDetailsType,
  DispatchProps,
  FlowStepperActions
>(
  mapStateToProps,
  mapDispatchToProps,
);

export default withConnect(ProductPage);
