/*
 * RatesPage Messages
 *
 * This contains all the text for the ProductPage container.
 */
import { defineMessages } from 'react-intl';

const messages = defineMessages({
    currencyCode : {
        id:'app.containers.RatesPage.currencyCode',
        defaultMessage: 'Currency Code',
    },
    exchangeRates:{
        id:'app.containers.RatesPage.exchangeRates',
        defaultMessage: 'Exchange Rates',
    },
    serviceType:{
        id:'app.containers.serviceType.exchangeRates',
        defaultMessage: 'Product/Service',
    },
    buyNow:{
        id:'app.containers.buyNow.exchangeRates',
        defaultMessage: 'Buy Now',
    }
});

export default messages;