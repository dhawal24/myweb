/**
 * Asynchronously loads the component for RatesPage
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
