/*
 * Rates
 *
 */
import React, { useState } from 'react';
import { push } from 'connected-react-router';
import { FormattedMessage } from 'react-intl';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { Box, Table, TableBody, TableCell, TableHead, TableRow } from '@material-ui/core';  

import Container from '../../components/Container';
import { FlowStepperActions } from '../../components/FlowStepper/types';
import { RootState } from '../../store';
import { useInjectReducer } from '../../utils/injectReducer';
import { makeStyles } from '@material-ui/core';

import messages from './messages';
import RatesList, { RatesType } from './constants';
import { submitRatesDetails } from './actions';
import { RateDetailsType } from './types';
import rateReducer from './reducer';
import { 
  selectPartnerRateCode,
  selectPartnerExchangeRate,
} from './selectors';

interface DispatchProps {
  submitRatesDetails: (
    partnerRateCode: string,
    partnerExchangeRate: number | null,
  ) => void;
}

interface Props extends RateDetailsType, DispatchProps, FlowStepperActions {}

const useStyles = makeStyles({  
  table: {
    padding: 0,
  },
  button: {
    border: 0,
    fontWeight:"bold",
    background:'transparent',
    color:"orange",
  },
});


export const RatesPage: React.FC<Props> = (props: Props) => {

  useInjectReducer({
    key: 'rateDetails',
    reducer: rateReducer,
  });

  const classes = useStyles();
  const [partnerExchangeRate, setPartnerExchangeRate] = useState(props.partnerExchangeRate);
  const [partnerRateCode, setPartnerRateCode] = useState(props.partnerRateCode);

  const handleSubmit = (event: number) => {

    const rateData = getCurrency(event, RatesList);

    if (rateData) {
      setPartnerExchangeRate(rateData.rate);
      setPartnerRateCode(rateData.code);
      
      props.submitRatesDetails(partnerRateCode, partnerExchangeRate);
      
      console.log(partnerRateCode+'~~~~'+partnerExchangeRate);
      props.next();
    }  

   
  }

  return(
      <Container p={4} logo cardSpacing={4}>
          <Box
          width={650}
          height={280}
          m="auto"
          display="flex"
          alignItems="center"
          justifyContent="center"
          flexDirection="column"
        >
          <Table className={classes.table}>
            <TableHead>
              <TableRow>
                <TableCell>
                  <FormattedMessage {...messages.currencyCode} />
                </TableCell>
                <TableCell>
                <FormattedMessage {...messages.exchangeRates} />
                </TableCell>
                <TableCell>
                  <FormattedMessage {...messages.exchangeRates} />
                </TableCell>
                <TableCell>
                  <FormattedMessage {...messages.buyNow} />
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
            {RatesList.map(rateArrayData => (
                <TableRow>
                  <TableCell>{rateArrayData.code}</TableCell>
                  <TableCell>{rateArrayData.rate}</TableCell>
                  <TableCell>{rateArrayData.serviceType}</TableCell>
                  <TableCell><button className={classes.button} key={rateArrayData.id} onClick={()=>handleSubmit(rateArrayData.id)}>Order Online</button></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
           
        </Box>
      </Container>
  )
}

export const getCurrency = (
  id: number,
  currencies: Array<RatesType>,
): RatesType | undefined => currencies.find(t => t.id === id);

const mapStateToProps = createStructuredSelector<RootState, RateDetailsType>(
  {
    partnerRateCode: selectPartnerRateCode,
    partnerExchangeRate: selectPartnerExchangeRate,
  },
);

const mapDispatchToProps = {
  submitRatesDetails,
  push,
};

const withConnect = connect<
  RateDetailsType,
  DispatchProps,
  FlowStepperActions
>(
  mapStateToProps,
  mapDispatchToProps,
);

export default withConnect(RatesPage);