import { createCustomAction } from 'typesafe-actions';
import { SET_RATES_DETAILS } from './constants';

export const submitRatesDetails = createCustomAction(
    SET_RATES_DETAILS,
    type => (
      partnerRateCode: string,
      partnerExchangeRate: number | null,
    ) => ({
      type,
      partnerRateCode,
      partnerExchangeRate,
    }),
  );
  