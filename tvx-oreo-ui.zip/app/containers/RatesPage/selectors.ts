import { createSelector } from 'reselect';
import { RootState } from '../../store';
import { initialState } from './reducer';

export const selectRateDetails = (state: RootState) =>
  state.rateDetails || initialState;

export const selectPartnerRateCode = createSelector(
    selectRateDetails,
    state => state.partnerRateCode,
);

export const selectPartnerExchangeRate = createSelector(
    selectRateDetails,
    state => state.partnerExchangeRate,
);
