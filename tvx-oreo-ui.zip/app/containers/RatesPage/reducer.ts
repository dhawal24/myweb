import { ActionType, createReducer, getType } from 'typesafe-actions';
import produce from 'immer';

import * as actions from './actions';
import { RateDetailsType } from './types';

export type RateDetailsState = Readonly<RateDetailsType>;

export const initialState: RateDetailsState = {
  partnerRateCode: '',
  partnerExchangeRate: null,
};

export const setRateDetailsHandler = (
  state: RateDetailsState,
  action: ActionType<typeof actions.submitRatesDetails>,
) =>
  produce(state, draft => {
    draft.partnerRateCode = action.partnerRateCode;
    draft.partnerExchangeRate = action.partnerExchangeRate;
  });

export default createReducer<any, any>(initialState, {
  [getType(actions.submitRatesDetails)]: setRateDetailsHandler,
});
