export interface RateDetailsType {
    partnerRateCode: string;
    partnerExchangeRate: number | null;
}
  