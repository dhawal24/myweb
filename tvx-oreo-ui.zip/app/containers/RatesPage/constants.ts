export interface RatesType {
    id: number;
    name: string;
    rate: number;
    code: string;
    serviceType: string;
  }

  const RatesList:Array<RatesType> = [
    { id: 1, name: 'US Dollar', rate: 0.82, code: 'USD', serviceType:'Cash' },
    { id: 2, name: 'Australia Dollar', rate: 0.89, code: 'AUD', serviceType:'Cash' },
    { id: 3, name: 'Canada Dollar', rate: 0.62, code: 'CAD', serviceType:'Cash' },
    { id: 4, name: 'Euro', rate: 0.89, code: 'EUR', serviceType:'Cash' },
  ]

  export default RatesList;

  

/**
 * redux action types
 */
export const SET_RATES_DETAILS = 'SET_RATES_DETAILS';