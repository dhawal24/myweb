import React from 'react';
import { IntlProvider } from 'react-intl';
import { BrowserRouter } from 'react-router-dom';
import { render } from '@testing-library/react';
import { expect } from 'chai';

import App from '../index';

describe('<App />', () => {
  it('should render and match the snapshot', () => {
    const {
      container: { firstChild },
    } = render(
      <IntlProvider locale="en">
        <BrowserRouter>
          <App />
        </BrowserRouter>
      </IntlProvider>,
    );
    expect(firstChild).to.matchSnapshot();
  });
});
