import { RouteProps } from 'react-router';

import ProductPage from 'containers/ProductPage/Loadable';
import OrderFailure from 'containers/OrderFailure';
import OrderSuccess from 'containers/OrderSuccess';
import PersonalDetails from 'containers/PersonalDetails/Loadable';
import OrderDetails from 'containers/OrderDetails';
import ConfirmPayment from 'containers/ConfirmPayment/Loadable';
import ViewOrder from 'containers/ViewOrder';
import FulfillmentPage from 'containers/FulfillmentPage/Loadable';
import FlowPage from 'containers/FlowPage/Loadable';

export interface CustomRouteProps extends RouteProps {
  key: string;
}

// TODO remove flow routes
const routes: CustomRouteProps[] = [
  {
    key: 'confirm-payment',
    exact: true,
    path: '/confirm-payment',
    component: ConfirmPayment,
  },
  {
    key: 'product',
    exact: true,
    path: '/',
    component: FlowPage,
  },
  {
    key: 'details',
    exact: true,
    path: '/details',
    component: OrderDetails,
  },
  {
    key: 'personal-details',
    exact: true,
    path: '/personal-details',
    component: PersonalDetails,
  },
  {
    key: 'fulfillment-details',
    exact: true,
    path: '/fulfillment/:partnerId?',
    component: FulfillmentPage,
  },
  {
    key: 'order-success',
    exact: true,
    path: '/order-success',
    component: OrderSuccess,
  },
  {
    key: 'order-failure',
    exact: true,
    path: '/order-failure',
    component: OrderFailure,
  },
  {
    key: 'confirm',
    exact: true,
    path: '/confirm',
    component: ProductPage,
  },
  {
    key: 'view',
    exact: true,
    path: '/view',
    component: ViewOrder,
  },
];

export default routes;
