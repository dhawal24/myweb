/**
 *
 * App.js
 *
 * This component is the skeleton around the actual pages, and should only
 * contain code that should be seen on all pages. (e.g. navigation bar)
 *
 */

import React from 'react';
import { Route, Switch } from 'react-router-dom';
import { Box, CssBaseline, MuiThemeProvider } from '@material-ui/core';

import NotFoundPage from 'containers/NotFoundPage/Loadable';
import lightTheme from 'utils/themes/light';

import routes, { CustomRouteProps } from './routes';

export default function App() {
  return (
    <MuiThemeProvider theme={lightTheme}>
      <CssBaseline />
      <Box width="100%" height="100%">
        <Box width="100%" height="100%" display="flex" justifyContent="center">
          <Switch>
            {routes.map((routeConfig: CustomRouteProps) => (
              <Route {...routeConfig} />
            ))}
            <Route component={NotFoundPage} />
          </Switch>
        </Box>
      </Box>
    </MuiThemeProvider>
  );
}
