import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import { IntlProvider } from 'react-intl';
import { expect } from 'chai';
import { spy, assert } from 'sinon';

import { HomePage } from '../index';

const LOCALE = 'de';

describe('<HomePage />', () => {
  it('should render and match the snapshot', () => {
    const changeLocaleSpy = spy();
    const {
      container: { firstChild },
      getByText,
    } = render(
      <IntlProvider locale="en">
        <HomePage locale="en" changeLocale={changeLocaleSpy} />
      </IntlProvider>,
    );

    fireEvent.click(getByText(/Change locale/i));
    assert.calledWith(changeLocaleSpy, LOCALE);

    expect(firstChild).to.matchSnapshot();
  });

  it('should call changeLocale on click', () => {
    const changeLocaleSpy = spy();
    const { getByText } = render(
      <IntlProvider locale="en">
        <HomePage locale="en" changeLocale={changeLocaleSpy} />
      </IntlProvider>,
    );

    fireEvent.click(getByText(/Change locale/i));

    assert.calledWith(changeLocaleSpy, LOCALE);
  });
});
