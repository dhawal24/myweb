import React from 'react';
import { IntlProvider } from 'react-intl';
import { render, fireEvent } from '@testing-library/react';
import { expect } from 'chai';
import { spy, assert } from 'sinon';

import { OrderSuccess } from '../index';

describe('<OrderSuccess />', () => {
  it('should render and match the snapshot', () => {
    const next = spy();
    const {
      container: { firstChild },
    } = render(
      <IntlProvider locale="en">
        <OrderSuccess next={next} />
      </IntlProvider>,
    );
    expect(firstChild).to.matchSnapshot();
  });

  it('should call push with parameter on submit click', () => {
    const nextSpy = spy();
    const { getByText } = render(
      <IntlProvider locale="en">
        <OrderSuccess next={nextSpy} />
      </IntlProvider>,
    );
    fireEvent.click(getByText(/Next/i));
    assert.calledWith(nextSpy);
  });
});
