import React from 'react';
import { FormattedMessage } from 'react-intl';
import { connect } from 'react-redux';
import { Box, Divider, Typography } from '@material-ui/core';

import Container from '../../components/Container';
import { FlowStepperActions } from '../../components/FlowStepper/types';
import StepperControls from '../../components/StepperControls';

import messages from './messages';

enum FulfillmentType {
  HOME_DELIVERY = 'Home Delivery',
  PARTNER_PICKUP = 'Partner Pickup',
}

interface OrderSummary {
  orderNumber: string;
  currency: string;
  userCurrency: string;
  exchangeRate: number;
  amountToChange: number;
  FulfillmentType: FulfillmentType;
  deliveryDate: string;
}

const data: OrderSummary = {
  orderNumber: 'TVX123456789',
  currency: 'EUR',
  userCurrency: 'GBP',
  exchangeRate: 1.0938,
  amountToChange: 500,
  FulfillmentType: FulfillmentType.HOME_DELIVERY,
  deliveryDate: '19/06/2019',
};

type Props = FlowStepperActions;

export const OrderSuccess: React.FC<Props> = (props: Props) => {
  const handleSubmit = () => {
    props.next();
  };

  return (
    <Container p={2} logo>
      <Box px={4} py={2}>
        <Typography variant="h4">
          <FormattedMessage {...messages.title} />
        </Typography>
      </Box>
      <Divider variant="fullWidth" orientation="horizontal" />
      <Box display="flex" flexDirection="row" px={4} py={1}>
        <Box mr={0.5}>
          <Typography variant="h5">
            <FormattedMessage {...messages.subTitle} />:
          </Typography>
        </Box>
        <Typography variant="h5">
          <Box fontWeight="700">{data.orderNumber}</Box>
        </Typography>
      </Box>
      <Divider variant="fullWidth" orientation="horizontal" />
      <Box px={4} py={1}>
        <Typography variant="h6">
          <FormattedMessage {...messages.summary} />:
        </Typography>
      </Box>
      <Box px={4} fontSize="body1.fontSize">
        <Box py={1} width="100%" display="flex">
          <Box flexGrow={1} flexShrink={0}>
            <Typography
              display="inline"
              color="textSecondary"
              variant="inherit"
            >
              <FormattedMessage {...messages.currency} />
            </Typography>
          </Box>
          <Box textAlign="right">
            <Typography display="inline" variant="inherit">
              {data.currency}
            </Typography>
          </Box>
        </Box>

        <Box py={1} width="100%" display="flex">
          <Box flexGrow={1} flexShrink={0}>
            <Typography
              display="inline"
              color="textSecondary"
              variant="inherit"
            >
              {data.amountToChange} {data.currency} @ {data.exchangeRate}
            </Typography>
          </Box>
          <Box textAlign="right">
            <Typography display="inline" variant="inherit">
              {(data.amountToChange / data.exchangeRate).toFixed(2)}{' '}
              {data.userCurrency}
            </Typography>
          </Box>
        </Box>

        <Box py={1} width="100%" display="flex">
          <Box flexGrow={1} flexShrink={0}>
            <Typography
              display="inline"
              color="textSecondary"
              variant="inherit"
            >
              <FormattedMessage {...messages.fulfillment} />
            </Typography>
          </Box>
          <Box textAlign="right">
            <Typography display="inline" variant="inherit">
              {data.FulfillmentType}
            </Typography>
          </Box>
        </Box>

        <Box py={1} width="100%" display="flex">
          <Box flexGrow={1} flexShrink={0}>
            <Typography
              display="inline"
              color="textSecondary"
              variant="inherit"
            >
              <FormattedMessage {...messages.deliveryDate} />
            </Typography>
          </Box>
          <Box textAlign="right">
            <Typography display="inline" variant="inherit">
              {data.deliveryDate}
            </Typography>
          </Box>
        </Box>
      </Box>
      <Box px={4} pb={4}>
        <StepperControls onClickNext={handleSubmit} onClickBack={props.back} />
      </Box>
    </Container>
  );
};

const mapDispatchToProps = {};

const withConnect = connect<never, any, FlowStepperActions>(
  null,
  mapDispatchToProps,
);

export default withConnect(OrderSuccess);
