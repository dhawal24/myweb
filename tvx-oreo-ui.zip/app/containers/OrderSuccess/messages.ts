/*
 * ProductPage Messages
 *
 * This contains all the text for the ProductPage container.
 */
import { defineMessages } from 'react-intl';

const messages = defineMessages({
  title: {
    id: 'app.containers.OrderSuccess.title',
    defaultMessage: 'Thank you for your order',
  },
  subTitle: {
    id: 'app.containers.OrderSuccess.subtitle',
    defaultMessage: 'Your order number is',
  },
  summary: {
    id: 'app.containers.OrderSuccess.summary',
    defaultMessage: 'Order Summary',
  },
  currency: {
    id: 'app.containers.OrderSuccess.currency',
    defaultMessage: 'Currency',
  },
  fulfillment: {
    id: 'app.containers.OrderSuccess.fulfillment',
    defaultMessage: 'Fulfillment Type',
  },
  deliveryDate: {
    id: 'app.containers.OrderSuccess.delivery',
    defaultMessage: 'Delivery Date',
  },
  submit: {
    id: 'app.containers.OrderSuccess.submit',
    defaultMessage: 'Proceed to Payment',
  },
});

export default messages;
