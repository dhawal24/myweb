import React from 'react';
import { expect } from 'chai';
import { render } from '@testing-library/react';
import { Provider } from 'react-redux';

import store from '../../../store';
import { FlowPage } from '../index';

describe('<FlowPage />', () => {
  it('should render and match snapshot', () => {
    const {
      container: { firstChild },
    } = render(
      <Provider store={store}>
        <FlowPage />
      </Provider>,
    );
    expect(firstChild).to.matchSnapshot();
  });
});
