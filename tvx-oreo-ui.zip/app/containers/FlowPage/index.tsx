import React, { FC } from 'react';

import FlowStepper from '../../components/FlowStepper';

export const FlowPage: FC = () => <FlowStepper />;

export default FlowPage;
