/**
 * Asynchronously loads the component for FlowPage
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
