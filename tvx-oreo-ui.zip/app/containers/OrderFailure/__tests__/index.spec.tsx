import React from 'react';
import { IntlProvider } from 'react-intl';
import { render } from '@testing-library/react';
import { expect } from 'chai';

import { OrderFailure } from '../index';

describe('<OrderFailure />', () => {
  it('should render and match the snapshot', () => {
    const {
      container: { firstChild },
    } = render(
      <IntlProvider locale="en">
        <OrderFailure />
      </IntlProvider>,
    );
    expect(firstChild).to.matchSnapshot();
  });
});
