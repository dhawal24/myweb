import React from 'react';
import { FormattedMessage } from 'react-intl';
import { Box, Divider, Typography } from '@material-ui/core';

import Container from '../../components/Container';

import messages from './messages';

export const OrderFailure: React.FC<{}> = () => (
  <Container p={2} logo>
    <Box width={500}>
      <Box p={2} textAlign="center">
        <Typography variant="h4" align="center">
          <FormattedMessage {...messages.title} />
        </Typography>
      </Box>
      <Divider orientation="horizontal" variant="fullWidth" />
      <Box textAlign="center" p={4} pt={2}>
        <Typography variant="h5" align="center" gutterBottom>
          <FormattedMessage {...messages.subTitle} />
        </Typography>
        <Typography variant="button" gutterBottom color="error">
          <FormattedMessage {...messages.code} /> 101
        </Typography>
      </Box>
    </Box>
  </Container>
);

export default OrderFailure;
