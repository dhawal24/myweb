import { createCustomAction } from 'typesafe-actions';

import HttpError from 'utils/HttpError';

import {
  FETCH_ORDER_CONFIRMATION_FAILURE,
  FETCH_ORDER_CONFIRMATION_REQUEST,
  FETCH_ORDER_CONFIRMATION_SUCCESS,
} from './constants';

export const fetchOrderConfirmationRequest = createCustomAction(
  FETCH_ORDER_CONFIRMATION_REQUEST,
  type => (
    orderReferenceCode: string,
    paymentStatus: string,
    paymentReference: string,
  ) => ({
    type,
    orderReferenceCode,
    paymentStatus,
    paymentReference,
  }),
);

export const fetchOrderConfirmationSuccess = createCustomAction(
  FETCH_ORDER_CONFIRMATION_SUCCESS,
  type => () => ({
    type,
  }),
);

export const fetchOrderConfirmationFailure = createCustomAction(
  FETCH_ORDER_CONFIRMATION_FAILURE,
  type => (error: HttpError) => ({
    type,
    error,
  }),
);
