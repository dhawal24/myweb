import { ActionType, createReducer, getType } from 'typesafe-actions';
import produce from 'immer';

import * as actions from './actions';
import { ConfirmationPaymentState } from './types';

export const initialState: ConfirmationPaymentState = {
  isLoading: false,
  error: null,
  success: false,
};

export const fetchOrderConfirmationRequestHandler = (
  state: ConfirmationPaymentState,
) =>
  produce(state, draft => {
    draft.isLoading = true;
    draft.error = null;
    draft.success = false;
  });

export const fetchOrderConfirmationSuccessHandler = (
  state: ConfirmationPaymentState,
) =>
  produce(state, draft => {
    draft.isLoading = false;
    draft.error = null;
    draft.success = true;
  });

export const fetchOrderConfirmationFailureHandler = (
  state: ConfirmationPaymentState,
  action: ActionType<typeof actions.fetchOrderConfirmationFailure>,
) =>
  produce(state, draft => {
    draft.isLoading = false;
    draft.error = action.error;
    draft.success = false;
  });

export default createReducer<any, any>(initialState, {
  [getType(
    actions.fetchOrderConfirmationRequest,
  )]: fetchOrderConfirmationRequestHandler,
  [getType(
    actions.fetchOrderConfirmationSuccess,
  )]: fetchOrderConfirmationSuccessHandler,
  [getType(
    actions.fetchOrderConfirmationFailure,
  )]: fetchOrderConfirmationFailureHandler,
});
