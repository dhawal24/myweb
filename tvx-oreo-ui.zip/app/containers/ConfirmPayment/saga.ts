import { call, put, takeLatest } from 'redux-saga/effects';
import { ActionType, getType } from 'typesafe-actions';

import HttpError from 'utils/HttpError';

import * as actions from './actions';
import { sendConfirmationRequest } from './api';

export function* submitConfirmation(
  action: ActionType<typeof actions.fetchOrderConfirmationRequest>,
) {
  try {
    const data = yield call(
      sendConfirmationRequest,
      action.orderReferenceCode,
      action.paymentStatus,
      action.paymentReference,
    );
    if (data.paymentStatus === 'success') {
      yield put(actions.fetchOrderConfirmationSuccess());
    } else if (data.Error) {
      actions.fetchOrderConfirmationFailure(
        new HttpError(
          '403',
          'The server understood the request but refuses to authorize it.',
        ),
      );
    } else if (data.paymentStatus === 'failure') {
      actions.fetchOrderConfirmationFailure(
        new HttpError(
          '403',
          'The server understood the request but refuses to authorize it.',
        ),
      );
    } else {
      actions.fetchOrderConfirmationFailure(
        new HttpError('500', 'Server error'),
      );
    }
  } catch (error) {
    yield put(actions.fetchOrderConfirmationFailure(error));
  }
}

export default function* confirmationSaga() {
  yield takeLatest(
    getType(actions.fetchOrderConfirmationRequest),
    submitConfirmation,
  );
}
