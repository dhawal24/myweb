import { createSelector } from 'reselect';

import { RootState } from '../../store';

import { initialState } from './reducer';

export const selectConfirmPayment = (state: RootState) =>
  state.confirmPayment || initialState;

export const selectIsLoading = createSelector(
  selectConfirmPayment,
  state => state.isLoading,
);

export const selectSuccess = createSelector(
  selectConfirmPayment,
  state => state.success,
);

export const selectError = createSelector(
  selectConfirmPayment,
  state => state.error,
);
