import HttpError from 'utils/HttpError';

/**
 * Redux types
 */

export interface ConfirmationPaymentState {
  isLoading: boolean;
  error?: HttpError | null;
  success?: boolean | null;
}
