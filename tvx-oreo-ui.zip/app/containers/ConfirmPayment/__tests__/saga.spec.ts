import { expectSaga, testSaga } from 'redux-saga-test-plan';
import { call } from 'redux-saga-test-plan/matchers';

import HttpError from 'utils/HttpError';

import {
  fetchOrderConfirmationFailure,
  fetchOrderConfirmationRequest,
  fetchOrderConfirmationSuccess,
} from '../actions';
import confirmationPaymentSaga, { submitConfirmation } from '../saga';
import { FETCH_ORDER_CONFIRMATION_REQUEST } from '../constants';
import * as api from '../api';

describe('ConfirmPayment saga', () => {
  it('should dispatch request action', () => {
    expectSaga(confirmationPaymentSaga)
      .dispatch(fetchOrderConfirmationRequest('123', 'status', 'ref'))
      .run();
  });

  it('should take submitConfirmation saga and provide appropriate action', () => {
    testSaga(confirmationPaymentSaga)
      .next()
      .takeLatest(FETCH_ORDER_CONFIRMATION_REQUEST, submitConfirmation);
  });
  it('should provide an api success response value for confirmation payment call', () => {
    const apiResult = { paymentStatus: 'success' };
    expectSaga(
      submitConfirmation,
      fetchOrderConfirmationRequest('123', 'status', 'ref'),
    )
      .provide([[call.fn(api.sendConfirmationRequest), apiResult]])
      .put(fetchOrderConfirmationSuccess())
      .run();
  });

  it('should provide an api failure response value for confirmation payment call', () => {
    const apiResult = { paymentStatus: 'failure' };
    expectSaga(
      submitConfirmation,
      fetchOrderConfirmationRequest('123', 'status', 'ref'),
    )
      .provide([[call.fn(api.sendConfirmationRequest), apiResult]])
      .put(fetchOrderConfirmationFailure(new HttpError('123', 'error')))
      .run();
  });
});
