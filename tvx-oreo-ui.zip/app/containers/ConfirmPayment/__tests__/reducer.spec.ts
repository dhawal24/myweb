import { expect } from 'chai';

import HttpError from 'utils/HttpError';

import confirmPaymentReducer from '../reducer';
import { ConfirmationPaymentState } from '../types';
import {
  fetchOrderConfirmationFailure,
  fetchOrderConfirmationRequest,
  fetchOrderConfirmationSuccess,
} from '../actions';

const mockError = new HttpError('123', 'error');

const mockConfirmationPaymentState: ConfirmationPaymentState = {
  isLoading: false,
  error: null,
  success: false,
};

describe('ConfirmPayment reducer', () => {
  it('should return given state for an invalid action', () => {
    expect(
      confirmPaymentReducer(mockConfirmationPaymentState, { type: null }),
    ).to.eql(mockConfirmationPaymentState);
  });

  it('should change isLoading value to true', () => {
    expect(
      confirmPaymentReducer(
        mockConfirmationPaymentState,
        fetchOrderConfirmationRequest('123', 'status', 'ref'),
      ),
    ).to.eql({
      ...mockConfirmationPaymentState,
      isLoading: true,
    });
  });

  it('should match expected state and provide success action', () => {
    expect(
      confirmPaymentReducer(
        { ...mockConfirmationPaymentState, isLoading: true },
        fetchOrderConfirmationSuccess(),
      ),
    ).to.eql({
      ...mockConfirmationPaymentState,
      success: true,
    });
  });

  it('should provide given error', () => {
    expect(
      confirmPaymentReducer(
        mockConfirmationPaymentState,
        fetchOrderConfirmationFailure(mockError),
      ),
    ).to.eql({
      ...mockConfirmationPaymentState,
      error: mockError,
    });
  });
});
