import React from 'react';
import { render } from '@testing-library/react';
import { FormattedMessage, IntlProvider } from 'react-intl';
import { expect } from 'chai';
import { spy } from 'sinon';
import { Provider } from 'react-redux';
import { Typography } from '@material-ui/core';

import HttpError from 'utils/HttpError';

import { ConfirmPayment, getMessage, StateProps } from '../index';
import { DEFAULT_LOCALE } from '../../../i18n';
import store from '../../../store';
import messages from '../messages';

describe('<ConfirmPayment />', () => {
  it('should render and match the snapshot', () => {
    const fetchOrderConfirmationRequest = spy();
    const next = spy();
    const {
      container: { firstChild },
    } = render(
      <Provider store={store}>
        <IntlProvider locale={DEFAULT_LOCALE}>
          <ConfirmPayment
            next={next}
            error={null}
            isLoading={false}
            success={false}
            fetchOrderConfirmationRequest={fetchOrderConfirmationRequest}
          />
        </IntlProvider>
      </Provider>,
    );
    expect(firstChild).to.matchSnapshot();
  });
});

describe('<ConfirmPayment /> getMessage function', () => {
  it('should return null when in given props are not present success or error field', () => {
    expect(getMessage({} as StateProps)).to.eql(null);
  });

  it('should return match error heading component when error in given state is valued', () => {
    const expectedOutput = (
      <Typography variant="h6" color="error" gutterBottom>
        <FormattedMessage {...messages.paymentError} />
      </Typography>
    );
    expect(
      getMessage({
        error: new HttpError('123', 'error'),
      } as StateProps),
    ).to.eql(expectedOutput);
  });

  it('should return match success heading component when success in given state is valued', () => {
    const expectedOutput = (
      <Typography variant="h6" color="primary" gutterBottom>
        <FormattedMessage {...messages.paymentSuccess} />
      </Typography>
    );
    expect(getMessage({ success: true } as StateProps)).to.eql(expectedOutput);
  });
});
