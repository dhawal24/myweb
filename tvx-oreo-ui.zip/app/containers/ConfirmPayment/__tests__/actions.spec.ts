import { expect } from 'chai';

import HttpError from 'utils/HttpError';

import * as actions from '../actions';
import {
  FETCH_ORDER_CONFIRMATION_FAILURE,
  FETCH_ORDER_CONFIRMATION_REQUEST,
  FETCH_ORDER_CONFIRMATION_SUCCESS,
} from '../constants';

describe('ConfirmPayment actions', () => {
  it('should create an action to request order  confirmation', () => {
    const expectedAction = {
      type: FETCH_ORDER_CONFIRMATION_REQUEST,
      orderReferenceCode: '123',
      paymentStatus: 'status',
      paymentReference: 'ref',
    };
    expect(
      actions.fetchOrderConfirmationRequest(
        expectedAction.orderReferenceCode,
        expectedAction.paymentStatus,
        expectedAction.paymentReference,
      ),
    ).to.eql(expectedAction);
  });

  it('should create an action to request order confirmation', () => {
    const expectedAction = {
      type: FETCH_ORDER_CONFIRMATION_REQUEST,
      orderReferenceCode: '123',
      paymentStatus: 'status',
      paymentReference: 'ref',
    };
    expect(
      actions.fetchOrderConfirmationRequest(
        expectedAction.orderReferenceCode,
        expectedAction.paymentStatus,
        expectedAction.paymentReference,
      ),
    ).to.eql(expectedAction);
  });

  it('should create a successful action to request order confirmation', () => {
    const expectedAction = {
      type: FETCH_ORDER_CONFIRMATION_SUCCESS,
    };
    expect(actions.fetchOrderConfirmationSuccess()).to.eql(expectedAction);
  });

  it('should create a failure action to request order confirmation', () => {
    const mockError = new HttpError('123', 'error');
    const expectedAction = {
      type: FETCH_ORDER_CONFIRMATION_FAILURE,
      error: mockError,
    };
    expect(actions.fetchOrderConfirmationFailure(mockError)).to.eql(
      expectedAction,
    );
  });
});
