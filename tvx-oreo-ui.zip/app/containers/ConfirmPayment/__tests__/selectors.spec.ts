import { expect } from 'chai';

import * as selectors from '../selectors';
import { initialState } from '../reducer';
import { RootState } from '../../../store';
import HttpError from '../../../utils/HttpError';

const mockError = new HttpError('123', 'error');

const mockState: RootState = {
  confirmPayment: {
    isLoading: false,
    error: mockError,
    success: false,
  },
};

describe('PersonalDetails selectors', () => {
  it('should match the initial state when given state is invalid', () => {
    expect(selectors.selectConfirmPayment({})).to.eql(initialState);
  });

  it('should match isLoading field from given state', () => {
    expect(selectors.selectIsLoading(mockState)).to.eql(
      mockState.confirmPayment.isLoading,
    );
  });

  it('should match error field from given state', () => {
    expect(selectors.selectError(mockState)).to.eql(
      mockState.confirmPayment.error,
    );
  });

  it('should match success field from given state', () => {
    expect(selectors.selectSuccess(mockState)).to.eql(
      mockState.confirmPayment.success,
    );
  });
});
