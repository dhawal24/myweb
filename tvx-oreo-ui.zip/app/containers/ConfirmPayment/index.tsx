import React, { useState } from 'react';
import { FormattedMessage } from 'react-intl';
import {
  Box,
  FormControlLabel,
  Radio,
  RadioGroup,
  Typography,
} from '@material-ui/core';
import { createStructuredSelector } from 'reselect';
import { connect } from 'react-redux';

import Container from 'components/Container';
import { FlowStepperActions } from 'components/FlowStepper/types';
import StepperControls from 'components/StepperControls';
import HttpError from 'utils/HttpError';

import { useInjectReducer } from '../../utils/injectReducer';
import { useInjectSaga } from '../../utils/injectSaga';
import { SagaInjectorMode } from '../../utils/constants';
import { RootState } from '../../store';
import InputField from '../../components/InputField';

import * as selectors from './selectors';
import confirmPaymentReducer from './reducer';
import confirmPaymentSaga from './saga';
import messages from './messages';
import { fetchOrderConfirmationRequest } from './actions';

export interface StateProps {
  isLoading: boolean;
  success: boolean;
  error: HttpError | null;
}

interface DispatchActions {
  fetchOrderConfirmationRequest: (
    orderReferenceCode: string,
    paymentStatus: string,
    paymentReference: string,
  ) => void;
}

interface Props extends FlowStepperActions, StateProps, DispatchActions {}

export const ConfirmPayment: React.FC<Props> = (props: Props) => {
  useInjectReducer({
    key: 'confirmPayment',
    reducer: confirmPaymentReducer,
  });
  useInjectSaga({
    key: 'confirmPaymentSaga',
    saga: confirmPaymentSaga,
    mode: SagaInjectorMode.RestartOnRemount,
  });

  const [orderReferenceCode, setOrderReferenceCode] = useState('');
  const [paymentStatus, setPaymentStatus] = useState('');

  const handleSubmit = () => {
    props.fetchOrderConfirmationRequest(
      orderReferenceCode,
      paymentStatus,
      'tdc',
    );
  };

  return (
    <Container p={2} logo cardSpacing={4}>
      <Box>
        <Typography variant="h4">
          <FormattedMessage {...messages.header} />
        </Typography>
        <Box py={1}>{getMessage(props)}</Box>
        <Box flex={1} pb={2}>
          <InputField
            id="reference"
            fullWidth
            label={<FormattedMessage {...messages.orderReference} />}
            value={orderReferenceCode || ''}
            onChange={event => setOrderReferenceCode(event.target.value)}
          />
        </Box>
        <Box>
          <RadioGroup
            aria-label="payment"
            name="payment"
            value={paymentStatus}
            onChange={event => setPaymentStatus(event.target.value)}
          >
            <FormControlLabel
              value="success"
              control={<Radio color="primary" />}
              label={<FormattedMessage {...messages.confirmPayment} />}
            />
            <FormControlLabel
              value="failure"
              control={<Radio color="primary" />}
              label={<FormattedMessage {...messages.rejectPayment} />}
            />
          </RadioGroup>
        </Box>
      </Box>
      <StepperControls
        nextMessage="Finish"
        onClickBack={props.back}
        onClickNext={handleSubmit}
      />
    </Container>
  );
};

/**
 * Checks props and gets error or success message according with props fields
 * @param props - properties to be checked
 */
export const getMessage = (props: StateProps) => {
  let heading = null;
  if (props.error) {
    heading = (
      <Typography variant="h6" color="error" gutterBottom>
        <FormattedMessage {...messages.paymentError} />
      </Typography>
    );
  }
  if (props.success) {
    heading = (
      <Typography variant="h6" color="primary" gutterBottom>
        <FormattedMessage {...messages.paymentSuccess} />
      </Typography>
    );
  }
  return heading;
};

const mapStateToProps = createStructuredSelector<RootState, StateProps>({
  isLoading: selectors.selectIsLoading,
  success: selectors.selectSuccess,
  error: selectors.selectError,
});

const mapDispatchToProps = {
  fetchOrderConfirmationRequest,
};

const withConnect = connect<StateProps, DispatchActions, FlowStepperActions>(
  mapStateToProps,
  mapDispatchToProps,
);

export default withConnect(ConfirmPayment);
