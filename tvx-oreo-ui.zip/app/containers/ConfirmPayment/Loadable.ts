/**
 * Asynchronously loads the component for ConfirmPayment page
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
