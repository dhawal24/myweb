import HttpError from 'utils/HttpError';

import env from '../../../env.json';

export const sendConfirmationRequest = async (
  orderReferenceCode: string,
  paymentStatus: string,
  paymentReference: string,
) => {
  try {
    const response = await fetch(
      `${env.API.confirmationPaymentURL}/${orderReferenceCode}/actions/confirmPayment`,
      {
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        mode: 'cors',
        method: 'PATCH',
        body: JSON.stringify({
          orderReferenceCode,
          paymentStatus,
          paymentReference,
        }),
      },
    );
    return await response.json();
  } catch (e) {
    throw new HttpError('500', 'Server error');
  }
};
