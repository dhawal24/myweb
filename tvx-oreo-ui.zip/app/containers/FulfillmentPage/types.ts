export interface FulfillmentType {
  fulfillmentType: string;
  fulfillmentDate: string;
}

export interface SubmitActionType {
  type: string;
  data: FulfillmentType;
}

export interface fulfillActions {
  submitFulfillmentRequest: (data: FulfillmentType) => SubmitActionType;
}

export interface DeliveryDate {
  date: string;
  message?: string;
}

export interface RangeType {
  minDate: Date;
  maxDate: Date;
}
