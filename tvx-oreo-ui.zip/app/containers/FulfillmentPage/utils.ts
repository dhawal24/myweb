import { max, min, parse } from 'date-fns';

import { DeliveryDate, RangeType } from './types';

export const API_DATE_FORMAT = 'dd-MM-yyyy';

/**
 * Returns given date if the it is in the same month range as given reference, undefined otherwise
 * @param date a Date to be checked
 * @param reference a Date to be checked
 */
export const getSelectedValue = (
  date: Date | null,
  reference: Date,
): Date | undefined => {
  if (!date) return undefined;
  if (
    reference.getFullYear() === date.getFullYear() &&
    reference.getMonth() === date.getMonth()
  ) {
    return date;
  }
  return undefined;
};

/**
 * Maps DeliveryDate object to Date
 * @param deliveryDates - an array of DeliveryDates to be mapped
 */
export const mapDates = (
  deliveryDates: Array<DeliveryDate> = [],
): Array<Date> =>
  deliveryDates.map(deliveryDate =>
    parse(deliveryDate.date, API_DATE_FORMAT, new Date()),
  );

/**
 * Return range between min and max date from given array of dates
 * @param dates - an array of Dates
 */
export const getRange = (dates: Array<Date>): RangeType => {
  if (!dates || dates.length === 0) {
    return {} as RangeType;
  }

  const minDate = min(dates);
  const maxDate = max(dates);
  return { minDate, maxDate };
};

/**
 * Check if given date exists as item in given dates array
 * @param date date to be checked
 * @param dates array of Dates
 */
export const existsInDates = (
  date: Date | null,
  dates: Readonly<Array<Date>>,
): boolean => {
  if (!date) return false;
  for (const d of dates) {
    if (d.getTime() === date.getTime()) {
      return true;
    }
  }
  return false;
};
