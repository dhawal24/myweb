import produce from 'immer';
import { ActionType, createReducer, getType } from 'typesafe-actions';

import HttpError from '../../utils/HttpError';

import * as actions from './actions';
import { DeliveryDate } from './types';

export type FulfillmentState = Readonly<{
  deliveryDates: DeliveryDate[];
  fulfillmentType: string;
  fulfillmentDate: string;
  error: HttpError | null;
  isLoading: boolean;
}>;

export const initialState: FulfillmentState = {
  deliveryDates: [],
  fulfillmentType: '',
  fulfillmentDate: '',
  error: null,
  isLoading: false,
};

export const fetchDeliveryDatesRequestHandler = (state: FulfillmentState) =>
  produce(state, draft => {
    draft.deliveryDates = [];
    draft.isLoading = true;
  });

export const setFulfillmentDetailsHandler = (
  state: FulfillmentState,
  action: ActionType<typeof actions.setFulfillmentDetails>,
) =>
  produce(state, draft => {
    draft.fulfillmentType = action.fulfillmentType;
    draft.fulfillmentDate = action.fulfillmentDate;
  });

export const fetchFulfillmentDeliveryDatesHandler = (
  state: FulfillmentState,
  action: ActionType<typeof actions.fetchDeliveryDateSuccess>,
) =>
  produce(state, draft => {
    draft.deliveryDates = action.deliveryDates;
    draft.isLoading = false;
  });

export const fetchDeliveryDatesFailureHandler = (
  state: FulfillmentState,
  action: ActionType<typeof actions.fetchDeliveryDateFailure>,
) =>
  produce(state, draft => {
    draft.error = action.error;
    draft.isLoading = false;
  });
export default createReducer<any, any>(initialState, {
  [getType(
    actions.fetchDeliveryDatesRequest,
  )]: fetchDeliveryDatesRequestHandler,
  [getType(actions.setFulfillmentDetails)]: setFulfillmentDetailsHandler,
  [getType(
    actions.fetchDeliveryDateSuccess,
  )]: fetchFulfillmentDeliveryDatesHandler,
  [getType(actions.fetchDeliveryDateFailure)]: fetchDeliveryDatesFailureHandler,
});
