/*
 * FulfillmentPage Messages
 *
 * This contains all the text for the FulfillmentPage container.
 */
import { defineMessages } from 'react-intl';

const messages = defineMessages({
  title: {
    id: 'app.containers.FulfillmentPage.title',
    defaultMessage: 'How would you like to get your currency?',
  },
  homeDeliveryLabel: {
    id: 'app.containers.FulfillmentPage.homeDeliveryLabel',
    defaultMessage: 'Home Delivery',
  },
  noSelectedValue: {
    id: 'app.containers.FulfillmentPage.noSelectedValue',
    defaultMessage: 'Please select a delivery date',
  },
  storeCollectionLabel: {
    id: 'app.containers.FulfillmentPage.storeCollectionLabel',
    defaultMessage: 'Store Collection',
  },
  error: {
    id: 'app.containers.FulfillmentPage.error',
    defaultMessage: 'Unable to retrieve the home delivery dates.',
  },
});

export default messages;
