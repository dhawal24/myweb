import env from '../../../env.json';

export const getDeliveryDates = async (
  productCode: string,
  currencyISOCode: string,
  fulfillmentType: string,
  partnerId?: string,
): Promise<Response> => {
  const data = await fetch(
    `${env.API.calendarService}/${productCode}/${currencyISOCode}/${fulfillmentType}`,
    {
      headers: {
        pid: `${partnerId || '1234'}`,
      },
    },
  );
  return data.json();
};
