import { createCustomAction } from 'typesafe-actions';

import HttpError from 'utils/HttpError';

import {
  FETCH_DELIVERY_DATES_FAILURE,
  FETCH_DELIVERY_DATES_REQUEST,
  FETCH_DELIVERY_DATES_SUCCESS,
  SET_FULFILLMENT_DETAILS,
} from './constants';
import { DeliveryDate } from './types';

export const setFulfillmentDetails = createCustomAction(
  SET_FULFILLMENT_DETAILS,
  type => (fulfillmentDate: string, fulfillmentType: string) => ({
    type,
    fulfillmentDate,
    fulfillmentType,
  }),
);

export const fetchDeliveryDatesRequest = createCustomAction(
  FETCH_DELIVERY_DATES_REQUEST,
  type => (
    productCode: string,
    currencyISOCode: string,
    fulfillmentType: string,
    partnerId?: string,
  ) => ({
    type,
    productCode,
    currencyISOCode,
    fulfillmentType,
    partnerId,
  }),
);

export const fetchDeliveryDateSuccess = createCustomAction(
  FETCH_DELIVERY_DATES_SUCCESS,
  type => (deliveryDates: DeliveryDate[]) => ({
    type,
    deliveryDates,
  }),
);

export const fetchDeliveryDateFailure = createCustomAction(
  FETCH_DELIVERY_DATES_FAILURE,
  type => (error: HttpError) => ({
    type,
    error,
  }),
);
