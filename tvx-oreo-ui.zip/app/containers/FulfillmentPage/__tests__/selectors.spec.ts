import { expect } from 'chai';
import { parse } from 'date-fns';

import * as selectors from '../selectors';
import { initialState } from '../reducer';
import HttpError from '../../../utils/HttpError';
import { API_DATE_FORMAT } from '../utils';
import { DeliveryDate, RangeType } from '../types';

const deliveryDates: Array<DeliveryDate> = [
  { date: '01-02-2019', message: '' },
  { date: '03-02-2019', message: '' },
  { date: '04-02-2019', message: '' },
];

const mockState = {
  fulfillmentDetails: {
    deliveryDates,
    fulfillmentType: 'type',
    fulfillmentDate: '01-09-2019',
    error: null,
    isLoading: true,
  },
};

describe('Fulfillment selectors', () => {
  it('should match the initial state when given state is invalid', () => {
    expect(selectors.selectFulfillmentDetails({})).to.eql(initialState);
  });

  it('should match delivery dates from given state', () => {
    const expectedOutput = [
      parse(deliveryDates[0].date, API_DATE_FORMAT, new Date()),
      parse(deliveryDates[1].date, API_DATE_FORMAT, new Date()),
      parse(deliveryDates[2].date, API_DATE_FORMAT, new Date()),
    ];
    expect(selectors.selectDeliveryDates(mockState)).to.eql(expectedOutput);
  });

  it('should match delivery dates range (min and max date) from given state', () => {
    const expectedOutput = {
      minDate: parse(deliveryDates[0].date, API_DATE_FORMAT, new Date()),
      maxDate: parse(deliveryDates[2].date, API_DATE_FORMAT, new Date()),
    } as RangeType;
    expect(selectors.selectRange(mockState)).to.eql(expectedOutput);
  });

  it('should match fulfillment type from given state', () => {
    expect(selectors.selectFulfillmentType(mockState)).to.eql(
      mockState.fulfillmentDetails.fulfillmentType,
    );
  });

  it('should match fulfillment date from given state', () => {
    const mockDate = parse(
      mockState.fulfillmentDetails.fulfillmentDate,
      API_DATE_FORMAT,
      new Date(),
    );
    expect(selectors.selectFulfillmentDate(mockState)).to.eql(mockDate);
  });

  it('should return null when fulfillment date is falsy', () => {
    const mockStateWithoutDate = {
      fulfillmentDetails: {
        ...mockState.fulfillmentDetails,
        fulfillmentDate: undefined,
      },
    };
    expect(selectors.selectFulfillmentDate(mockStateWithoutDate)).to.eql(null);
  });

  it('should match isLoading field from given state', () => {
    expect(selectors.selectIsLoading(mockState)).to.eql(
      mockState.fulfillmentDetails.isLoading,
    );
  });

  it('should match error field from given state', () => {
    const mockError = new HttpError('1', 'message');
    const mockStateWithError = {
      fulfillmentDetails: { ...mockState.fulfillmentDetails, error: mockError },
    };
    expect(selectors.selectDeliveryDatesError(mockStateWithError)).to.eql(
      mockError,
    );
  });
});
