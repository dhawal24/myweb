import { expect } from 'chai';

import fulfillmentReducer, {
  fetchFulfillmentDeliveryDatesHandler,
  FulfillmentState,
  setFulfillmentDetailsHandler,
} from '../reducer';
import {
  FETCH_DELIVERY_DATES_REQUEST,
  FETCH_DELIVERY_DATES_SUCCESS,
  SET_FULFILLMENT_DETAILS,
} from '../constants';
import { fetchDeliveryDateSuccess, setFulfillmentDetails } from '../actions';

const mockInitialState: FulfillmentState = {
  deliveryDates: [],
  fulfillmentType: '',
  fulfillmentDate: '',
  error: null,
  isLoading: false,
};

describe('Fulfillment reducer test', () => {
  it('should match initial state when action is invalid', () => {
    expect(fulfillmentReducer(mockInitialState, { type: null })).to.eql(
      mockInitialState,
    );
  });

  it('should change isLoading field for fetch fulfillment request action type', () => {
    const mockFulfillmentRequestAction = {
      type: FETCH_DELIVERY_DATES_REQUEST,
      productCode: 'code',
      currencyISOCode: 'eur',
      fulfillmentType: '123',
      partnerId: '12345',
    };
    const expectedState = {
      ...mockInitialState,
      isLoading: true,
    };

    expect(
      fulfillmentReducer(mockInitialState, mockFulfillmentRequestAction),
    ).to.eql(expectedState);
  });

  it('should match given state for set fulfillment details action type', () => {
    const mockFulfillmentDetailsAction = {
      type: SET_FULFILLMENT_DETAILS,
      fulfillmentType: 'type',
      fulfillmentDate: '01-09-2019',
    };
    const expectedState = {
      ...mockInitialState,
      fulfillmentType: mockFulfillmentDetailsAction.fulfillmentType,
      fulfillmentDate: mockFulfillmentDetailsAction.fulfillmentDate,
    };

    expect(
      fulfillmentReducer(mockInitialState, mockFulfillmentDetailsAction),
    ).to.eql(expectedState);
  });

  it('should match given state for set fulfillment details handler', () => {
    const mockFulfillmentDetailsAction = {
      type: SET_FULFILLMENT_DETAILS,
      fulfillmentType: 'type',
      fulfillmentDate: '01-09-2019',
    };
    const expectedState = {
      ...mockInitialState,
      fulfillmentType: mockFulfillmentDetailsAction.fulfillmentType,
      fulfillmentDate: mockFulfillmentDetailsAction.fulfillmentDate,
    };

    expect(
      setFulfillmentDetailsHandler(
        mockInitialState,
        setFulfillmentDetails(
          mockFulfillmentDetailsAction.fulfillmentDate,
          mockFulfillmentDetailsAction.fulfillmentType,
        ),
      ),
    ).to.eql(expectedState);
  });

  it('should match given state for successful fulfillment fetch delivery date action type', () => {
    const mockFulfillmentDetailsAction = {
      type: FETCH_DELIVERY_DATES_SUCCESS,
      deliveryDates: [{ date: '01-09-2019' }, { date: '01-09-2019' }],
    };
    const expectedState = {
      ...mockInitialState,
      deliveryDates: mockFulfillmentDetailsAction.deliveryDates,
    };

    expect(
      fulfillmentReducer(mockInitialState, mockFulfillmentDetailsAction),
    ).to.eql(expectedState);
  });

  it('should match given state for successful fulfillment fetch delivery date handler', () => {
    const mockFulfillmentDetailsAction = {
      type: FETCH_DELIVERY_DATES_SUCCESS,
      deliveryDates: [{ date: '01-09-2019' }, { date: '01-09-2019' }],
    };
    const expectedState = {
      ...mockInitialState,
      deliveryDates: mockFulfillmentDetailsAction.deliveryDates,
    };

    expect(
      fetchFulfillmentDeliveryDatesHandler(
        mockInitialState,
        fetchDeliveryDateSuccess(mockFulfillmentDetailsAction.deliveryDates),
      ),
    ).to.eql(expectedState);
  });
});
