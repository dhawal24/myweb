import { expect } from 'chai';
import { parse } from 'date-fns';

import {
  API_DATE_FORMAT,
  existsInDates,
  getRange,
  getSelectedValue,
  mapDates,
} from '../utils';
import { DeliveryDate, RangeType } from '../types';

const deliveryDates: Array<DeliveryDate> = [
  { date: '01-02-2019', message: '' },
  { date: '03-02-2019', message: '' },
  { date: '04-02-2019', message: '' },
];

const mockDates = [
  new Date('2019-02-01'),
  new Date('2019-02-03'),
  new Date('2019-02-04'),
];

describe('Fulfillment utils mapDates()', () => {
  it('should return empty array when given deliveryDates are undefined', () => {
    expect(mapDates(undefined)).to.eql([]);
  });

  it('should map deliveryDates to array of dates', () => {
    const expectedOutput = [
      parse(deliveryDates[0].date, API_DATE_FORMAT, mockDates[0]),
      parse(deliveryDates[1].date, API_DATE_FORMAT, mockDates[1]),
      parse(deliveryDates[2].date, API_DATE_FORMAT, mockDates[2]),
    ];

    expect(mapDates(deliveryDates)).to.eql(expectedOutput);
  });
});

describe('Fulfillment utils getBounds()', () => {
  it('should return an empty object when given array is empty', () => {
    expect(getRange([])).to.eql({});
  });

  it('should return an object with the same dates when dates array does not contain a range', () => {
    const mockDatesWithoutRange = [mockDates[0], mockDates[0]];
    const expectedOutput = {
      minDate: mockDates[0],
      maxDate: mockDates[0],
    } as RangeType;
    expect(getRange(mockDatesWithoutRange)).to.eql(expectedOutput);
  });

  it('should return min and max date from given array of dates', () => {
    const expectedOutput = {
      minDate: mockDates[0],
      maxDate: mockDates[2],
    } as RangeType;
    expect(getRange(mockDates)).to.eql(expectedOutput);
  });
});

describe('Fulfillment utils existsInDates()', () => {
  it('should return false when given date is null', () => {
    expect(existsInDates(null, mockDates)).to.eql(false);
  });

  it('should return true when given date is a item of given array', () => {
    expect(existsInDates(mockDates[0], mockDates)).to.eql(true);
  });

  it('should return false when given date is not a item of given array', () => {
    expect(existsInDates(new Date(), mockDates)).to.eql(false);
  });
});

describe('Fulfillment utils getSelectedValue()', () => {
  it('should return undefined when date is null', () => {
    expect(getSelectedValue(null, new Date())).to.eql(undefined);
  });

  it('should return given date when reference has the same month like date', () => {
    const mockDate = new Date('2019-10-11');
    const mockReference = new Date('2019-10-01');
    expect(getSelectedValue(mockDate, mockReference)).to.eql(mockDate);
  });

  it('should return undefined when reference does not have the same month', () => {
    const mockDate = new Date('2019-11-11');
    const mockReference = new Date('2019-10-01');
    expect(getSelectedValue(mockDate, mockReference)).to.eql(undefined);
  });

  it('should return undefined when reference has the same month like date but different year', () => {
    const mockDate = new Date('2019-11-11');
    const mockReference = new Date('2020-11-01');
    expect(getSelectedValue(mockDate, mockReference)).to.eql(undefined);
  });
});
