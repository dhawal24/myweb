import { expect } from 'chai';

import HttpError from 'utils/HttpError';

import {
  FETCH_DELIVERY_DATES_FAILURE,
  FETCH_DELIVERY_DATES_REQUEST,
  FETCH_DELIVERY_DATES_SUCCESS,
  SET_FULFILLMENT_DETAILS,
} from '../constants';
import * as actions from '../actions';

describe('Fulfillment Page actions test', () => {
  it('should create an action to set fulfillment details', () => {
    const mockFulfillment = {
      fulfillmentType: '',
      fulfillmentDate: '14-08-2019',
    };

    const expectedAction = {
      type: SET_FULFILLMENT_DETAILS,
      fulfillmentType: mockFulfillment.fulfillmentType,
      fulfillmentDate: mockFulfillment.fulfillmentDate,
    };
    expect(
      actions.setFulfillmentDetails(
        mockFulfillment.fulfillmentDate,
        mockFulfillment.fulfillmentType,
      ),
    ).to.eql(expectedAction);
  });

  it('should create an action for fulfillment delivery dates request and match params', () => {
    const requestParams = {
      productCode: '123',
      currencyISOCode: 'EUR',
      fulfillmentType: '2',
      partnerId: '1',
    };
    const expectedAction = {
      type: FETCH_DELIVERY_DATES_REQUEST,
      productCode: requestParams.productCode,
      currencyISOCode: requestParams.currencyISOCode,
      fulfillmentType: requestParams.fulfillmentType,
      partnerId: requestParams.partnerId,
    };
    expect(
      actions.fetchDeliveryDatesRequest(
        requestParams.productCode,
        requestParams.currencyISOCode,
        requestParams.fulfillmentType,
        requestParams.partnerId,
      ),
    ).to.eql(expectedAction);
  });

  it('should create an action for successful response of fulfillment delivery dates request and match dates', () => {
    const mockDeliveryDates = [{ date: '01-09-2019' }, { date: '01-09-2019' }];
    const expectedAction = {
      type: FETCH_DELIVERY_DATES_SUCCESS,
      deliveryDates: mockDeliveryDates,
    };
    expect(actions.fetchDeliveryDateSuccess(mockDeliveryDates)).to.eql(
      expectedAction,
    );
  });

  it('should create an action for failure response of fulfillment delivery dates request and provide the error', () => {
    const mockError = new HttpError('1', 'message');
    const expectedAction = {
      type: FETCH_DELIVERY_DATES_FAILURE,
      error: mockError,
    };
    expect(actions.fetchDeliveryDateFailure(mockError)).to.eql(expectedAction);
  });
});
