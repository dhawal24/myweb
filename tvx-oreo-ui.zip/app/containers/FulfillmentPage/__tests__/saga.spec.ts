import { expectSaga, testSaga } from 'redux-saga-test-plan';
import { call } from 'redux-saga-test-plan/matchers';

import HttpError from 'utils/HttpError';

import {
  fetchDeliveryDateFailure,
  fetchDeliveryDatesRequest,
  fetchDeliveryDateSuccess,
} from '../actions';
import fulfillmentSaga, { fetchFulfillmentDates } from '../saga';
import { FETCH_DELIVERY_DATES_REQUEST } from '../constants';
import { getDeliveryDates } from '../api';

describe('Fulfillment saga', () => {
  it('should dispatch request action', () => {
    expectSaga(fulfillmentSaga)
      .dispatch(fetchDeliveryDatesRequest('123', 'EUR', '123'))
      .run();
  });

  it('should take fetchFulfillment saga and provide appropriate action', () => {
    testSaga(fulfillmentSaga)
      .next()
      .takeLatest(FETCH_DELIVERY_DATES_REQUEST, fetchFulfillmentDates);
  });

  it('should provide an api response value for delivery dates call', () => {
    const mockRequestAction = {
      type: FETCH_DELIVERY_DATES_REQUEST,
      productCode: '1',
      currencyISOCode: '1',
      fulfillmentTyp: '1',
    };
    const apiResult = [{ date: '09.11.2019', message: '1' }];
    expectSaga(fetchFulfillmentDates, mockRequestAction)
      .provide([[call.fn(getDeliveryDates), apiResult]])
      .put(fetchDeliveryDateSuccess(apiResult))
      .run();
  });

  it('should dispatch failure action when api returns invalid value', () => {
    const mockRequestAction = {
      type: FETCH_DELIVERY_DATES_REQUEST,
      productCode: '1',
      currencyISOCode: '1',
      fulfillmentTyp: '1',
    };
    const apiResult = { error: '1' };
    expectSaga(fetchFulfillmentDates, mockRequestAction)
      .provide([[call.fn(getDeliveryDates), apiResult]])
      .dispatch(fetchDeliveryDateFailure(new HttpError('500', 'Server error')))
      .run();
  });
});
