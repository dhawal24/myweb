import React from 'react';
import { expect } from 'chai';
import { FormattedMessage, IntlProvider } from 'react-intl';
import { Box, Typography } from '@material-ui/core';
import { render } from '@testing-library/react';
import { Provider } from 'react-redux';
import { spy } from 'sinon';

import HttpError from 'utils/HttpError';

import FulfillmentPage, { getDeliveryDatesMessage } from '../index';
import messages from '../messages';
import store from '../../../store';

describe('<FulfillmentPage />', () => {
  it('should render and match the snapshot', () => {
    const next = spy();
    const {
      container: { firstChild },
    } = render(
      <Provider store={store}>
        <IntlProvider locale="en">
          <FulfillmentPage next={next} initialDate={new Date('2019-09-11')} />
        </IntlProvider>
      </Provider>,
    );
    expect(firstChild).to.matchSnapshot();
  });
});

describe('<FulfillmentPage /> getDeliveryDatesMessage()', () => {
  it('should return null when error is not present', () => {
    expect(getDeliveryDatesMessage()).to.eql(null);
  });

  it('should return match element with default error message when given error does not contain a message', () => {
    const expectedOutputWithDefaultMessage = (
      <Box p={2}>
        <Typography variant="h4" color="error">
          <FormattedMessage {...messages.error} />
        </Typography>
      </Box>
    );
    expect(getDeliveryDatesMessage(new HttpError('', ''))).to.eql(
      expectedOutputWithDefaultMessage,
    );
  });

  it('should return match element with default error message when given error does not contain a message', () => {
    const mockError: HttpError = new HttpError('1', 'message');
    const expectedOutputWithCustomMessage = (
      <Box p={2}>
        <Typography variant="h4" color="error">
          {mockError.message}
        </Typography>
      </Box>
    );
    expect(getDeliveryDatesMessage(mockError)).to.eql(
      expectedOutputWithCustomMessage,
    );
  });
});
