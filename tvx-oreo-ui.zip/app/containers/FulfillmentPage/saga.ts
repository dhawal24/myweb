import { call, put, takeLatest } from 'redux-saga/effects';
import { getType } from 'typesafe-actions';

import HttpError from 'utils/HttpError';

import {
  fetchDeliveryDateFailure,
  fetchDeliveryDatesRequest,
  fetchDeliveryDateSuccess,
} from './actions';
import { getDeliveryDates } from './api';

export function* fetchFulfillmentDates(action: any) {
  try {
    const deliveryDates = yield call(
      getDeliveryDates,
      action.productCode,
      action.currencyISOCode,
      action.fulfillmentType,
      action.partnerId,
    );
    if (deliveryDates instanceof Array) {
      yield put(fetchDeliveryDateSuccess(deliveryDates));
    } else {
      yield put(fetchDeliveryDateFailure(new HttpError('500', 'Server error')));
    }
  } catch (error) {
    yield put(fetchDeliveryDateFailure(error));
  }
}

export default function* fulfillmentSaga() {
  yield takeLatest(getType(fetchDeliveryDatesRequest), fetchFulfillmentDates);
}
