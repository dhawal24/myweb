import { makeStyles, Theme } from '@material-ui/core';
import { StyleRules } from '@material-ui/core/styles';

export const useCalendarStyles = makeStyles(
  (theme: Theme): StyleRules => ({
    calendarBox: {
      width: '100%',
      position: 'relative',
      padding: theme.spacing(0.5, 5, 0),
      display: 'flex',
      flexDirection: 'row',
      [theme.breakpoints.down('sm')]: {
        flexDirection: 'column',
      },
    },
    calendarHeader: {
      width: '100%',
      minHeight: 100,
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      padding: theme.spacing(2, 5),
      backgroundColor: theme.palette.primary.main,
      borderRadius: `${theme.shape.borderRadius}px ${theme.shape.borderRadius}px 0 0`,
      color: theme.palette.primary.contrastText,
      '& > h6': {
        opacity: 0.75,
      },
    },
    calendarControls: {
      width: '100%',
      display: 'flex',
      justifyContent: 'space-between',
      flexDirection: 'row',
      position: 'absolute',
      top: '50%',
      left: '0',
      transform: 'translateY(-50%)',
      padding: theme.spacing(0, 0.5),
    },
    styledCalendar: {
      minHeight: 375,
      margin: theme.spacing(0, 2),
      [theme.breakpoints.down('sm')]: {
        margin: theme.spacing(0, 0),
      },
      border: 'none !important',
      background: theme.palette.background.paper,
      fontFamily: theme.typography.fontFamily,
      '& button': {
        ...theme.typography.button,
        '&:disabled': {
          color: theme.palette.text.disabled,
        },
      },
      '& .react-calendar__navigation': {
        marginBottom: theme.spacing(1),
        borderBottom: `1px solid ${theme.palette.background.default}`,
        '& button': {
          '&.react-calendar__navigation__label': {
            backgroundColor: 'transparent',
            textTransform: 'capitalize',
            color: theme.palette.text.primary,
          },
          '&.react-calendar__navigation__arrow': {
            display: 'none',
          },
        },
      },
      '& .react-calendar__month-view__weekdays': {
        ...theme.typography.caption,
        fontWeight: 'bold',
        '& abbr[title]': {
          textDecoration: 'none',
          textTransform: 'capitalize',
          color: theme.palette.text.secondary,
        },
      },
      '& .react-calendar__tile': {
        padding: theme.spacing(1.5, 0.5),
        '&:disabled': {
          backgroundColor: 'transparent',
        },
        '&:enabled': {
          position: 'relative',
          backgroundColor: 'transparent',
          zIndex: 0,
          color: theme.palette.primary.main,
          fontWeight: 'bold',
          '& abbr': {
            position: 'relative',
            zIndex: 2,
          },
          '&:before': {
            content: '""',
            position: 'absolute',
            zIndex: 1,
            display: 'block',
            margin: 'auto',
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            width: theme.spacing(5.4),
            height: theme.spacing(5.4),
            borderRadius: '100%',
            border: `2px solid ${theme.palette.primary.light}`,
            backgroundColor: 'transparent',
            transition: theme.transitions.create(
              ['border-color', 'background-color'],
              { duration: theme.transitions.duration.short },
            ),
          },
          '&:hover': {
            backgroundColor: 'transparent',
            color: theme.palette.primary.dark,
            '&:before': {
              backgroundColor: theme.palette.primary.light,
            },
          },
          '&:focus': {
            backgroundColor: 'transparent !important',
            '&:before': {
              borderColor: theme.palette.primary.main,
            },
          },
          '&.react-calendar__tile--active': {
            backgroundColor: 'transparent !important',
            color: theme.palette.primary.contrastText,
            '&:hover': {
              backgroundColor: 'transparent !important',
              '&:before': {
                backgroundColor: theme.palette.primary.main,
              },
            },
            '&:focus:before': {
              borderColor: theme.palette.primary.dark,
            },
            '&:before': {
              borderColor: theme.palette.primary.main,
              backgroundColor: theme.palette.primary.main,
            },
          },
        },
      },
    },
  }),
);
