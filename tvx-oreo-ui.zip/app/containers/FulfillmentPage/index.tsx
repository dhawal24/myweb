import React, { ReactElement, ReactNode, useEffect, useState } from 'react';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import {
  Box,
  Checkbox,
  CircularProgress,
  FormControlLabel,
  IconButton,
  Paper,
  Typography,
} from '@material-ui/core';
import { format } from 'date-fns';
import Calendar, { CalendarTileProperties } from 'react-calendar';
import { ChevronLeft, ChevronRight } from '@material-ui/icons';

import { SagaInjectorMode } from 'utils/constants';
import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import HttpError from 'utils/HttpError';

import { RootState } from '../../store';
import { selectCurrencyCode } from '../ProductPage/selectors';
import { FlowStepperActions } from '../../components/FlowStepper/types';
import StepperControls from '../../components/StepperControls';

import { fetchDeliveryDatesRequest, setFulfillmentDetails } from './actions';
import {
  selectDeliveryDates,
  selectDeliveryDatesError,
  selectFulfillmentDate,
  selectFulfillmentType,
  selectIsLoading,
  selectRange,
} from './selectors';
import messages from './messages';
import fulfillmentSaga from './saga';
import fulfillmentReducer from './reducer';
import { RangeType } from './types';
import { API_DATE_FORMAT, existsInDates, getSelectedValue } from './utils';
import { useCalendarStyles } from './FulfillmentPageStyles';

interface StateProps {
  error: HttpError | null;
  fulfillmentType: string;
  fulfillmentDate: Date | null;
  currencyCode: string;
  range: RangeType;
  deliveryDates: Readonly<Array<Date>>;
  isLoading: boolean;
}

interface DispatchProps {
  fetchDeliveryDatesRequest: (
    productCode: string,
    currencyISOCode: string,
    fulfillmentType: string,
    partnerId?: string,
  ) => void;
  setFulfillmentDetails: (
    fulfillmentDate: string,
    fulfillmentType: string,
  ) => void;
}

interface OwnProps extends FlowStepperActions {
  initialDate?: Date;
}

interface Props extends StateProps, DispatchProps, OwnProps {}

function getCalendarReferenceDates(initialDate?: Date) {
  const startDate = initialDate || new Date();
  const nextDate = new Date(startDate);
  nextDate.setMonth(startDate.getMonth() + 1, 1);
  return { startDate, nextDate };
}

export const FulfillmentPage: React.FC<Props> = (props: Props) => {
  const classes = useCalendarStyles();
  const { range, deliveryDates, isLoading } = props;
  const { startDate, nextDate } = getCalendarReferenceDates(props.initialDate);

  const [firstReference, setFirstReference] = useState(startDate);
  const [secondReference, setSecondReference] = useState(nextDate);
  const [fulfillmentType] = useState('Home Delivery');
  const [selectedDate, setSelectedDate] = useState<Date>(
    props.fulfillmentDate ? props.fulfillmentDate : range.minDate,
  );
  const deliveryDatesErrorMessage = getDeliveryDatesMessage(
    props.error as HttpError,
  );

  useInjectSaga({
    key: 'fulfillmentSaga',
    saga: fulfillmentSaga,
    mode: SagaInjectorMode.RestartOnRemount,
  });
  useInjectReducer({
    key: 'fulfillmentDetails',
    reducer: fulfillmentReducer,
  });

  useEffect(() => {
    const currencyCode = props.currencyCode ? props.currencyCode : 'EUR';
    props.fetchDeliveryDatesRequest('12345', currencyCode, '55', '12');
  }, [fulfillmentType]);

  const handleSubmit = () => {
    if (selectedDate) {
      props.setFulfillmentDetails(
        format(selectedDate, API_DATE_FORMAT),
        fulfillmentType,
      );
      props.next();
    }
  };

  const handleMonthChange = (inc: number) => {
    setFirstReference(
      new Date(firstReference.setMonth(firstReference.getMonth() + inc, 1)),
    );
    setSecondReference(
      new Date(secondReference.setMonth(secondReference.getMonth() + inc, 1)),
    );
  };

  if (isLoading) {
    return <CircularProgress />;
  }

  if (deliveryDatesErrorMessage) {
    return deliveryDatesErrorMessage;
  }

  if (!range) {
    return getDeliveryDatesMessage({} as HttpError);
  }

  const buildCalendar = (refDate: Date): ReactNode => (
    <Calendar
      activeStartDate={refDate}
      className={classes.styledCalendar}
      showNeighboringMonth={false}
      prev2Label={null}
      next2Label={null}
      minDetail="month"
      value={getSelectedValue(selectedDate, refDate)}
      onChange={date => {
        setSelectedDate(date instanceof Date ? date : date[0]);
      }}
      tileDisabled={(tile: CalendarTileProperties) =>
        !existsInDates(tile.date, deliveryDates)
      }
    />
  );

  return (
    <Box
      display="flex"
      flexDirection="column"
      justifyContent="center"
      alignItems="center"
      p={2}
    >
      <Typography variant="h5">
        <FormattedMessage {...messages.title} />
      </Typography>
      <Box py={2}>
        <FormControlLabel
          control={<Checkbox checked color="primary" readOnly />}
          label={<FormattedMessage {...messages.homeDeliveryLabel} />}
        />
      </Box>
      <Paper>
        <Box className={classes.calendarHeader}>
          <Typography variant="subtitle1">
            {selectedDate ? format(selectedDate, 'yyyy') : ''}
          </Typography>
          <Typography variant="h4">
            {selectedDate ? (
              format(selectedDate, 'EEEE, LLL d')
            ) : (
              <FormattedMessage {...messages.noSelectedValue} />
            )}
          </Typography>
        </Box>
        <Box className={classes.calendarBox}>
          <Box className={classes.calendarControls}>
            <IconButton onClick={() => handleMonthChange(-1)}>
              <ChevronLeft />
            </IconButton>
            <IconButton onClick={() => handleMonthChange(1)}>
              <ChevronRight />
            </IconButton>
          </Box>
          {buildCalendar(firstReference)}
          {buildCalendar(secondReference)}
        </Box>
        <Box p={3} pt={0}>
          <StepperControls
            isNextDisabled={!selectedDate}
            onClickBack={props.back}
            onClickNext={handleSubmit}
          />
        </Box>
      </Paper>
    </Box>
  );
};

/**
 * Gets the error message from the error object as a ReactElement
 * IF error does not exists a null value will be provided
 * @param error - a HttpError with message
 */
export const getDeliveryDatesMessage = (
  error?: HttpError,
): ReactElement | null => {
  if (!error) {
    return null;
  }
  const message = error.message ? error.message : null;
  return (
    <Box p={2}>
      <Typography variant="h4" color="error">
        {message || <FormattedMessage {...messages.error} />}
      </Typography>
    </Box>
  );
};

const mapStateToProps = createStructuredSelector<RootState, StateProps>({
  error: selectDeliveryDatesError,
  isLoading: selectIsLoading,
  fulfillmentType: selectFulfillmentType,
  fulfillmentDate: selectFulfillmentDate,
  currencyCode: selectCurrencyCode,
  range: selectRange,
  deliveryDates: selectDeliveryDates,
});

const mapDispatchToProps = {
  setFulfillmentDetails,
  fetchDeliveryDatesRequest,
};

const withConnect = connect<StateProps, DispatchProps, OwnProps>(
  mapStateToProps,
  mapDispatchToProps,
);

export default withConnect(FulfillmentPage);
