import { createSelector } from 'reselect';
import { parse } from 'date-fns';

import { RootState } from '../../store';

import { initialState } from './reducer';
import { API_DATE_FORMAT, getRange, mapDates } from './utils';

export const selectFulfillmentDetails = (state: RootState) =>
  state.fulfillmentDetails || initialState;

export const selectDeliveryDatesError = createSelector(
  selectFulfillmentDetails,
  state => state.error,
);

export const selectIsLoading = createSelector(
  selectFulfillmentDetails,
  state => state.isLoading,
);

export const selectFulfillmentType = createSelector(
  selectFulfillmentDetails,
  state => state.fulfillmentType,
);

export const selectFulfillmentDate = createSelector(
  selectFulfillmentDetails,
  state =>
    state.fulfillmentDate
      ? parse(state.fulfillmentDate, API_DATE_FORMAT, new Date())
      : null,
);

export const selectRange = createSelector(
  selectFulfillmentDetails,
  state => {
    const deliveryDatesMap = mapDates(state.deliveryDates);
    return getRange(deliveryDatesMap);
  },
);

export const selectDeliveryDates = createSelector(
  selectFulfillmentDetails,
  state => mapDates(state.deliveryDates),
);
