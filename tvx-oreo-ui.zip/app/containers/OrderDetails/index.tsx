import React, { useState } from 'react';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import {
  Box,
  Checkbox,
  Divider,
  FormControlLabel,
  Table,
  TableBody,
  TableCell,
  TableFooter,
  TableHead,
  TableRow,
  Typography,
} from '@material-ui/core';

import Container from 'components/Container';
import { PersonalDetailsType } from 'containers/PersonalDetails/types';
import { ProductDetailsType } from 'containers/ProductPage/types';
import { FulfillmentType } from 'containers/FulfillmentPage/types';
import { FlowStepperActions } from 'components/FlowStepper/types';
import StepperControls from 'components/StepperControls';

import { RootState } from '../../store';

import messages from './messages';
import { useOrderDetailStyles } from './OrderDetailsStyles';

interface StateProps {
  personalDetails: PersonalDetailsType;
  productDetails: ProductDetailsType;
  fulfillmentDetails: FulfillmentType;
}

interface Props extends StateProps, FlowStepperActions {}

export const OrderDetails: React.FC<Props> = props => {
  const [isChecked, setIsChecked] = useState(false);
  const classes = useOrderDetailStyles();
  const handleSubmit = () => {
    props.next();
  };

  const { personalDetails, productDetails, fulfillmentDetails } = props;
  const convertedAmount =
    productDetails.amount &&
    productDetails.exchangeRate &&
    (productDetails.amount * productDetails.exchangeRate).toFixed(2);

  return (
    <Container mx="auto" py={2} px={1} logo>
      <Box width={550} pb={2}>
        <Box px={2}>
          <Typography variant="h5" gutterBottom>
            <FormattedMessage {...messages.header} />
          </Typography>
        </Box>
        <Divider orientation="horizontal" variant="fullWidth" />
        <Box>
          <Box px={2}>
            {createDetailsHeader(<FormattedMessage {...messages.yourBasket} />)}
          </Box>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>
                  <FormattedMessage {...messages.currency} />
                </TableCell>
                <TableCell align="right">
                  <FormattedMessage {...messages.foreignAmount} />
                </TableCell>
                <TableCell align="right">
                  <FormattedMessage {...messages.toPay} />
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              <TableRow>
                <TableCell>{productDetails.currencyCode}</TableCell>
                <TableCell align="right">
                  {productDetails.amount} {productDetails.currencyCode}
                </TableCell>
                <TableCell align="right">{convertedAmount} GBP</TableCell>
              </TableRow>
              <TableRow>
                <TableCell colSpan={2}>
                  <Box fontWeight="bold">
                    <FormattedMessage {...messages.rate} />
                  </Box>
                </TableCell>
                <TableCell align="right">
                  <Box fontWeight="bold">{productDetails.exchangeRate}</Box>
                </TableCell>
              </TableRow>
            </TableBody>
            <TableFooter className={classes.tableFooter}>
              <TableRow>
                <TableCell colSpan={2}>
                  <Typography variant="inherit">
                    <FormattedMessage {...messages.total} />
                  </Typography>
                </TableCell>
                <TableCell align="right">
                  <Typography variant="inherit">
                    {`${convertedAmount} GBP`}
                  </Typography>
                </TableCell>
              </TableRow>
            </TableFooter>
          </Table>
          <Box px={2} pb={0.5}>
            {createDetailsHeader(
              <FormattedMessage {...messages.deliveryDetails} />,
            )}
            {createDetailsRow(
              <FormattedMessage {...messages.deliveryDate} />,
              fulfillmentDetails.fulfillmentDate,
            )}
            {createDetailsRow(
              <FormattedMessage {...messages.deliveryDetails} />,
              personalDetails.address1,
              personalDetails.address2,
              personalDetails.city,
              personalDetails.county,
              personalDetails.postCode,
            )}
          </Box>
          <Divider orientation="horizontal" variant="fullWidth" />
          <Box px={2} pb={0.5}>
            {createDetailsHeader(
              <FormattedMessage {...messages.personalDetails} />,
            )}
            {createDetailsRow(
              <FormattedMessage {...messages.name} />,
              personalDetails.firstName,
              personalDetails.lastName,
            )}
            {createDetailsRow(
              <FormattedMessage {...messages.email} />,
              personalDetails.email,
            )}
            {createDetailsRow(
              <FormattedMessage {...messages.mobileNumber} />,
              personalDetails.mobileNumber,
            )}
          </Box>
          <Divider orientation="horizontal" variant="fullWidth" />
        </Box>
        <Box mt={1} px={2}>
          <FormControlLabel
            control={
              <Checkbox
                value={isChecked}
                checked={isChecked}
                onChange={() => setIsChecked(!isChecked)}
                color="primary"
              />
            }
            label={<FormattedMessage {...messages.termsAndConditions} />}
          />
        </Box>
        <Box px={3} pb={2}>
          <StepperControls
            isNextDisabled={!isChecked}
            onClickNext={handleSubmit}
            onClickBack={props.back}
          />
        </Box>
      </Box>
    </Container>
  );
};

const createDetailsHeader = (label: JSX.Element) => (
  <Box pt={1}>
    <Typography variant="h6">{label}</Typography>
  </Box>
);

const createDetailsRow = (
  label: JSX.Element,
  ...values: Array<string | number | null>
) => (
  <Box py={1} width="100%" display="flex">
    <Box flexGrow={1} flexShrink={0} fontWeight="500">
      <Typography display="inline" variant="inherit">
        {label}
      </Typography>
    </Box>
    <Box textAlign="right">
      <Typography display="inline" variant="inherit">
        {values.map(value => `${value} `)}
      </Typography>
    </Box>
  </Box>
);

const mapStateToProps = (state: RootState) => ({
  personalDetails: state.personalDetails,
  productDetails: state.productDetails,
  fulfillmentDetails: state.fulfillmentDetails,
});

const withConnect = connect<StateProps, {}, FlowStepperActions>(
  mapStateToProps,
);

export default withConnect(OrderDetails);
