import { makeStyles, Theme } from '@material-ui/core';
import { StyleRules } from '@material-ui/core/styles';

export const useOrderDetailStyles = makeStyles(
  (theme: Theme): StyleRules => ({
    tableFooter: {
      backgroundColor: theme.palette.background.default,
      '& span': {
        ...theme.typography.body1,
        fontWeight: 'bold',
        color: theme.palette.text.primary,
      },
    },
  }),
);
