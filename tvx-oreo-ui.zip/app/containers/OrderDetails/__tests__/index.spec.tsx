import React from 'react';
import { render } from '@testing-library/react';
import { expect } from 'chai';
import { Provider } from 'react-redux';
import { IntlProvider } from 'react-intl';
import { spy } from 'sinon';

import { OrderDetails } from '../index';
import store from '../../../store';

describe('<OrderDetails />', () => {
  it('should render and match the snapshot', () => {
    const next = spy();
    const {
      container: { firstChild },
    } = render(
      <Provider store={store}>
        <IntlProvider locale="en">
          <OrderDetails
            next={next}
            productDetails={{
              currencyCode: 'CAD',
              amount: 8484848,
              exchangeRate: 1.63633,
            }}
            fulfillmentDetails={{
              fulfillmentType: 'Home Delivery',
              fulfillmentDate: '2019-09-02',
            }}
            personalDetails={{
              firstName: 'asd',
              lastName: 'dw',
              mobileNumber: 'dw',
              email: 'd',
              address1: 'd',
              address2: 'wd',
              city: 'dd',
              county: 'Cleveland',
              postCode: 'dwq',
              birthDate: '22/1/1990',
            }}
          />
        </IntlProvider>
      </Provider>,
    );
    expect(firstChild).to.matchSnapshot();
  });
});
