/*
 *
 * LanguageProvider actions
 *
 */

import { createCustomAction } from 'typesafe-actions';

import { CHANGE_LOCALE } from './constants';

export const changeLocale = createCustomAction(
  CHANGE_LOCALE,
  type => (locale: string) => ({ type, locale }),
);
