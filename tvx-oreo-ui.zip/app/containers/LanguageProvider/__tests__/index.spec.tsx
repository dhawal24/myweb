import React from 'react';
import { render } from '@testing-library/react';
import { FormattedMessage, defineMessages } from 'react-intl';
import { Provider } from 'react-redux';
import { expect } from 'chai';

import store from '../../../store';
import { translationMessages } from '../../../i18n';
import ConnectedLanguageProvider, { LanguageProvider } from '../index';

const defaultMessage = 'This is some default message';
const messages = defineMessages({
  someMessage: {
    id: 'some.id',
    defaultMessage,
  },
});

describe('<LanguageProvider />', () => {
  it('should render its children', () => {
    const children = <h1>Test</h1>;
    const {
      container: { firstChild },
    } = render(
      <LanguageProvider messages={messages} locale="en">
        {children}
      </LanguageProvider>,
    );
    expect(firstChild).to.matchSnapshot();
  });
});

describe('<ConnectedLanguageProvider />', () => {
  it('should render the default language messages', () => {
    const { queryByText } = render(
      <Provider store={store}>
        <ConnectedLanguageProvider messages={translationMessages}>
          <FormattedMessage {...messages.someMessage} />
        </ConnectedLanguageProvider>
      </Provider>,
    );
    expect(queryByText(defaultMessage)).to.matchSnapshot();
  });
});
