import { expect } from 'chai';

import languageProviderReducer from '../reducer';
import { CHANGE_LOCALE } from '../constants';

const LOCALE = 'en';

/* eslint-disable default-case, no-param-reassign */
describe('languageProviderReducer', () => {
  it('returns the initial state', () => {
    expect(languageProviderReducer(undefined, {})).to.eql({ locale: LOCALE });
  });

  it('changes the locale', () => {
    expect(
      languageProviderReducer(undefined, {
        type: CHANGE_LOCALE,
        locale: LOCALE,
      }),
    ).to.eql({ locale: LOCALE });
  });
});
