/**
 * Create the store with dynamic reducers
 */

import { applyMiddleware, compose, createStore } from 'redux';
import { routerMiddleware } from 'connected-react-router';
import createSagaMiddleware from 'redux-saga';
import { StateType } from 'typesafe-actions';

import history from 'utils/history';

import ratesPageReducer from '../containers/RatesPage/reducer';
import fulfillmentReducer from '../containers/FulfillmentPage/reducer';
import productDetailsReducer from '../containers/ProductPage/reducer';
import confirmPaymentReducer from '../containers/ConfirmPayment/reducer';

import createReducer from './reducers';

const rootReducers = createReducer();

// Define store types
// export type RootAction = ActionType<typeof import('./actions').default>;
export type RootState = Partial<
  StateType<
    typeof rootReducers &
      typeof ratesPageReducer &
      typeof fulfillmentReducer &
      typeof productDetailsReducer &
      typeof confirmPaymentReducer
  >
>;

let composeEnhancers = compose;
const reduxSagaMonitorOptions = {};

// If Redux Dev Tools and Saga Dev Tools Extensions are installed, enable them
/* istanbul ignore next */
if (process.env.NODE_ENV !== 'production' && typeof window === 'object') {
  /* eslint-disable no-underscore-dangle */
  if (window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__)
    composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__({});

  // NOTE: Uncomment the code below to restore support for Redux Saga
  // Dev Tools once it supports redux-saga version 1.x.x
  // if (global.__SAGA_MONITOR_EXTENSION__)
  //   reduxSagaMonitorOptions = {
  //     sagaMonitor: global.__SAGA_MONITOR_EXTENSION__,
  //   };
  /* eslint-enable */
}

const sagaMiddleware = createSagaMiddleware(reduxSagaMonitorOptions);

// Create the store with two middlewares
// 1. sagaMiddleware: Makes redux-sagas work
// 2. routerMiddleware: Syncs the location/URL path to the state
const middlewares = [sagaMiddleware, routerMiddleware(history)];

const enhancers = [applyMiddleware(...middlewares)];

const initialState = {};

const store = createStore(
  rootReducers,
  initialState,
  composeEnhancers(...enhancers),
);

// Extensions
store.runSaga = sagaMiddleware.run;
store.injectedReducers = {}; // Reducer registry
store.injectedSagas = {}; // Saga registry

// Make reducers hot reloadable, see http://mxs.is/googmo
/* istanbul ignore next */
if (module.hot) {
  module.hot.accept('./reducers', () => {
    store.replaceReducer(createReducer(store.injectedReducers));
  });
}

export default store;
