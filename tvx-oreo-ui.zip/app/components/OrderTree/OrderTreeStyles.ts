import { makeStyles, Theme } from '@material-ui/core';
import { StyleRules } from '@material-ui/core/styles';

export const useOrderTreeStyles = makeStyles(
  (theme: Theme): StyleRules => ({
    arrow: {
      cursor: 'pointer',
      opacity: 0.8,
      transform: 'rotate(0deg)',
      transition: theme.transitions.create(['transform', 'hover'], {
        duration: theme.transitions.duration.short,
      }),
      '&:hover': {
        opacity: 1,
      },
    },
    arrowRotate: {
      transform: 'rotate(90deg)',
    },
  }),
);
