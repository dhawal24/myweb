import React from 'react';
import { render } from '@testing-library/react';
import { expect } from 'chai';
import { IntlProvider } from 'react-intl';

import messages from 'containers/ViewOrder/messages';

import OrderItem from '../index';
const input = [
  {
    'GB-0000000000112': {
      orderStatus: 'Scheduled',
      domCurrTotalOrdAmt: 5,
      orderChannel: 'Web',
      basket: [
        {
          label: 'basketId',
          value: 0,
          data: {
            domCurrAmt: 458,
            foreignCurrAmt: 25.2,
            foreignCurrISOCode: 'USD',
            productType: 'Prod',
            rateDenom: 'test',
            exchangeRate: 2.2,
            spotRate: 2.1,
            rateType: 'Indirect',
          },
        },
      ],
      fulfillment: {
        fulfillmentDate: '2020-01-01T00:00:00.000Z',
        fulfillmentType: 'Home Delivery',
      },
    },
  },
];

describe('<OrderItem />', () => {
  it('Should render and match the snapshot and render the entire list', () => {
    const {
      container: { firstChild },
    } = render(
      <IntlProvider locale="en">
        <OrderItem
          data={input}
          itemKey="GB-0000000000112"
          messages={messages}
          root
        />
      </IntlProvider>,
    );
    expect(firstChild).to.matchSnapshot();
  });

  it('Should render and match the snapshot and render the basket array', () => {
    const partialInput = {
      basket: [
        {
          label: 'basketId',
          value: 0,
          data: {
            domCurrAmt: 458,
            foreignCurrAmt: 25.2,
            foreignCurrISOCode: 'USD',
            productType: 'Prod',
            rateDenom: 'test',
            exchangeRate: 2.2,
            spotRate: 2.1,
            rateType: 'Indirect',
          },
        },
      ],
    };
    const {
      container: { firstChild },
    } = render(
      <IntlProvider locale="en">
        <OrderItem data={partialInput} itemKey="basket" messages={messages} />
      </IntlProvider>,
    );
    expect(firstChild).to.matchSnapshot();
  });

  it('Should render and match the snapshot and render the single item with the specific key', () => {
    const partialInput = { orderStatus: 'Scheduled' };
    const {
      container: { firstChild },
    } = render(
      <IntlProvider locale="en">
        <OrderItem
          data={partialInput}
          itemKey="orderStatus"
          messages={messages}
        />
      </IntlProvider>,
    );
    expect(firstChild).to.matchSnapshot();
  });

  it('Should render and match the snapshot and render the error item', () => {
    const expectedOutput = [
      {
        'GB-0000000001131': {
          error:
            'Unable to retrieve the Order information for GB-0000000001131',
        },
      },
    ];

    const {
      container: { firstChild },
    } = render(
      <IntlProvider locale="en">
        <OrderItem
          data={expectedOutput}
          itemKey="orderStatus"
          messages={messages}
        />
      </IntlProvider>,
    );
    expect(firstChild).to.matchSnapshot();
  });
});
