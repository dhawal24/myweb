import React from 'react';
import { FormattedMessage, Messages } from 'react-intl';
import { Box, Typography } from '@material-ui/core';
import clsx from 'clsx';
import { KeyboardArrowRight } from '@material-ui/icons';

import { useOrderTreeStyles } from './OrderTreeStyles';

interface Props {
  data: any;
  itemKey: string;
  inArray?: boolean;
  root?: boolean;
  hasChildren?: boolean;
  messages: Messages;
  isError?: boolean;
}

const OrderTree: React.FC<Props> = ({
  data,
  itemKey,
  inArray,
  isError,
  root,
  hasChildren,
  messages,
}) => {
  const classes = useOrderTreeStyles();
  const [isCollapsed, setIsCollapsed] = React.useState(root);
  const toggleFunction = () => setIsCollapsed(!isCollapsed);
  const toggler = (
    <KeyboardArrowRight
      fontSize="small"
      color="action"
      onClick={toggleFunction}
      className={clsx(classes.arrow, !isCollapsed && classes.arrowRotate)}
    />
  );

  let renderedItem;
  const itemData = inArray ? data.data : data;
  if (Array.isArray(itemData)) {
    renderedItem = [
      <Box
        className="group-parent"
        key={`group-parent-${itemKey}`}
        display="flex"
        flexDirection="row"
      >
        {toggler}
        <Typography variant="subtitle2">
          {messages[itemKey] ? (
            <FormattedMessage {...messages[itemKey]} />
          ) : (
            itemKey
          )}
        </Typography>
      </Box>,
      !isCollapsed && (
        <Box ml={3} key={itemKey}>
          {itemData.map((item, index) => (
            <OrderTree
              key={`${itemKey}-${index}`}
              data={item}
              itemKey={itemKey}
              inArray
              messages={messages}
            />
          ))}
        </Box>
      ),
    ];
  } else {
    let boxContent;
    if (itemData instanceof Object) {
      boxContent = (
        <Box ml={3}>
          {Object.keys(itemData).map(dataKey => (
            <Box key={dataKey}>
              <OrderTree
                isError={dataKey === 'error'}
                data={itemData[dataKey]}
                itemKey={dataKey}
                hasChildren={itemData[dataKey] instanceof Object}
                messages={messages}
              />
            </Box>
          ))}
        </Box>
      );
    } else {
      boxContent = `: ${itemData}`;
    }
    let keyContent;

    if (root) {
      keyContent = (
        <Box display="flex" alignItems="center">
          {toggler}
          <Typography variant="button">{itemKey}</Typography>
        </Box>
      );
    } else if (messages[itemKey]) {
      keyContent = <FormattedMessage {...messages[itemKey]} />;
    } else {
      keyContent = itemKey;
    }

    keyContent = hasChildren ? (
      <Box display="flex" alignItems="center">
        {toggler}
        <Typography variant="subtitle2">
          {messages[itemKey] && <FormattedMessage {...messages[itemKey]} />}
        </Typography>
      </Box>
    ) : (
      keyContent
    );

    renderedItem = (
      <Box
        display="flex"
        flexDirection={!(root || hasChildren || inArray) ? 'row' : 'column'}
        color={isError ? 'error' : ''}
      >
        {inArray ? (
          <Box display="flex" alignItems="center">
            {toggler}
            <Typography variant="subtitle2">
              {messages[data.label] ? (
                <FormattedMessage {...messages[data.label]} />
              ) : (
                data.label
              )}{' '}
              {`: ${data.value}`}
            </Typography>
          </Box>
        ) : (
          keyContent
        )}
        {!isCollapsed && boxContent}
      </Box>
    );
  }

  return <>{renderedItem}</>;
};

export default OrderTree;
