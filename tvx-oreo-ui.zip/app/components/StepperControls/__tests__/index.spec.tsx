import React from 'react';
import { expect } from 'chai';
import { render } from '@testing-library/react';

import StepperControls from '../index';

describe('<StepperControls />', () => {
  it('should render and match snapshot', () => {
    const {
      container: { firstChild },
    } = render(<StepperControls />);
    expect(firstChild).to.matchSnapshot();
  });
});
