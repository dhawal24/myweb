import React, { FC } from 'react';
import { Box, Button } from '@material-ui/core';

export interface Props {
  nextMessage?: string;
  backMessage?: string;
  onClickNext?: () => void;
  onClickBack?: () => void;
  isNextDisabled?: boolean;
  isBackDisabled?: boolean;
  isNextHidden?: boolean;
  isBackHidden?: boolean;
}

const StepperControls: FC<Props> = (props: Props) => (
  <Box width="100%" pt={3} display="flex" justifyContent="flex-end">
    {!props.isBackHidden && (
      <Box px={1}>
        <Button disabled={props.isBackDisabled} onClick={props.onClickBack}>
          {props.backMessage || 'Back'}
        </Button>
      </Box>
    )}
    {!props.isNextHidden && (
      <Box px={1}>
        <Button
          hidden={props.isNextHidden}
          disabled={props.isNextDisabled}
          variant="contained"
          color="primary"
          onClick={props.onClickNext}
        >
          {props.nextMessage || 'Next'}
        </Button>
      </Box>
    )}
  </Box>
);

export default StepperControls;
