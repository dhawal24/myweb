import React, { ReactNode } from 'react';
import { Box, Paper } from '@material-ui/core';
import { BoxProps } from '@material-ui/core/Box';

export interface Props {
  children?: ReactNode;
  logo?: boolean;
  cardSpacing?: number;
}

const Container: React.FC<Props & BoxProps> = ({
  logo,
  children,
  cardSpacing,
  ...boxProps
}) => (
  <Box {...boxProps}>
    <Paper elevation={4}>
      {logo && (
        <Box width="100%" p={2}>
          <Box width={50}>
            <img
              src="https://i.pinimg.com/originals/90/4f/ce/904fce606315b5b0de0b83cd0cfe9a6d.jpg"
              alt="Logo"
              width="100%"
            />
          </Box>
        </Box>
      )}
      <Box p={cardSpacing}>{children}</Box>
    </Paper>
  </Box>
);

export default Container;
