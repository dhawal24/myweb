import React from 'react';
import { render } from '@testing-library/react';
import { expect } from 'chai';

import Container from '../index';

describe('<Container />', () => {
  it('Should render and match the snapshot', () => {
    const {
      container: { firstChild },
    } = render(<Container />);
    expect(firstChild).to.matchSnapshot();
  });
});
