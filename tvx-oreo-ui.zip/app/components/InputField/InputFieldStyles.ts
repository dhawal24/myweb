import { makeStyles, Theme } from '@material-ui/core';
import { StyleRules } from '@material-ui/core/styles';

const useInputFieldStyles = makeStyles(
  (theme: Theme): StyleRules => ({
    input: {
      '& > div': {
        overflow: 'hidden',
        '&:before': {
          content: 'none',
        },
      },
      '& p': {
        paddingLeft: theme.spacing(1),
        marginTop: theme.spacing(0.5),
      },
    },
    inputField: {
      background: theme.palette.background.default,
      paddingLeft: theme.spacing(1),
      paddingRight: theme.spacing(1),
      borderRadius: theme.shape.borderRadius,
    },
    inputLabel: {
      zIndex: 1,
      paddingLeft: theme.spacing(1),
    },
  }),
);

export default useInputFieldStyles;
