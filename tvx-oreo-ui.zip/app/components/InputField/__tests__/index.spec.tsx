import React from 'react';
import { render } from '@testing-library/react';
import { expect } from 'chai';

import InputField from '../index';

describe('<InputField />', () => {
  it('Should render and match the snapshot', () => {
    const {
      container: { firstChild },
    } = render(<InputField id="firstName" name="firstName" type="text" />);
    expect(firstChild).to.matchSnapshot();
  });
});
