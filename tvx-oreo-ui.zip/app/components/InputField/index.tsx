import React from 'react';
import { TextField } from '@material-ui/core';
import { TextFieldProps } from '@material-ui/core/TextField';

import useInputFieldStyles from './InputFieldStyles';

const InputField: React.FC<TextFieldProps> = (props: TextFieldProps) => {
  const classes = useInputFieldStyles();
  return (
    <TextField
      className={classes.input}
      InputLabelProps={{
        className: classes.inputLabel,
      }}
      InputProps={{
        inputProps: { className: classes.inputField },
      }}
      {...props}
    />
  );
};

export default InputField;
