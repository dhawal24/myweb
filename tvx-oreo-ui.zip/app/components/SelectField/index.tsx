import React, { ReactNode } from 'react';
import { SelectProps } from '@material-ui/core/Select';
import {
  FilledInput,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
} from '@material-ui/core';

import useSelectFieldStyles from './SelectFieldStyles';

export interface SelectFieldOptionsType {
  key: string;
  value?: string;
}

interface Props extends SelectProps {
  id: string;
  options: Array<SelectFieldOptionsType>;
  helperText?: string;
  label?: ReactNode;
}

const SelectField: React.FC<Props> = ({
  id,
  options,
  label,
  ...selectProps
}) => {
  const classes = useSelectFieldStyles();
  return (
    <FormControl
      classes={{ fullWidth: classes.input }}
      required={selectProps.required}
      fullWidth
    >
      <InputLabel
        error={selectProps.error}
        htmlFor={id}
        className={classes.inputLabel}
      >
        {label}
      </InputLabel>
      <Select
        {...selectProps}
        inputProps={{
          id,
          name: selectProps.name,
        }}
        input={
          <FilledInput
            classes={{
              root: classes.root,
              underline: classes.input,
              input: classes.inputField,
              focused: classes.focus,
            }}
          />
        }
      >
        {options &&
          options.map(option => (
            <MenuItem key={option.key} value={option.key}>
              {option.value ? option.value : option.key}
            </MenuItem>
          ))}
      </Select>
    </FormControl>
  );
};

export default SelectField;
