import { makeStyles, Theme } from '@material-ui/core';
import { StyleRules } from '@material-ui/core/styles';

const useSelectFieldStyles = makeStyles(
  (theme: Theme): StyleRules => ({
    root: {
      marginTop: theme.spacing(2),
      backgroundColor: 'transparent',
    },
    input: {
      borderRadius: `${theme.shape.borderRadius}px !important`,
      backgroundColor: 'transparent',
      '&:before': {
        content: 'none !important',
      },
    },
    inputLabel: {
      zIndex: 1,
      paddingLeft: theme.spacing(1),
      pointerEvents: 'none',
    },
    inputField: {
      padding: theme.spacing(0.75, 1, 0.875),
      background: theme.palette.background.default,
      borderRadius: `${theme.shape.borderRadius}px !important`,
      position: 'relative',
      zIndex: 0,
      '&:hover, &:focus': {
        background: theme.palette.background.default,
      },
    },
    focus: {
      background: theme.palette.background.default,
    },
  }),
);

export default useSelectFieldStyles;
