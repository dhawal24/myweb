import React from 'react';
import { render } from '@testing-library/react';
import { expect } from 'chai';

import SelectField from '../index';

describe('<SelectField />', () => {
  it('Should render and match the snapshot', () => {
    const {
      container: { firstChild },
    } = render(
      <SelectField
        id="state"
        name="state"
        options={[{ key: 'USA', value: 'United States of America' }]}
      />,
    );
    expect(firstChild).to.matchSnapshot();
  });
});
