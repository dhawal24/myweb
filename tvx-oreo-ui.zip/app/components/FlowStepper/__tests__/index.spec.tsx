import React, { FC } from 'react';
import { expect } from 'chai';
import { render } from '@testing-library/react';
import { Provider } from 'react-redux';

import store from '../../../store';
import FlowStepper, { getStepContent } from '../index';
import { FlowStep, FlowStepperActions } from '../types';

describe('<FlowStepper />', () => {
  it('should render and match snapshot', () => {
    const {
      container: { firstChild },
    } = render(
      <Provider store={store}>
        <FlowStepper />
      </Provider>,
    );
    expect(firstChild).to.matchSnapshot();
  });
});

describe('<FlowStepper /> getStepContent()', () => {
  const mockStepContentFirst: FC<FlowStepperActions> = () => <div>Text</div>;
  const mockStepContentSecond: FC<FlowStepperActions> = () => <div>Text</div>;

  const mockFlowSteps: Array<FlowStep> = [
    { order: 1, label: 'first', component: mockStepContentFirst },
    { order: 2, label: 'second', component: mockStepContentSecond },
  ];

  it('should return null for non-existent stepOrder', () => {
    expect(getStepContent(-1, mockFlowSteps)).to.eql(null);
  });

  it('should return match step component of the given order ', () => {
    expect(getStepContent(1, mockFlowSteps)).to.eql(mockStepContentFirst);
  });
});
