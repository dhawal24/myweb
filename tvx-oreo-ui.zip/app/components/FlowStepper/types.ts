import React from 'react';

export interface FlowStepperActions {
  next: () => void;
  back?: () => void;
}

export type FlowStep = {
  order: number;
  label: string;
  component: React.ComponentType<FlowStepperActions>;
};
