import { createStyles, makeStyles, Theme } from '@material-ui/core';

export const useFlowStepperStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      width: '100%',
      backgroundColor: theme.palette.background.default,
      marginRight: 0,
    },
  }),
);
