import React, { FC } from 'react';
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import { Box } from '@material-ui/core';

import { useFlowStepperStyles } from './FlowStepperStyles';
import { flowSteps } from './constants';
import { FlowStep, FlowStepperActions } from './types';

export const FlowStepper: FC = () => {
  const classes = useFlowStepperStyles();
  const [activeStep, setActiveStep] = React.useState(0);
  const StepContent = getStepContent(activeStep, flowSteps);

  const handleNext = () => {
    setActiveStep(prevActiveStep => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep(prevActiveStep => prevActiveStep - 1);
  };

  return (
    <Box width="100%">
      <Stepper
        activeStep={activeStep}
        className={classes.root}
        alternativeLabel
      >
        {flowSteps.map(step => {
          const stepProps: { completed?: boolean } = {};
          return (
            <Step key={step.order} {...stepProps}>
              <StepLabel>{step.label}</StepLabel>
            </Step>
          );
        })}
      </Stepper>
      {StepContent && (
        <div>
          <Box width="100%" display="flex" justifyContent="center">
            <StepContent next={handleNext} back={handleBack} />
          </Box>
        </div>
      )}
    </Box>
  );
};

/**
 * Gets the flow step content by given order,
 * If an step with given order is not present an null value will be provided
 * @param stepOrder - order of the active step
 * @param steps - an array of steps
 */
export const getStepContent = (
  stepOrder: number,
  steps: Array<FlowStep>,
): React.ComponentType<FlowStepperActions> | null => {
  const activeStep = steps.find(step => step.order === stepOrder);
  return activeStep ? activeStep.component : null;
};

export default FlowStepper;
