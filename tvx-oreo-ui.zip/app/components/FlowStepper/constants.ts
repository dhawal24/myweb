import ProductPage from 'containers/ProductPage/Loadable';
import FulfillmentPage from 'containers/FulfillmentPage';
import PersonalDetails from 'containers/PersonalDetails/Loadable';
import OrderDetails from 'containers/OrderDetails';
import OrderSuccess from 'containers/OrderSuccess';
import RatesPage from 'containers/RatesPage/Loadable'
import ConfirmPayment from 'containers/ConfirmPayment/Loadable';

import { FlowStep } from './types';

export const flowSteps: Array<FlowStep> = [  
  {
    order: 0,
    label: 'Rates',
    component: RatesPage,
  },
  {
    order: 1,
    label: 'Product',
    component: ProductPage,
  },
  { order: 2, label: 'Fulfillment', component: FulfillmentPage },
  {
    order: 3,
    label: 'Personal Details',
    component: PersonalDetails,
  },
  { order: 4, label: 'Review', component: OrderDetails },
  { order: 5, label: 'Confirmation', component: OrderSuccess },
  { order: 6, label: 'Payment', component: ConfirmPayment },
];
