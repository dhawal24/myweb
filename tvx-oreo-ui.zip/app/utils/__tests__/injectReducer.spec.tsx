/**
 * Test injectors
 */

import React from 'react';
import { Provider } from 'react-redux';
import { Action, Reducer, Store } from 'redux';
import { render } from '@testing-library/react';
import { createMemoryHistory } from 'history';
import mock from 'mock-require';
import { assert, spy, stub } from 'sinon';

import store from '../../store';
import * as utils from '../history';

const reducer: Reducer<any, Action> = (state: Store) => state || null;

const memoryHistory = createMemoryHistory();
const injectors = {
  injectReducer: spy(),
};

stub(utils, 'history').returns(() => () => memoryHistory);
mock('../reducerInjectors', () => injectors);

describe('useInjectReducer hook', () => {
  let ComponentWithReducer: React.FC;

  beforeEach(() => {
    const { useInjectReducer } = mock.reRequire('../injectReducer');

    ComponentWithReducer = () => {
      useInjectReducer({ key: 'test', reducer });
      return null;
    };
  });

  afterEach(() => {
    mock.stop('../injectReducer');
  });

  it('should inject a given reducer', () => {
    render(
      <Provider store={store}>
        <ComponentWithReducer />
      </Provider>,
    );

    assert.calledOnce(injectors.injectReducer);
    assert.calledWith(injectors.injectReducer, {
      key: 'test',
      reducer,
    });
  });
});
