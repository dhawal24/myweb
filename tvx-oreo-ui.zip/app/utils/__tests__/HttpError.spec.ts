import { expect } from 'chai';

import HttpError from '../HttpError';

describe('HttpError', () => {
  it('should provide given code', () => {
    const code = '123';
    const mockHttpError = new HttpError(code, 'message');
    expect(mockHttpError.code).to.eql(code);
  });

  it('should provide given message', () => {
    const message = 'message';
    const mockHttpError = new HttpError('123', message);
    expect(mockHttpError.message).to.eql(message);
  });
});
