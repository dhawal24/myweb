import { createMuiTheme } from '@material-ui/core';
import { indigo, teal } from '@material-ui/core/colors';

const lightTheme = createMuiTheme({
  palette: {
    type: 'light',
    primary: {
      light: indigo[100],
      main: indigo[500],
      dark: indigo[700],
    },
    secondary: {
      light: teal[300],
      main: teal[500],
      dark: teal[700],
    },
    background: {
      default: '#E8EBEF',
      paper: '#FFF',
    },
  },
  shape: {
    borderRadius: 5,
  },
});

export default lightTheme;
