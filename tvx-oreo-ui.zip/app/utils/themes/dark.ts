import { createMuiTheme } from '@material-ui/core';
import { indigo, teal } from '@material-ui/core/colors';

const darkTheme = createMuiTheme({
  palette: {
    type: 'dark',
    primary: {
      light: indigo[200],
      main: indigo[300],
      dark: indigo[400],
    },
    secondary: {
      light: teal[200],
      main: teal[300],
      dark: teal[400],
    },
  },
});

export default darkTheme;
