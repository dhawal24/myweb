export default class HttpError extends Error {
  public message: string;

  public code: string;

  constructor(code: string, message: string) {
    super();
    this.code = code;
    this.message = message;
  }
}
