import chai from 'chai';
import chaiJestSnapshot from 'chai-jest-snapshot';
import { cleanup } from '@testing-library/react';
import { restore } from 'sinon';

chai.use(chaiJestSnapshot);

before(function beforeHook() {
  chaiJestSnapshot.resetSnapshotRegistry();
});

beforeEach(function beforeEachHook() {
  cleanup();
  chaiJestSnapshot.configureUsingMochaContext(this);
});

afterEach(function afterEachHook() {
  restore();
});
