require('ts-node').register({
  files: true,
  compilerOptions: {
    module: 'commonjs',
  },
});
