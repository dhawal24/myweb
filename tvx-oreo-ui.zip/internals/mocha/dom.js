import jsdomGlobal from 'jsdom-global';

jsdomGlobal();

global.window.Date = Date;
