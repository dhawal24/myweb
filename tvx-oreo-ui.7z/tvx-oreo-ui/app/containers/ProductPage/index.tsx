/*
 * HomePage
 *
 * This is the first thing users see of our App, at the '/' route
 *
 */

import React from 'react';
import { FormattedMessage } from 'react-intl';
import { Box } from 'grommet';

import messages from './messages';

interface Props {
  locale: string;
}

export const ProductPage: React.FC<Props> = () => (
  <Box align="center" fill="vertical" justify="center">
    <Box gap="medium" height="medium" justify="center" width="medium">
      <Box direction="row">
        <Box width="small">
          <label htmlFor="currency">
            <FormattedMessage {...messages.currency} />
          </label>
        </Box>
        <Box flex="grow">
          <select id="currency" name="currency">
            <option value="EUR">EUR</option>
            <option value="USD">USD</option>
          </select>
        </Box>
      </Box>
      <Box direction="row">
        <Box width="small" />
        <Box flex="grow">1 GBP = 1.0938 EUR</Box>
      </Box>
      <Box direction="row">
        <Box width="small">
          <label htmlFor="quantity">
            <FormattedMessage {...messages.quantity} />
          </label>
        </Box>
        <Box flex="grow">
          <input id="quantity" name="quantity" type="text" />
        </Box>
      </Box>
      <Box direction="row">
        <Box width="small">How much you will pay</Box>
        <Box flex="grow">457.12 GBP</Box>
      </Box>
      <Box direction="row" justify="center">
        <button onClick={() => {}} type="button">
          Submit
        </button>
      </Box>
    </Box>
  </Box>
);

export default ProductPage;
