<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="Generator" content="EditPlus®">
<meta name="Author" content="">
<meta name="Keywords" content="">
<meta name="Description" content="">
<title>Made By Dhawal | Web Designer | PHP Developer | Mumbai</title>
<meta name="Keywords" content="dhawal mhatre, web, website, websites, web design, design, freelance, responsive, mobile, mobile design, development, responsive development, web development, affordable, small business, personal, blog, portfolio, store"/>
<meta content="index, follow" name="Robots" />
<meta name="Copyright" content="Dhawal Mhatre"/>
<meta content="Dhawal Mhatre" name="Author" />
<meta content="en" name="Language" />
<meta http-equiv="Revisit-After" content="10 days"/>
<meta name="googlebot" content="index, follow" />
<meta name="msnbot" content="index, follow" />
<meta name="slurp" content="index, follow" />
<meta name="robots" content="All" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Latest compiled and minified CSS -->
<link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link href="css/mbd.css" rel="stylesheet" type="text/css" />
<link href="css/mbd-responsive.css" rel="stylesheet" type="text/css" />
<link id="pagestyle"  href="css/morning.css" rel="stylesheet" type="text/css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/scroll-navbar.js"></script>
<!--WOW Animation-->
<link rel="stylesheet" href="wow/animate.css">
<!--Snow Fall-->
<link href="css/snowflakes.css" rel="stylesheet" media="screen" />
<script src="js/ready.min.js" type="text/javascript"></script>
<script src="js/snowflakes.js" type="text/javascript"></script>
<script type="text/javascript">
var snowflakes;
	domReady(function() {
		snowflakes = new Snowflakes('container','snowflakesContainer'); 	
		snowflakes.create(40);
	});

jQuery(document).ready(function(){
	jQuery('.skillbar').each(function(){
		jQuery(this).find('.skillbar-bar').animate({
			width:jQuery(this).attr('data-percent')
		},6000);
	});
});

$(document).ready(function(){
	var hour = new Date().getHours();
	if (hour >= 6 && hour <= 17){
		document.getElementById('pagestyle').setAttribute('href', 'css/morning.css');
	}else if (hour >= 18 && hour <= 5){
		document.getElementById('pagestyle').setAttribute('href', 'css/nite.css');
	}else {
		document.getElementById('pagestyle').setAttribute('href', 'css/nite.css');
	}
});
</script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-59923592-1', 'auto');
  ga('send', 'pageview');

</script>

</head>
<body>
<header class="innerheader">
  <div id="snowflakesContainer"></div>
  <div id="container" class="container">
    <div id="header-navbar1">
      <nav class="navbar navbar-default">
        <div class="container-fluid"> 
          <!-- Brand and toggle get grouped for better mobile display -->
          <div class="navbar-header"> <a class="navbar-brand hidden-xs" href="index.html"><img src="images/my-logo.png" width="318" height="67" alt="Made by Dhawal Logo" border="0"/></a> <a class="navbar-brand visible-xs" href="index.html"><img src="images/mobile-logo.png" alt="Made by Dhawal Logo" border="0" width="200" height="42"/></a>
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false"> MENU </button>
          </div>
          
          <!-- Collect the nav links, forms, and other content for toggling -->
          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
              <li><a href="about-us.html">About Me</a></li>
              <li><a href="my-work.html">My Work</a></li>
              <li><a href="faq.html">FAQ's</a></li>
              <!-- <li><a href="blogs">My Blogs</a></li>
              <li><a href="testimonials.html">Testimonials</a></li> -->
              <li class="default"><a href="contact.html">Contact</a></li>
            </ul>
          </div>
          <!-- /.navbar-collapse --> 
        </div>
        <!-- /.container-fluid --> 
      </nav>
    </div>
    <div class="innerbanner">	  
		<h1 class="wow fadeInDown">Contact</h1>
    </div>
  </div>
  <div id="header-navbar2" class="hidden-xs" style="display:none;">
    <div class="container">
      <nav class="navbar navbar-default">
        <div class="container-fluid"> 
          <!-- Brand and toggle get grouped for better mobile display -->
          <div class="navbar-header"> <a class="navbar-brand" href="index.html"><img src="images/my-logo-xs.png" alt="Made by Dhawal Logo" border="0" width="200" height="42"/></a>
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false"> MENU </button>
          </div>
          
          <!-- Collect the nav links, forms, and other content for toggling -->
          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
              <li><a href="about-us.html">About Me</a></li>
              <li><a href="my-work.html">My Work</a></li>
              <li><a href="faq.html">FAQ's</a></li>
              <!-- <li><a href="blogs">My Blogs</a></li>
              <li><a href="testimonials.html">Testimonials</a></li> -->
              <li class="default"><a href="contact.html">Contact</a></li>
            </ul>
          </div>
          <!-- /.navbar-collapse --> 
        </div>
        <!-- /.container-fluid --> 
      </nav>
    </div>
  </div>
</header>
<section class="aboutMe">
  <div class="container">
    <div class="text-center"> <img src="images/my-work-icon.png" alt="My Work" title="My Work" border="0" class="img-responsive wow flipInX"/>
      <h6>Like what you see? Let’s Talk.</h6>
      <p class="col-md-8 col-xs-12 col-md-offset-2 wow fadeInDown">Interested in working together? Fill out the form below with some information about your project. Have a question for me? Check the <a href="faq.html">FAQ page</a> first. If it is not answered there, fill out the below form. Please allow a couple of business days for me to respond. </p>
	  <div class="col-md-6 col-xs-12 col-md-offset-3 wow fadeInDown" style="margin-top:25px;">
	  <form method="post" class="formInput" action="project-enquiry.php">
		  <div class="form-group">
			<input type="text" class="form-control" id="fullName" name="fullName" placeholder="Full Name" required>
		  </div>
		  <div class="form-group">
			<input type="email" class="form-control" id="emailAdd" name="emailAdd" placeholder="Email" required>
		  </div>
		  <div class="form-group">
			<input type="text" class="form-control" id="contactNo" name="contactNo" placeholder="Phone No." required>
		  </div>
		  <div class="form-group">
			<textarea class="form-control" id="porjectQuery" name="porjectQuery" rows="6" placeholder="Tell me little about your project"></textarea>
		  </div>
		  <button type="submit" class="btn btn-primary col-lg-12" style="float:left;">Submit</button>
	</form>
    </div>
    </div>
  </div>
  <div class="clear"></div>
</section>
<section class="">
	
</section>

<footer>
	<div class="container">
		<div class="groundBg">
			<ul>
				<li><a href="https://www.facebook.com/dhawal.mhatre" target="_blank">facebook</a></li>
				<li><a href="https://twitter.com/DhawalMhatre" target="_blank">twitter</a></li>
				<li><a href="http://in.linkedin.com/pub/dhawal-mhatre/1b/607/358" target="_blank">linkedin</a></li>
				<li><a href="mailto:hello@madebydhawal.com">hire me</a></li>
			</ul>
			<p class="text-center">Copyright &copy; 2016 MadebyDhawal All Rights Reserved | Site Map</p>
		</div>
	</div>
</footer>
</body>
<script src="wow/wow.js"></script>
<script>
    wow = new WOW(
      {
        animateClass: 'animated',
        offset:       100,
        callback:     function(box) {
          console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
        }
      }
    );
    wow.init();

  </script>
</html>
