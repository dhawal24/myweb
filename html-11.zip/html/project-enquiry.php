<?php

	$fullNameTxt = $emailIdTxt = $phoneTxt = $commentsMsg = "";
	$errorTxt = "";
	$error = 0;
	
	if(empty($_REQUEST['fullName'])){
			$errorTxt = "Full Name is required.";
			$error = 1;
		}else{
			$fullNameTxt = $connection->sanitize_input($_REQUEST['fullName']);
			if (!preg_match("/[a-zA-Z]+/",$fullNameTxt)) {
				$errorTxt = "Only aphla numeric and white space allowed";
				$error = 1;
			}
	}
	if(empty($_POST['emailAdd'])){
		$errorTxt = "Email is required";
		$error = 1;
	}else{
		$emailIdTxt = $connection->sanitize_input($_POST['emailAdd']);
		if (!filter_var($emailIdTxt, FILTER_VALIDATE_EMAIL)) {
			$errorTxt = "Invalid email format";
			$emailIdTxt = "";
			$error = 1;
		}
	}
	if(empty($_POST['contactNo'])){
		$errorTxt = "Phone No is required.";
		$error = 1;
	}else{
		$phoneTxt = $connection->sanitize_input($_POST['contactNo']);
		if(!preg_match("/^[0-9,]+$/", $phoneTxt)){
			$errorTxt = "Only numbers allowed.";
			$error = 1;
		}
	}
	if(preg_match("/(http|https|ftp|ftps)\:\/\/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\/\S*)?/", $_REQUEST['porjectQuery'])){
		header("location:contact.php?error=URL is not allowed");
	}elseif($error == 0){
		$fullNameTxt = $_REQUEST['fullName'];
		$emailIdTxt = $_REQUEST['emailAdd'];
		$phoneTxt = $_REQUEST['contactNo'];
		$commentsMsg = $_REQUEST['porjectQuery'];
		$GetIpAddress = $_SERVER['REMOTE_ADDR'];
		$BrowserDetail = $_SERVER['HTTP_USER_AGENT'];

			$mediaMsg = "<html><body><table width='700' border='0' cellspacing='0' cellpadding='0'>  <tr>    <td style='padding:10px; font-family:Georgia, Times New Roman, Times, serif; font-size:14px;'><p>Hello Dhawal,</p><p>You have received  enquiry from Madebydhawal.com. Below is the detail of enquiry:</p><ul>  <li style='padding:5px 0px;'><strong>Full Name :</strong> ".$fullNameTxt."</li>  <li style='padding:5px 0px;'><strong>Email :</strong> ".$emailIdTxt."</li>  <li style='padding:5px 0px;'><strong>Phone No.:</strong> ".$phoneTxt."</li>  <li style='padding:5px 0px;'><strong>Query :</strong> ".$commentsMsg."</li>  <li style='padding:5px 0px;'><strong>IP Address :</strong> ".$GetIpAddress."</li>  <li style='padding:5px 0px;'><strong>Browser Detail :</strong> ".$BrowserDetail."</li></ul><p>&nbsp;</p><p><strong>Madebydhawal.com</strong></p></td>  </tr></table></body></html>";

			require_once('php-mailer/class.phpmailer.php');
			$mail = new PHPMailer();
			$mail->IsSMTP(); // telling the class to use SMTP
			$mail->SMTPDebug  = 1; // enables SMTP debug information (for testing) // 1 = errors and messages // 2 = messages only
			$mail->SMTPAuth   = true; // enable SMTP authentication
			$mail->SMTPSecure = "tls";  
			$mail->Host = "smtp.gmail.com"; // sets the SMTP server
			$mail->Port = 587; // set the SMTP port for the GMAIL server
			$mail->Username   = "madebydhawal@gmail.com"; // SMTP account username
			$mail->Password   = "m@d3byDhawa!";  // SMTP account password
			$mail->From = "hello@madebydhawal.com";
			$mail->FromName = "Made By Dhawal";
			$mail->Subject = "Enquiry from MadebyDhawal.com";
			$mail->MsgHTML($mediaMsg);
			$mail->AddAddress("dhawal.mhatre@gmail.com", "Dhawal Mhatre");
			$mail->AddBCC("madebydhawal@gmail.com", "Dhawal Mhatre");
			$mail->send();
			$mail->ClearAllRecipients();
			
			header("location:thanks.html");
	}else{
		header("location:contact.php?error=$errorTxt");
	}

?>