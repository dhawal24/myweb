/**
 * Combine all reducers in this file and export the combined reducers.
 */

import { combineReducers } from 'redux';
import { connectRouter } from 'connected-react-router';

import history from '../utils/history';
import languageProviderReducer from '../containers/LanguageProvider/reducer';
import productReducer from '../containers/ProductPage/reducer';
import personalDetailsReducer from 'containers/PersonalDetails/reducer';
import fulfillReducer from '../containers/FulfillmentPage/reducer';


/**
 * Merges the main reducer with the router state and dynamically injected reducers
 */
export default function createReducer(injectedReducers = {}) {
  return combineReducers({
    personalDetails: personalDetailsReducer,
    fulfillDetails: fulfillReducer,
    language: languageProviderReducer,
    router: connectRouter(history),
    productReducer,
    ...injectedReducers,
  });
}
