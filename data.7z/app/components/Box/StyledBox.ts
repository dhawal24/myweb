import styled from 'styled-components'

const StyledBox = styled.div`
    text-align: center;
    border: 1px solid #000;
    display: flex;
    flex-direction: column;
    padding: 0 24px 16px;
`

export default StyledBox