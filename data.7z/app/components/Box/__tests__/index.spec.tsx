import React from 'react';
import { render } from 'react-testing-library';
import Box from '../index';

const content = <div data-testid="child">test content</div>

describe('<Box />', () => {
  it('Should render and match the snapshot', () => {
    const {
      container: { firstChild },
    } = render(
      <Box />
    );
    expect(firstChild).toMatchSnapshot();
  });

  it('Should render the component with children', () => {
    const {
      getByTestId
    } = render(
      <Box>
        {content}
      </Box>
    );

    expect(getByTestId('child')).toBeDefined()
  });
});
