import React from 'react';

import StyledBox from './StyledBox';

interface Props {}

const Box: React.FC<Props> = ({children}) => (
  <StyledBox>
    {children}
  </StyledBox>
);

export default Box;
