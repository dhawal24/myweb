import React from 'react';

interface Props {
    id: string
    name: string
    options: string[]
}

const SelectField: React.FC<Props> = (props: Props) => 
    <select defaultValue="" {...props}>
        <option value="" disabled hidden></option>
        {
            props.options && props.options.map((value, index) => <option key={index} value={value}>{value}</option>)
        }
    </select>

export default SelectField;
