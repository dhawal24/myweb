import React from 'react';
import { render } from 'react-testing-library';

import SelectField from '../index';

describe('<SelectField />', () => {
  it('Should render and match the snapshot', () => {
    const {
      container: { firstChild },
    } = render(
      <SelectField id="state" name="state" options={["United States of America"]} />
    );
    expect(firstChild).toMatchSnapshot();
  });
});
