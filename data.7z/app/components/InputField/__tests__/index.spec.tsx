import React from 'react';
import { render } from 'react-testing-library';

import InputField from '../index';

describe('<InputField />', () => {
  it('Should render and match the snapshot', () => {
    const {
      container: { firstChild },
    } = render(
      <InputField id="firstName" name="firstName" type="text"/>
    );
    expect(firstChild).toMatchSnapshot();
  });
});
