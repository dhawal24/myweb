import React from 'react';

interface Props {
    id: string
    name: string
    type: string
}

const InputField: React.FC<Props> = (props: Props) => <input {...props} />

export default InputField;
