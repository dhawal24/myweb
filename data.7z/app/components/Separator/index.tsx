import React from 'react';
import StyledSeparator from './StyledSeparator';

export interface Props {
    borderWidth?: number
}

const Separator: React.FC<Props> = ({borderWidth}) => <StyledSeparator borderWidth={borderWidth}/>;

export default Separator;
