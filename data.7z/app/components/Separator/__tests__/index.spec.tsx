import React from 'react';
import { render } from 'react-testing-library';

import Separator from '../index';

describe('<Separator />', () => {
  it('Should render and match the snapshot', () => {
    const {
      container: { firstChild },
    } = render(<Separator />);
    expect(firstChild).toMatchSnapshot();
  });

});
