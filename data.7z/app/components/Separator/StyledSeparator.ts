import styled, { css } from 'styled-components'
import { Props } from './index';


const StyledSeparator = styled.div((props: Props) => {
    return css `
    border-bottom: ${props.borderWidth || "0"}px solid black;
`})

StyledSeparator.displayName = "StyledSeparator";
export default StyledSeparator;