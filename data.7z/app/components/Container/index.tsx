import React, { ReactNode } from 'react';
import StyledContainerSection from './StyledContainerSection';

export interface Props {
    children?: ReactNode
    width?: number
    padding?: string
    borderWidth?: number
    margin?: string 
    logo?: boolean
}

const Container: React.FC<Props> = ({ width, borderWidth, padding, margin, logo, children }) => {
    return <StyledContainerSection
        width={width}
        borderWidth={borderWidth}
        padding={padding}
        margin={margin}>
        {logo && <img src="https://i.pinimg.com/originals/90/4f/ce/904fce606315b5b0de0b83cd0cfe9a6d.jpg" alt="Logo" width="50" style={{ marginBottom: "20px" }} />}

        {children}
    </StyledContainerSection>;
}
export default Container;
