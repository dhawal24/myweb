import styled, { css } from 'styled-components';
import { Props } from './index';

const StyledContainerSection = styled.section((props: Props) => {
    return css `
    width: ${props.width && (props.width + 'px')};
    padding: ${props.padding || "0"};
    border: ${props.borderWidth || "0"}px solid black;
    margin: ${props.margin};
`})

StyledContainerSection.displayName = "StyledContainerSection";
export default StyledContainerSection;