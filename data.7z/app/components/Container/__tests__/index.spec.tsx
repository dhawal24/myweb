import React from 'react';
import { render } from 'react-testing-library';

import Container from '../index';

describe('<Container />', () => {
  it('Should render and match the snapshot', () => {
    const {
      container: { firstChild },
    } = render(
      <Container />
    );
    expect(firstChild).toMatchSnapshot();
  });
});
