/*
 * HomePage Messages
 *
 * This contains all the text for the HomePage container.
 */
import { defineMessages } from 'react-intl';

const messages = defineMessages({
  header: {
    id: 'app.containers.HomePage.header',
    defaultMessage: 'This is the HomePage container!',
  },
  currency: {
    id: 'app.containers.HomePage.currencyLabel',
    defaultMessage: 'Currency'
  },
  quantity: {
    id: 'app.containers.HomePage.quantityLabel',
    defaultMessage: 'How much do you want'
  }
});

export default messages;
