import styled from 'styled-components';

const PersonalDetailsStyle = styled.section`
    input, select {
        border: 1px solid #9E9E9E;

        &.input-error {
            border: 1px solid #F44336;
        }
    }

    .message-error {
        color: #F44336;
        text-transform: lowercase;

        &::first-letter {
            text-transform: uppercase;
        }
    }

    input[type="date"] {
        position: relative; 
        height: 20px;

        &:before {
            content: attr(data-date);
            color: #000;
        }

        &::-webkit-datetime-edit, &::-webkit-inner-spin-button, &::-webkit-clear-button {
            display: none;
        }

        &::-webkit-calendar-picker-indicator {
            position: absolute;
            top: 4px;
            right: 2px;
            width: 6px;
            height: 7px;
            color: black;
            opacity: 1;

            &:hover {
                background-color: transparent;
            }
        }
    }
`

PersonalDetailsStyle.displayName = 'PersonalDetailsStyle';
export default PersonalDetailsStyle;