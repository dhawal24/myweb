import produce from 'immer';
import { PersonalDetailsType, SubmitActionType } from './types';
import { SUBMIT_PERSONAL_DETAILS } from './constants';

export const initialPersonalDetails: PersonalDetailsType = {
    firstName: '',
    lastName: '',
    mobileNumber: '',
    email: '',
    address1: '',
    address2: '',
    city: '',
    county: '',
    postCode: '',
    birthDate: ''
};

/* eslint-disable default-case, no-param-reassign */
const personalDetailsReducer = (state = initialPersonalDetails, action: SubmitActionType) =>
    produce(state, (draft: PersonalDetailsType) => {
        switch (action.type) {
            case SUBMIT_PERSONAL_DETAILS: {
                Object.keys(draft).map((fieldName) => draft[fieldName as keyof PersonalDetailsType] = action.data[fieldName as keyof PersonalDetailsType])
                break;
            }
        }
    });

export default personalDetailsReducer