import { SUBMIT_PERSONAL_DETAILS } from './constants';
import { PersonalDetailsType } from './types';

export const submitPersonalDetails = (data: PersonalDetailsType) => ({
    type: SUBMIT_PERSONAL_DETAILS,
    data
})