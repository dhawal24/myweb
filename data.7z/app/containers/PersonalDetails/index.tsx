/*
 * PersonalDetailsPage
 *
 */

import React from 'react';
import { FormattedMessage } from 'react-intl';
import { Box, Heading } from 'grommet';
import { ConnectedRouterProps } from 'connected-react-router';
import moment from 'moment';

import messages from './messages';
import { PersonalDetailsFields } from './constants';
import { FormField, PersonalDetailsType, PersonalDetailsActions } from './types';
import PersonalDetailsStyle from './PersonalDetailsStyle';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import { submitPersonalDetails } from './actions'
import { initialPersonalDetails } from './reducer';
import Container from 'components/Container';

interface State {
  personalDetails: PersonalDetailsType
  hasError: { [fieldId: string]: boolean }
}

interface Props extends PersonalDetailsActions, PersonalDetailsType, ConnectedRouterProps { }

export class PersonalDetails extends React.Component<Props, State> {
  public state: State = {
    personalDetails: initialPersonalDetails,
    hasError: PersonalDetailsFields.map(el => el.id).reduce((obj, key) => ({ ...obj, [key]: false }), {}),
  }

  public componentDidMount() {
    document.querySelectorAll('input[type=date]')[0].setAttribute('data-date', 'dd/mm/yyyy');
  }

  public render() {
    const { hasError } = this.state;

    return (
      <Container width={800} borderWidth={1} margin={"0 auto"} padding={"20px"} logo>
        <PersonalDetailsStyle>
          <Container borderWidth={1} padding={"0 20px"}>
            <Box gap="medium" width="large" margin={{ top: "medium", bottom: "medium" }}>
              <Heading level="3" margin={{ top: "xsmall", bottom: "xsmall" }}>
                <FormattedMessage {...messages.header} />
              </Heading>
              {
                PersonalDetailsFields.map((field: FormField) => {
                  const { message, component, order, ...fieldProperties } = field

                  return <Box direction="row" key={field.id}>
                    <Box width="small">
                      <label htmlFor={field.id}>
                        <FormattedMessage {...message} />
                      </label>
                    </Box>
                    <Box width="small">
                      <field.component {...fieldProperties}
                        className={hasError[field.id] ? 'input-error' : ''}
                        onChange={this.onFieldChange}
                        onBlur={() => this.handleError(field.id)}
                        required
                      />
                    </Box>
                    <Box width="medium" margin={{ left: "medium" }}>
                      {hasError[field.id] && <div className="message-error">{message.defaultMessage} is required.</div>}
                    </Box>
                  </Box>
                })
              }
              <Box direction="row" justify="end" margin={{ top: "medium", right: "medium" }}>
                <button onClick={this.handleSubmit}> Submit </button>
              </Box>
            </Box>
          </Container>
        </PersonalDetailsStyle>
      </Container>
    )
  }

  private onFieldChange = (event: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const inputId = (event as React.ChangeEvent<HTMLInputElement | HTMLSelectElement>).target.id
    const inputText = (event as React.ChangeEvent<HTMLInputElement | HTMLSelectElement>).target.value

    if (inputText !== null) {
      this.setState(prevState => ({
        personalDetails: {
          ...prevState.personalDetails,
          [inputId]: inputText
        }
      }))
    }

    this.setState(prevState => ({
      hasError: { ...prevState.hasError, [inputId]: inputText !== '' ? false : true }
    }))

    inputId === "birthDate" && document.querySelectorAll('input[type=date]')[0].setAttribute('data-date', moment(inputText, "YYYY-MM-DD").format('DD/MM/YYYY'));
  }

  private handleError = (fieldId: keyof PersonalDetailsType) => {
    this.setState(prevState => ({
      hasError: { ...prevState.hasError, [fieldId]: !this.state.personalDetails[fieldId] ? true : false }
    }))
  }

  private handleSubmit = () => {
    const { personalDetails } = this.state;
    document.body.scrollTop = 0;

    Object.keys(personalDetails).map(fieldId => {
      this.handleError(fieldId as keyof PersonalDetailsType);
    })

    if (Object.values(personalDetails).filter(field => field === '').length === 0) {
      this.props.submitPersonalDetails && this.props.submitPersonalDetails({
        ...this.state.personalDetails
      })
      this.props.history.push('/details');
    }
  }
}

const mapStateToProps = (state: any) => {
  return {
    personalDetails: state.personalDetails
  }
}

const mapDispatchToProps = (dispatch: any) => bindActionCreators(
  { submitPersonalDetails }, dispatch
)

export default connect(mapStateToProps, mapDispatchToProps)(PersonalDetails);
