import { FormattedMessage } from 'react-intl';

export interface FormField {
  id: keyof PersonalDetailsType
  message: FormattedMessage.MessageDescriptor
  component: React.FunctionComponent<any>
  name?: string
  type?: string
  options?: string[]
  order?: number
}

/**
 * redux types
 */

export interface PersonalDetailsType {
  firstName: string
  lastName: string
  mobileNumber: string
  email: string
  address1: string
  address2: string
  city: string
  county: string
  postCode: string
  birthDate: string
}

export interface SubmitActionType {
  type: string,
  data: PersonalDetailsType
}

export interface PersonalDetailsActions {
  submitPersonalDetails?: (data: PersonalDetailsType) => SubmitActionType
}