export interface ProductDetailsType {
    currencyCode: string
    amount: number | null
    exchangeRate: number | null
}

export interface SubmitActionType {
    type: string
    data: ProductDetailsType
}

export interface ProductDetailsActions {
    submitProductRequest: (data: ProductDetailsType) => SubmitActionType
}