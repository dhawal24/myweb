/*
 * HomePage
 *
 * This is the first thing users see of our App, at the '/' route
 *
 */

import React from 'react'
import { ConnectedRouterProps } from 'connected-react-router'
import { FormattedMessage } from 'react-intl';
import { Box } from 'grommet'

import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import messages from './messages'

import currencyList from './constants'
import { submitProductRequest } from './actions'
import { ProductDetailsActions, ProductDetailsType } from './types';
import Container from '../../components/Container';

interface Props extends ConnectedRouterProps, ProductDetailsActions {
  currencies: string
  currencyCode: string
  finalAmount: number
  newFinal: number
  exchangeRate: number
}

interface State extends ProductDetailsType { }


class ProductPage extends React.Component<Props, State> {
  public state: State = {
    currencyCode: '',
    amount: null,
    exchangeRate: this.props.exchangeRate,
  }

  private changeCurrency = (event: React.ChangeEvent<HTMLSelectElement>) => {
    let filterCurrency = currencyList.find(t => t.code === event.target.value)

    if (filterCurrency) {
      this.setState({ exchangeRate: filterCurrency.rate, currencyCode: event.target.value })
    }
  };

  private qtyChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value;
    this.setState({
      amount: parseFloat(value),
    });
  };

  private handleSubmit = () => {
    const { currencyCode, amount, exchangeRate } = this.state
    this.props.submitProductRequest({
      currencyCode,
      amount,
      exchangeRate
    })
    this.props.history.push('/fulfillment')
  };


  render() {
    const { amount, exchangeRate } = this.state
    let convertedAmount = amount && exchangeRate && (amount * exchangeRate).toFixed(2)

    return (
      <Container width={800} borderWidth={1} margin={"0 auto"} padding={"20px"} logo>
        <Container  borderWidth={1}>
          <Box align="center" fill="vertical" justify="center">
            <Box gap="medium" height="medium" justify="center" width="550px">
              <Box direction="row">
                <Box width="small">
                  <label htmlFor="currency">
                    <FormattedMessage {...messages.currency} />
                  </label>
                </Box>
                <Box flex="grow">
                  <select
                    id="currency"
                    name="currency"
                    onChange={this.changeCurrency}
                    value={this.state.currencyCode}
                  >
                    <option value="" disabled hidden>Select currency</option>
                    {currencyList.map(currency => (
                      <option key={currency.id} value={currency.code}>
                        {currency.name}
                      </option>
                    ))}
                  </select>
                </Box>
              </Box>

              {this.state.currencyCode && [<Box direction="row" key="echange-rate">
                <Box width="small" />
                <Box flex="grow">
                  1 GBP = {this.state.exchangeRate} {this.state.currencyCode}
                </Box>
              </Box>,
              <Box direction="row" key="quantity">
                <Box width="small">
                  <label htmlFor="quantity">
                    <FormattedMessage {...messages.quantity} />
                  </label>
                </Box>
                <Box flex="grow">
                  <input
                    id="quantity"
                    name="quantity"
                    type="text"
                    value={this.state.amount || ''}
                    onChange={this.qtyChange}
                  />
                </Box>
              </Box>,
              <Box direction="row" key="to-pay">
                <Box width="small">How much you will pay</Box>
                <Box flex="grow">{convertedAmount ? `${convertedAmount} GBP` : 'Please add an amount'}</Box>
              </Box>,
              <Box direction="row" justify="center" key="submit">
                <button onClick={this.handleSubmit} type="button">
                  Submit
            </button>
              </Box>
              ]}
            </Box>
          </Box>
        </Container >
      </Container >
    );
  }
}
const mapStateToProps = (state: any) => {
  return {
    p: state.personalDetails
  }
}

const mapDispatchToProps = (dispatch: any) => bindActionCreators(
  { submitProductRequest }, dispatch
)

export default connect(mapStateToProps, mapDispatchToProps)(ProductPage);
