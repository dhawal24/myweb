const currencyList = [
  { id: 1, name: 'US Dollar', rate: 1.25175, code: 'USD' },
  { id: 2, name: 'Australia Dollar', rate: 1.7997, code: 'AUD' },
  { id: 3, name: 'Canada Dollar', rate: 1.63633, code: 'CAD' },
  { id: 4, name: 'Euro', rate: 1.11247, code: 'EUR' },
];

export default currencyList;

/**
 * redux constants
 */
export const SUBMIT_PRODUCT_SELECTION = 'SUBMIT_PRODUCT_SELECTION'