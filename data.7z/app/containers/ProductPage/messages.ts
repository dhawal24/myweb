/*
 * ProductPage Messages
 *
 * This contains all the text for the ProductPage container.
 */
import { defineMessages } from 'react-intl';

const messages = defineMessages({
  currency: {
    id: 'app.containers.HomePage.currencyLabel',
    defaultMessage: 'Currency'
  },
  quantity: {
    id: 'app.containers.HomePage.quantityLabel',
    defaultMessage: 'How much do you want'
  }
});

export default messages;
