import { SUBMIT_PRODUCT_SELECTION } from './constants';
import { ProductDetailsType, SubmitActionType } from './types';

export const submitProductRequest = (data: ProductDetailsType): SubmitActionType => ({
    type: SUBMIT_PRODUCT_SELECTION,
    data
})