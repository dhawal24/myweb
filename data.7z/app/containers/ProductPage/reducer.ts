import produce from 'immer';
import { SUBMIT_PRODUCT_SELECTION } from './constants';
import { ProductDetailsType, SubmitActionType } from './types';

export const initialProductDetails: ProductDetailsType = {
    currencyCode: '',
    amount: null,
    exchangeRate: null,
};

const productReducer = (state = initialProductDetails, action: SubmitActionType) =>
    produce(state, (draft: ProductDetailsType) => {
        switch (action.type) {
            case SUBMIT_PRODUCT_SELECTION: {
                Object.keys(draft).map((fieldName) => draft[fieldName as keyof ProductDetailsType] = action.data[fieldName as keyof ProductDetailsType])
                break;
            }
        }
    });

export default productReducer