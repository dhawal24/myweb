
import React from 'react';
import { ConnectedRouterProps } from 'connected-react-router';
import { FormattedMessage } from 'react-intl';
import messages from './messages';
import Separator from '../../components/Separator';
import { Heading, Box, Paragraph } from 'grommet';
import Container from '../../components/Container';

enum FullfillmentType {
    HOME_DELIVERY = 'Home Delivery',
    PARTNER_PICKUP = 'Partner Pickup'
}

interface OrderSummary {
    orderNumber: string
    currency: string
    userCurrency: string
    exchangeRate: number
    amountToChange: number
    fullfillmentType: FullfillmentType
    deliveryDate: string
}

const data: OrderSummary = {
    orderNumber: 'TVX123456789',
    currency: 'EUR',
    userCurrency: 'GBP',
    exchangeRate: 1.0938,
    amountToChange: 500,
    fullfillmentType: FullfillmentType.HOME_DELIVERY,
    deliveryDate: '19/06/2019'
}


type Props = ConnectedRouterProps;
export const OrderSuccess: React.FC<Props> = (props) => {

    const handleSubmit = () => {
        props.history.push('/confirm-payment')
    };


    return (
        <Container borderWidth={1} padding="20px" logo>
            <Container borderWidth={1} padding="0 24px 16px">
                <Heading level="2">
                    <FormattedMessage {...messages.title} />
                </Heading>
                <Separator />
                <Box direction="row" justify="center">
                    <Heading level="3"><FormattedMessage {...messages.subTitle} />:</Heading>

                    <Paragraph margin={{ left: '4px' }} size="large" textAlign="start" alignSelf="center">{data.orderNumber}</Paragraph>
                </Box>
                <Box direction="row" alignContent="start">
                    <Heading level="5" margin={{ top: '0', bottom: '4px' }}><FormattedMessage {...messages.summary} />:</Heading>
                </Box>
                <Box direction="row" alignContent="start">
                    <Paragraph margin={{ bottom: '0' }} size="small" textAlign="start"><FormattedMessage {...messages.currency} /> {data.currency}</Paragraph>
                </Box>
                <Box direction="row" alignContent="start">
                    <Paragraph margin={{ bottom: "16px", top: '0' }} size="small" textAlign="start">{data.amountToChange} {data.currency} @ {data.exchangeRate} = {(data.amountToChange / data.exchangeRate).toFixed(2)} {data.userCurrency}</Paragraph>
                </Box>
                <Box direction="row" alignContent="start">
                    <Heading level="6" margin={{ top: '0', bottom: '4px' }}><FormattedMessage {...messages.fulfillment} />:</Heading>
                    <Paragraph size="small" margin={{ top: '0', bottom: '0', left: '4px' }}>{data.fullfillmentType}</Paragraph>
                </Box>
                <Box direction="row" alignContent="start">
                    <Heading level="6" margin={{ top: '0', bottom: '4px' }}><FormattedMessage {...messages.deliveryDate} />:</Heading>
                    <Paragraph size="small" margin={{ top: '0', bottom: '0', left: '4px' }}>{data.deliveryDate}</Paragraph>
                </Box>

                <Box direction="row" justify="end">
                    <button onClick={handleSubmit} type="button">
                        <FormattedMessage {...messages.submit} />
                    </button>
                </Box>
            </Container>
        </Container>
    )
}
export default OrderSuccess