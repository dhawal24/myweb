import { RouteProps } from 'react-router';
import ProductPageComponent from 'containers/ProductPage'
import OrderFailure from 'containers/OrderFailure';
import OrderSuccess from 'containers/OrderSuccess';
import PersonalDetailsComponent from 'containers/PersonalDetails';
import FulfillmentPage from 'containers/FulfillmentPage';
import OrderDetails from 'containers/OrderDetails';
import ConfirmPayment from 'containers/ConfirmPayment';

export interface CustomRouteProps extends RouteProps {
    key: string
}
const routes: CustomRouteProps[] = [
    {
        key: 'confirm-payment',
        exact: true,
        path: '/confirm-payment',
        component: ConfirmPayment
    },
    {
        key: 'product',
        exact: true,
        path: '/',
        component: ProductPageComponent
    },
    {
        key: 'details',
        exact: true,
        path: '/details',
        component: OrderDetails
    },
    {
        key: 'personal-details',
        exact: true,
        path: '/personal-details',
        component: PersonalDetailsComponent
    },
    {
        key: 'fulfillment-details',
        exact: true,
        path: '/fulfillment',
        component: FulfillmentPage
    },
    {
        key: 'order-success',
        exact: true,
        path: '/order-success',
        component: OrderSuccess
    },
    {
        key: 'order-failure',
        exact: true,
        path: '/order-failure',
        component: OrderFailure
    },
    {
        key: 'confirm',
        exact: true,
        path: '/confirm',
        component: ProductPageComponent
    }
]

export default routes