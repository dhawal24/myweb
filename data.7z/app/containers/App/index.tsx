/**
 *
 * App.js
 *
 * This component is the skeleton around the actual pages, and should only
 * contain code that should be seen on all pages. (e.g. navigation bar)
 *
 */

import React from 'react';
import { Route, Switch } from 'react-router-dom';
import { Grommet, Box } from 'grommet';

import NotFoundPage from 'containers/NotFoundPage/Loadable';
import routes, { CustomRouteProps } from './routes';
import './app.css';

export default function App() {
  return (
    <Grommet full plain className="main-container">
      <Box align="center" fill="vertical" justify="center">
        <Box gap="medium" justify="center" direction="row">
          <Switch>
            {
              routes.map((routeConfig: CustomRouteProps) => <Route {...routeConfig} />)
            }
            <Route component={NotFoundPage} />
          </Switch>
        </Box>
      </Box>
    </Grommet>
  );
}
