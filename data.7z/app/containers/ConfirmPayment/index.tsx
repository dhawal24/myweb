import React from 'react';
import { FormattedMessage } from 'react-intl';
import { Heading, Box } from 'grommet';

import messages from './messages';
import Container from 'components/Container';

// enum Statuses {
//   SUCCESS = 'success',
//   ERROR = 'error',
// }

interface Props {}

interface State {
  orderId: string;
  checked: string;
  resData: string;
  confirmationStatus: string;
  confirmMsg: string;
}

class ConfirmPayment extends React.Component<Props> {
  public state: State = {
    orderId: '',
    checked: '',
    resData: '',
    confirmationStatus: '',
    confirmMsg: '',
  };
  public render() {
    return (
      <Container borderWidth={1} padding="20px" logo>
        <Container borderWidth={1} padding="0 24px 16px">
          <Heading level="3" margin={{ top: 'xsmall', bottom: 'xsmall' }}>
            <FormattedMessage {...messages.header} />
          </Heading>
          {this.getMessage()}
          <Box direction="row" key="reference" margin={{ top: '32px' }}>
            <Box width="small">
              <label htmlFor="reference">
                <FormattedMessage {...messages.orderReference} />
              </label>
            </Box>
            <Box flex="grow">
              <input
                id="reference"
                type="text"
                value={this.state.orderId || ''}
                onChange={this.changeOrderId}
              />
            </Box>
          </Box>
          <Box direction="row" margin={{ top: '32px' }}>
            <Box width="small" direction="row">
              <input
                type="radio"
                id="confirmPayment"
                value="success"
                checked={this.state.checked === 'success'}
                onChange={this.changeRadioStatus}
              />
              <FormattedMessage {...messages.confirmPayment}>
                {formatedMessage => (
                  <label htmlFor="confirmPayment">{formatedMessage}</label>
                )}
              </FormattedMessage>
            </Box>
            <Box width="small" direction="row">
              <input
                type="radio"
                id="rejectPayment"
                value="failure"
                checked={this.state.checked === 'failure'}
                onChange={this.changeRadioStatus}
              />
              <FormattedMessage {...messages.rejectPayment}>
                {formatedMessage => (
                  <label htmlFor="rejectPayment">{formatedMessage}</label>
                )}
              </FormattedMessage>
            </Box>
          </Box>
          <Box
            direction="row"
            justify="start"
            margin={{ top: 'medium', right: 'medium' }}
          >
            <button onClick={this.handleSubmit}> Submit </button>
          </Box>
        </Container>
      </Container>
    );
  }

  private getMessage = () => {
    if (this.state.confirmationStatus == 'Error') {
      return (
        <Heading
          level="5"
          margin={{ top: 'xsmall', bottom: 'xsmall' }}
          style={{ color: 'red' }}
        >
          {this.state.confirmMsg}
        </Heading>
      );
    } else if (this.state.confirmationStatus == 'Success') {
      return (
        <Heading
          level="5"
          margin={{ top: 'xsmall', bottom: 'xsmall' }}
          style={{ color: 'green' }}
        >
          Order successfully confirmed
        </Heading>
      );
    }
  };

  private changeOrderId = (event: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ orderId: event.target.value });
  };
  private changeRadioStatus = (event: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ checked: event.target.value });
  };

  private handleSubmit = () => {
    const url =
      'http://in-mu-lt-J27296:8080/orders/' +
      this.state.orderId +
      '/actions/confirmPayment';

    fetch(url, {
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      mode: 'cors',
      method: 'PATCH',
      body: JSON.stringify({
        orderReferenceCode: this.state.orderId,
        paymentStatus: this.state.checked,
        paymentReference: 'tbc',
      }),
    })
      .then(response => response.text())
      .then(res => {
        const data = JSON.parse(res);

        if (data.Error || this.state.checked == 'failure') {
          this.setState({
            confirmationStatus: 'Error',
            confirmMsg: data.Error.message,
          });
        } else if (this.state.checked == 'success') {
          this.setState({
            confirmationStatus: 'Success',
            confirmMsg: '',
          });
        }
        //this.state.resData = data.Error.message; //{"Error":{"code":"104","message":"Invalid order reference code"}}
      })
      .catch(e => console.log(e));
  };
}

export default ConfirmPayment;
