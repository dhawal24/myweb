import React from 'react';
import { render } from 'react-testing-library';
import { IntlProvider } from 'react-intl';

import ConfirmPayment from '../index';
import { DEFAULT_LOCALE } from '../../../i18n';

describe('<ConfirmPayment />', () => {
  it.skip('Should render and match the snapshot', () => {
    const {
      container: { firstChild },
    } = render(
      <IntlProvider locale={DEFAULT_LOCALE}>
        <ConfirmPayment />
      </IntlProvider>,
    );
    expect(firstChild).toMatchSnapshot();
  });

  it('Expect to have additional unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
