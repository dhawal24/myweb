import { defineMessages } from 'react-intl';

const messages = defineMessages({
  header: {
    id: 'app.components.ConfirmPayment.header',
    defaultMessage: 'Confirm Customer Payment',
  },
  orderReference: {
    id: 'app.components.ConfirmPayment.orderReference',
    defaultMessage: 'Order Reference',
  },
  confirmPayment: {
    id: 'app.components.ConfirmPayment.confirmPayment',
    defaultMessage: 'Confirm Payment',
  },
  rejectPayment: {
    id: 'app.components.ConfirmPayment.rejectPayment',
    defaultMessage: 'Reject Payment',
  },
  paymentSuccess: {
    id: 'app.components.ConfirmPayment.paymentSuccess',
    defaultMessage: 'Order successfully confirmed',
  },
  paymentError: {
    id: 'app.components.ConfirmPayment.paymentError',
    defaultMessage: 'There was an error in confirming your order',
  },
});
export default messages;
