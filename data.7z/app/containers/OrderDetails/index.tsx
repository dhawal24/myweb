import React, { Component } from 'react';

import { ConnectedRouterProps } from 'connected-react-router';
import { FormattedMessage } from 'react-intl';
import { Box, Heading, Grid } from 'grommet';

import messages from './messages';
import Container from 'components/Container';
import Separator from 'components/Separator';
import { PersonalDetailsType, PersonalDetailsActions } from 'containers/PersonalDetails/types';
import { connect } from 'react-redux';
import { initialPersonalDetails } from 'containers/PersonalDetails/reducer';
import { initialProductDetails } from 'containers/ProductPage/reducer';
import { initialFulfillDetails } from 'containers/FulfillmentPage/reducer';
import { ProductDetailsType, ProductDetailsActions } from 'containers/ProductPage/types';
import { fulfillType, fulfillActions } from 'containers/FulfillmentPage/types';

interface Props extends ConnectedRouterProps, PersonalDetailsActions, PersonalDetailsType, ProductDetailsType, ProductDetailsActions, fulfillActions, fulfillType {
    personalDetails: PersonalDetailsType
    productDetails: ProductDetailsType
    fulfillDetails: fulfillType
}

interface State {
    isChecked: boolean
    personalDetails: PersonalDetailsType
    productDetails: ProductDetailsType
    fulfillDetails: fulfillType
}

// const mock = {
//     deliveryDate: "20.08.2019",
//     // paymentType: "Card",
//     // details: "xxxx xxxx xxxx xxxx 0005",
// }

class OrderDetails extends Component<Props, State> {
    public state: State = {
        isChecked: false,
        personalDetails: initialPersonalDetails,
        productDetails: initialProductDetails,
        fulfillDetails: initialFulfillDetails,
    }

    componentDidMount() {
        console.log(this.props.fulfillDetails);
        this.setState({ 
            personalDetails: this.props.personalDetails,
            productDetails: this.props.productDetails,
            fulfillDetails: this.props.fulfillDetails
         })
    }

    checked = () => this.setState(prevState => ({ isChecked: !prevState.isChecked }));

    private handleSubmit = () => {
    
        this.props.history.push('/order-success')
      };

    render() {
        const { isChecked, personalDetails, productDetails, fulfillDetails } = this.state;
        let convertedAmount = productDetails.amount && productDetails.exchangeRate && (productDetails.amount * productDetails.exchangeRate).toFixed(2)
        
        return (
            <Container width={800} borderWidth={1} margin={"0 auto"} padding={"30px"} logo>
                <Container borderWidth={1} padding={"0 20px 20px"}>
                    <Heading level="3">
                        <FormattedMessage {...messages.header} />
                    </Heading>
                    <Container borderWidth={1} padding={"20px"}>
                        <Heading level="4">
                            <FormattedMessage {...messages.yourBasket} />
                        </Heading>
                        <Grid
                            fill={true}
                            columns={['xsmall', 'flex', 'small']}
                            rows={['xxsmall', 'flex', 'xxsmall']}
                            areas={[
                                { name: 'currency', start: [0, 0], end: [1, 0] },
                                { name: 'amount', start: [2, 0], end: [3, 0] },
                                { name: 'toPay', start: [3, 0], end: [3, 0] },
                                { name: 'rate', start: [0, 1], end: [3, 1] },
                                { name: 'total', start: [0, 2], end: [3, 2] }
                            ]}>
                            <Box gridArea="currency">
                                <Box border={{ size: "small", side: "bottom", color: "black" }} pad={{ bottom: "xsmall" }}>
                                    <FormattedMessage {...messages.currency} />
                                </Box>
                                <Box pad={{ top: "xsmall" }}>{productDetails.currencyCode}</Box>
                            </Box>
                            <Box gridArea="amount">
                                <Box border={{ size: "small", side: "bottom", color: "black" }} pad={{ bottom: "xsmall" }}>
                                    <FormattedMessage {...messages.foreignAmount} />
                                </Box>
                                <Box pad={{ top: "xsmall" }}>{productDetails.amount} {productDetails.currencyCode}</Box>
                            </Box>
                            <Box gridArea="toPay">
                                <Box border={{ size: "small", side: "bottom", color: "black" }} pad={{ bottom: "xsmall" }}>
                                    <FormattedMessage {...messages.toPay} />
                                </Box>
                                <Box pad={{ top: "xsmall" }}>{convertedAmount} GBP</Box>
                            </Box>
                            <Box gridArea="rate">
                                <Box pad={{ vertical: "small" }} direction="row" style={{ fontWeight: "bold" }}>
                                    <FormattedMessage {...messages.rate} />:  {productDetails.exchangeRate}
                                </Box>
                            </Box>
                            <Box gridArea="total">
                                <Box direction="row" border={{ size: "small", side: "horizontal", color: "black" }} pad={{ vertical: "small" }} style={{ fontWeight: "bold" }} justify={"between"}>
                                    <FormattedMessage {...messages.total} />
                                    <Box>{convertedAmount} GBP</Box>
                                </Box>
                            </Box>
                        </Grid>
                        <Heading level="4">
                            <FormattedMessage {...messages.deliveryDetails} />
                        </Heading>
                        <Grid
                            fill={true}
                            columns={['small', 'flex', 'small']}
                            rows={['xxsmall', 'flex']}
                            areas={[
                                { name: 'deliveryDate', start: [0, 0], end: [1, 0] },
                                { name: 'deliveryDetails', start: [1, 0], end: [2, 0] },
                                { name: 'deliveryDetailsValue', start: [2, 0], end: [2, 0] }
                            ]}>
                            <Box gridArea="deliveryDate" direction="row">
                                <Box style={{ fontWeight: "bold" }} direction="row" pad={{ right: "xsmall" }}>
                                    <FormattedMessage {...messages.deliveryDate} />:
                                        </Box>
                                <Box> {fulfillDetails} </Box>
                            </Box>
                            <Box style={{ fontWeight: "bold" }} direction="row" gridArea="deliveryDetails" justify="end" pad={{ right: "xsmall" }}>
                                <FormattedMessage {...messages.deliveryDetails} />:
                            </Box>
                            <Box direction="row" gridArea="deliveryDetailsValue">
                                {personalDetails.address1}, {personalDetails.address2}, {personalDetails.city}, {personalDetails.county}, {personalDetails.postCode}
                            </Box>
                        </Grid>
                        <Grid fill={true}>
                            <Separator borderWidth={2}/>
                            <Heading level="4">
                                <FormattedMessage {...messages.personalDetails} />
                            </Heading>
                            <Box direction="row" pad={{ bottom: "small" }} >
                                <FormattedMessage {...messages.name} />
                                <Box pad={{ left: "medium", }}>{personalDetails.firstName} {personalDetails.lastName}</Box>
                            </Box>
                            <Box direction="row" pad={{ bottom: "small" }}>
                                <FormattedMessage {...messages.email} />
                                <Box pad={{ left: "medium" }}>{personalDetails.email}</Box>
                            </Box>
                            <Box direction="row" pad={{ bottom: "small" }}>
                                <FormattedMessage {...messages.mobileNumber} />
                                <Box pad={{ left: "small" }}>{personalDetails.mobileNumber}</Box>
                            </Box>
                        </Grid>
                        {/* <Grid fill={true}>
                            <Separator borderWidth={2}/>
                            <Heading level="4">
                                <FormattedMessage {...messages.paymentDetails} />
                            </Heading>
                            <Box direction="row" pad={{ bottom: "small" }}>
                                <FormattedMessage {...messages.paymentType} />:
                                    <Box pad={{ left: "xsmall", }}>{mock.paymentType}</Box>
                            </Box>
                            <Box direction="row" pad={{ bottom: "small" }}>
                                <FormattedMessage {...messages.details} />:
                                    <Box pad={{ left: "xsmall" }}>{mock.details}</Box>
                            </Box>
                        </Grid> */}
                    </Container>
                    <Box direction="row" pad={{ top: "small" }}>
                        <input type="checkbox" name="termsAndConditions" onClick={this.checked} />
                        <FormattedMessage {...messages.termsAndConditions} />
                    </Box>
                </Container>
                <Box direction="row" justify="end" margin={{ top: "medium" }}>
                    <button onClick={this.handleSubmit} type="button" disabled={isChecked ? false : true}>
                        Submit
                    </button>
                </Box>
            </Container>
        )
    }
};

const mapStateToProps = (state: any) => {
    return {
        personalDetails: state.personalDetails,
        productDetails: state.productReducer,
        fulfillDetails: state.fulfillReducer
    }
}

export default connect(mapStateToProps)(OrderDetails);
