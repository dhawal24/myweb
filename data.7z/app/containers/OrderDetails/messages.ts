import { defineMessages } from 'react-intl';

const messages = defineMessages({
    header: {
        id: 'app.containers.OrderDetails.header',
        defaultMessage: 'Review your order'
    },
    yourBasket: {
        id: 'app.containers.OrderDetails.yourBasket',
        defaultMessage: 'Your basket'
    },
    currency: {
        id: 'app.containers.OrderDetails.currency',
        defaultMessage: 'Currency'
    },
    foreignAmount: {
        id: 'app.containers.OrderDetails.foreignAmount',
        defaultMessage: 'Foreign amount'
    },
    toPay: {
        id: 'app.containers.OrderDetails.toPay',
        defaultMessage: 'To pay'
    },
    rate: {
        id: 'app.containers.OrderDetails.rate',
        defaultMessage: 'Rate'
    },
    total: {
        id: 'app.containers.OrderDetails.total',
        defaultMessage: 'Total'
    },
    deliveryDetails: {
        id: 'app.containers.OrderDetails.deliveryDetails',
        defaultMessage: 'Delivery address'
    },
    deliveryDate: {
        id: 'app.containers.OrderDetails.deliveryDate',
        defaultMessage: 'Delivery date'
    },
    personalDetails: {
        id: 'app.containers.OrderDetails.personalDetails',
        defaultMessage: 'Personal details'
    },
    name: {
        id: 'app.containers.OrderDetails.name', 
        defaultMessage: 'Name'
    },
    email: {
        id: 'app.containers.OrderDetails.email',
        defaultMessage: 'Email'
    },
    mobileNumber: {
        id: 'app.containers.OrderDetails.mobileNumber',
        defaultMessage: 'Mobile number'
    },
    paymentDetails: {
        id: 'app.containers.OrderDetails.paymentDetails',
        defaultMessage: 'Payment details'
    },
    paymentType: {
        id: 'app.containers.OrderDetails.paymentType',
        defaultMessage: 'Payment type'
    },
    details: {
        id: 'app.containers.OrderDetails.details',
        defaultMessage: 'Details'
    },
    termsAndConditions: {
        id: 'app.containers.OrderDetails.termsAndConditions',
        defaultMessage: 'I accept Terms and Conditions'
    }
});

export default messages;
