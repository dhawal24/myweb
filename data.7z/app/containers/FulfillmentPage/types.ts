export interface fulfillType {
    fulfillType: string
    fulfillDate: any
}

export interface SubmitActionType {
    type: string
    data: fulfillType
}

export interface fulfillActions {
    submitFulfillRequest: (data: fulfillType) => SubmitActionType
}