/**
 * Asynchronously loads the component for FulfillmentPage
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
