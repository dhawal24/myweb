
import { SET_FULFILLMENT_DATA } from './constants';
import { fulfillType, SubmitActionType } from './types';


export const submitFulfillRequest = (data: fulfillType): SubmitActionType => ({
  type: SET_FULFILLMENT_DATA,
  data
})
