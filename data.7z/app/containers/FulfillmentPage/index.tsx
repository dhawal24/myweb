import React, { ChangeEvent } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux'
import { FormattedMessage } from 'react-intl';
import { Box, Button, Calendar, Heading } from 'grommet';
import { Blank, Previous, Next } from 'grommet-icons';
import { addMonths, subMonths } from 'date-fns';
import { submitFulfillRequest } from './actions';
import { fulfillActions, fulfillType } from './types';
import messages from './messages';
import { ConnectedRouterProps } from 'connected-react-router';

interface Props extends ConnectedRouterProps, fulfillActions {
  fulfillType: string;
  fulfillDate: Date;
}

interface State extends fulfillType {
  fulfillType: string;
  fulfillDate: Date;
  setDate: null;
  date: '';
  firstReference: Date;
  secondReference: Date;
}

const now = new Date();
const next = new Date(now);
next.setMonth(now.getMonth() + 1, 1);

class FulfillmentPage extends React.Component<Props, State> {  

    public state:State = {
        fulfillType: 'Home Delivery',
        fulfillDate: new Date(),
        date: '',
        setDate: null,
        firstReference: now,
        secondReference: next,
    }
 

  private onSelect = (args: any) => {
    this.setState({
      date: args,
      setDate: args,
      fulfillDate:args 
    })
    //this.onSelectFulfillmentDateHandler(this.state.setDate);
  };

  private onSelectFulfillmentTypeHandler = (event: ChangeEvent<HTMLInputElement> ) => {
     this.setState({
       fulfillType:event.target.value
     })
  };

 
  private handleSubmit = () => {
    const { fulfillType, fulfillDate } = this.state

    this.props.submitFulfillRequest({
      fulfillType,
      fulfillDate
    })
    
    this.props.history.push('/personal-details');
  };

  render(){
  const { date, firstReference, secondReference } = this.state;
  return (
    <Box align="center" fill="vertical" justify="center">
      <Heading level="3">
        <FormattedMessage {...messages.title} />
      </Heading>
      <Box direction="row" gap="large">
        <Box direction="row">
          <input
            id="home"
            name="fulfillment"
            type="radio"
            onChange={this.onSelectFulfillmentTypeHandler}
            value="home"
            defaultChecked
          />{' '}
          <label htmlFor="home">
            <FormattedMessage {...messages.homeDeliveryLabel} />
          </label>
        </Box>       
      </Box>
      <Box justify="center" pad="large" direction="row" gap="small">
        <Calendar
          animate={false}
          showAdjacentDays={false}
          range={false}
          date={date}
          onSelect={this.onSelect}
          reference={firstReference.toISOString()}
          onReference={reference => {
            const referenceDate = new Date(reference);
            const nextDate = addMonths(new Date(referenceDate), 1);
            this.setState({
              firstReference: referenceDate,
              secondReference: nextDate
            });
          }}
          header={({
            date: currentDate,
            locale,
            onPreviousMonth,
            previousInBound,
          }) => (
            <Box direction="row" align="center" justify="between">
              <Button
                disabled={!previousInBound}
                icon={<Previous />}
                onClick={onPreviousMonth}
              />
              <Heading level={3} margin="none">
                {currentDate.toLocaleDateString(locale, {
                  month: 'long',
                  year: 'numeric',
                })}
              </Heading>
              <Blank />
            </Box>
          )}
        />
        <Calendar
          animate={false}
          showAdjacentDays={false}
          range={false}
          date={date}
          onSelect={this.onSelect}
          reference={secondReference.toISOString()}
          onReference={reference => {
            const referenceDate = new Date(reference);
            const previousDate = subMonths(new Date(referenceDate), 1);
            this.setState({
              firstReference: previousDate,
              secondReference: referenceDate
            });
          }}
          header={({ date: currentDate, locale, onNextMonth, nextInBound }) => (
            <Box direction="row" align="center" justify="between">
              <Blank />
              <Heading level={3} margin="none">
                {currentDate.toLocaleDateString(locale, {
                  month: 'long',
                  year: 'numeric',
                })}
              </Heading>
              <Button
                disabled={!nextInBound}
                icon={<Next />}
                onClick={onNextMonth}
              />
            </Box>
          )}
        />
      </Box>
      <Box>
        <button onClick={this.handleSubmit}>Next</button>
      </Box>
    </Box>
  );
  }
};



const mapStateToProps = (state: any) => {
  return {
    p: state.personalDetails
  }
}

const mapDispatchToProps = (dispatch: any) => bindActionCreators(
  { submitFulfillRequest }, dispatch
)

export default connect(mapStateToProps, mapDispatchToProps)(FulfillmentPage);