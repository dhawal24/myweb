import produce from 'immer';
import { SET_FULFILLMENT_DATA } from './constants';
import { fulfillType, SubmitActionType } from './types';


export const initialFulfillDetails: fulfillType = {
    fulfillType: '',
    fulfillDate: null,
};

const fulfillReducer = (state = initialFulfillDetails, action: SubmitActionType) =>
    produce(state, (draft: fulfillType) => {
        switch (action.type) {
            case SET_FULFILLMENT_DATA: {
                Object.keys(draft).map((fieldName) => draft[fieldName as keyof fulfillType] = action.data[fieldName as keyof fulfillType])
                break;
            }
        }
    });

export default fulfillReducer