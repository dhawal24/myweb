/*
 * ProductPage Messages
 *
 * This contains all the text for the ProductPage container.
 */
import { defineMessages } from 'react-intl';

const messages = defineMessages({
  title: {
    id: 'app.containers.OrderFailure.title',
    defaultMessage: 'Your order was unsuccessful'
  },
  subTitle: {
    id: 'app.containers.OrderFailure.subtitle',
    defaultMessage: 'Unfortunately we have been unable to complete your order'
  },
  code: {
    id: 'app.containers.OrderFailure.code',
    defaultMessage: 'Failure Code'
  }
});

export default messages;
