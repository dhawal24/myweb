
import React from 'react';
import { FormattedMessage } from 'react-intl';
import messages from './messages';
import Separator from '../../components/Separator';
import { Heading, Box, Paragraph } from 'grommet';
import Container from '../../components/Container';


export const OrderFailure: React.FC<{}> = () => (
    <Container borderWidth={1} padding="20px" logo>
        <Container borderWidth={1} padding="0 24px 16px">
            <Heading level="2" alignSelf="center">
                <FormattedMessage {...messages.title} />
            </Heading>
            <Separator />
            <Box direction="column" justify="center" width="medium" align="center">
                <Heading level="3" textAlign="center"><FormattedMessage {...messages.subTitle} />:</Heading>
                <Paragraph margin={{ top: '0', bottom: '32px' }}>
                    (<FormattedMessage {...messages.code} /> 101)
            </Paragraph>
            </Box>
        </Container>
    </Container>
)
export default OrderFailure