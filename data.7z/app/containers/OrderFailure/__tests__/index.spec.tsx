import React from 'react';
import { createRenderer } from 'react-test-renderer/shallow';

import { OrderFailure } from '../index';

const renderer = createRenderer();


describe('<OrderFailure />', () => {
    it('should render and match the snapshot', () => {
        renderer.render(<OrderFailure />);
        const renderedOutput = renderer.getRenderOutput();
        expect(renderedOutput).toMatchSnapshot();
    })
})