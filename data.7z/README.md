# tvx-oreo-ui

## Quick start

1.  Make sure that you have Node.js v10.16.0 and npm v6 or above installed
2.  Clone this repository using `git clone https://github.com/travelex/tvx-oreo-ui.git`
3.  Move to the appropriate directory: `cd tvx-oreo-ui`<br />
4.  Run `npm install` in order to install dependencies<br />
5.  Run `npm start` to see the app at `http://localhost:3000`
