interface Window {
  Intl: any;
  __REDUX_DEVTOOLS_EXTENSION_COMPOSE__: any;
}
