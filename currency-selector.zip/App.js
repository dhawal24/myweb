import React, { Component } from "react";
import "./App.css";
import CurrencySelect from "./utils/CurrencySelect";

class App extends Component {
  render() {
    return (
      <div className="App">
        <form>
          <label>Select Currency:</label> &nbsp;
          <CurrencySelect />
          <div className="clear" />
        </form>
      </div>
    );
  }
}

export default App;
