
text/x-generic pusave.php 
PHP script text
<?php
require_once("../functions.php");
Global $url;

/*error_reporting(E_ALL);
ini_set('display_errors',1);
ini_set('error_log','error.log');*/
error_reporting(0);
ini_set('display_errors', '0');

$program = "program";
@$universityid = $_REQUEST['university_id']; // university
$hash = uniqid();

// if we are the admin
if($_SESSION['is_admin'] != 1){
	header("location:".$url.$admin."/");
	die;
}

$result = array();


$valid_file = false;
set_time_limit(0);
//if they DID upload a file...
if($_FILES['photo']['name']) {
	$valid_file = true;
	//if no errors...
	if(!$_FILES['photo']['error']) {
		//now is the time to modify the future file name and validate the file
		$new_file_name = "program-".date('Y-m-d-H-i-s').".xls"; //rename file
		if($_FILES['photo']['size'] > (10485760 * 4)) //can't be larger than 2 MB
		{
			$valid_file = false;
			$message = 'Oops!  Your file\'s size is to large.';
		}
		
		if(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION) != 'xls') //Must be an xls file
		{
			$valid_file = false;
			$message = 'Oops!  Your file\'s extension is wrong. Please upload an xls file.';
		}
		
		//if the file has passed the test
		if($valid_file) {
			//move it to where we want it to be
			$file = '../import/program/'.$new_file_name;
			move_uploaded_file($_FILES['photo']['tmp_name'], $file);
			$message = 'Congratulations!  Your file was uploaded.<br />';
			
			$lsql = "SELECT * FROM level";
			$lqry = mysql_query($lsql);
			while($lrow = mysql_fetch_assoc($lqry)){
				$level[$lrow['id']] = strtolower($lrow['level_name']);
			}
			
			require_once('../Excel/reader.php');
			// ExcelFile($filename, $encoding);
			$data = new Spreadsheet_Excel_Reader();
			// Set output Encoding.
			$data->setOutputEncoding('CP1251');
			$data->read($file);
			
			$ignore = 0;
			$replace = 0;
			
			$usql = "SELECT country_id , university_id , name FROM university WHERE university_id = '".$universityid."'";
			$uqry = mysql_query($usql);
			$ucount = mysql_num_rows($uqry);
			$urow = mysql_fetch_assoc($uqry);
			
			if($ucount > 0){
				$x=2;
				$data->sheets[0]['numRows'];
				while($x<=$data->sheets[0]['numRows']) {
						$progId = isset($data->sheets[0]['cells'][$x][1]) ? $data->sheets[0]['cells'][$x][1] : '';
						$progName = isset($data->sheets[0]['cells'][$x][2]) ? $data->sheets[0]['cells'][$x][2] : '';
						$levelProg = isset($data->sheets[0]['cells'][$x][3]) ? $data->sheets[0]['cells'][$x][3] : '';
						$action = isset($data->sheets[0]['cells'][$x][4]) ? $data->sheets[0]['cells'][$x][4] : '';

						$leveQuery = "SELECT id from level where level_name = '$levelProg'";
						$levr =  mysql_query($leveQuery) or die('MySql Error' . mysql_error());
						$levrow = mysql_fetch_assoc($levr);
						//print_r($levrow);

						$r = array();
						for($i1=1;$i1<=45;$i1++){
							$r[$i1] = $data->sheets[0]['cells'][$x][$i1];
						}
						//print_r($r);
						$a1 = separate($r[2]);
						$a = $a1['tags'];
						//print_r($a1);
						$ignore = $ignore + $a1['ignore'];
						$replace = $replace + $a1['replace'];
						//var_dump($a);
						$systemtags = "";
						if($a) {
							foreach($a as $e){
								if($systemtags != '')
									$systemtags .= ";";
								$systemtags .= $e;
							}
						}
						if($progName!=""){
						if($action=="retain" || $action=="Retain"){
							
							$update = "UPDATE program SET program_name='$progName', level_id='{$levrow['id']}', system_tag='$systemtags'  WHERE program_id='$progId'";
							$result_insert = mysql_query($update) or die(mysql_error()); 
							$programid = $progId;
							if($a && $programid != '') {
								foreach($a as $index => $e){
									$fronttag = "";
									if (ctype_alpha($e[0])) {
										$fronttag = $e[0];
									}
									/*echo "<br><br>";
									print_r($e);
									echo "<br><br>";*/
									$sql = "INSERT INTO ".strtolower($fronttag)."_tag_map (`tag_map_id` , `program_map_id`) VALUES ('".$index."' , '".$programid."')";
									$qry = mysql_query($sql);
									// echo $sql."<br />";
								}
							}

						}elseif($action=="Add" || $action=="add"){

							$insert = "INSERT INTO program(program_name, level_id, status, university_id, country_id, system_tag)VALUES('$progName', '{$levrow['id']}', 'Active', '{$urow['university_id']}', '{$urow['country_id']}', '$systemtags')";
							$result_insert = mysql_query($insert) or die(mysql_error());

							$programid = mysql_insert_id();

							if($a && $programid != '') {
								foreach($a as $index => $e){
									$fronttag = "";
									if (ctype_alpha($e[0])) {
										$fronttag = $e[0];
									}
									
									$sql = "INSERT INTO ".strtolower($fronttag)."_tag_map (`tag_map_id` , `program_map_id`) VALUES ('".$index."' , '".$programid."')";
									$qry = mysql_query($sql);
									// echo $sql."<br />";
								}
							}


						}elseif($action=="Delete" || $action=="delete"){

							$delete = "delete from program WHERE program_id='$progId'";
							$result_insert = mysql_query($delete) or die(mysql_error()); 
						}
 }
						
					$x++;
				}
				//exit();
				header("location:".$url.$admin."/programbulk.php?type=form&all=".$universityid."&msg=".urlencode($message));
				die;
			} else {
				$err .= "<b>".$universityname."</b> - university name doesnot exists.<br />";
			}
		}
	}
	//if there is an error...
	else {
		//set that to be the returned message
		$message = 'Ooops!  Your upload triggered the following error:  '.$_FILES['photo']['error'];
	}
} else {
	$message = 'Oops! Please select a file to upload';
}

function wrapper($word){
	return addslashes(htmlentities($word,ENT_SUBSTITUTE,'UTF-8'));
}

function createImage($url){
	Global $folder;
	if($url != ''){
		$check = get_headers($url, 1);
		if(strpos($check[0],"200") !== false){
			if(strpos($check['Content-Type'],"image") !== false){
				$content = file_get_contents($url);
				//Store in the filesystem.
				$name = uniqid('image_');
				$explode = explode(".", $url);
				$filename = $folder."upload/images/program/".$name."-".time().".".$explode[count($explode)-1];
				$fp = fopen($_SERVER['DOCUMENT_ROOT'].$filename, "w");
				fwrite($fp, $content);
				fclose($fp);
				return $filename;
			} else {
				// file in not an image
				return "err3";
			}
		} else {
			// file does not exist
			return "err2";
		}
	} else {
		// url or program id not passed
		return "err1";
	}
}

echo "	<script>
			alert(\"".$message."\");
			window.top.location = '".$url.$admin."/programbulk.php?type=form&all=".$universityid."';
		</script>";
die;
// redirect back
header("location:".$url.$admin."/programbulk.php?type=form&all=".$universityid."&msg=".urlencode($message));
die;
echo $message;
echo $err;

?>