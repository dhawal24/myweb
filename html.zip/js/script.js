//animation effect(waypoint)
//paste this code under head tag or in a seperate js file.
 // Wait for window load
 jQuery(window).load(function() {
  // Animate loader off screen
  jQuery(".se-pre-con").fadeOut("slow");

  function onScrollInit( items, trigger ) {
    items.each( function() {
      var osElement = jQuery(this),
      osAnimationClass = osElement.attr('data-os-animation'),
      osAnimationDelay = osElement.attr('data-os-animation-delay');

      osElement.css({
        '-webkit-animation-delay':  osAnimationDelay,
        '-moz-animation-delay':     osAnimationDelay,
        'animation-delay':          osAnimationDelay
      });

      var osTrigger = ( trigger ) ? trigger : osElement;

      osTrigger.waypoint(function() {
        osElement.addClass('animated').addClass(osAnimationClass);
      },{
        triggerOnce: true,
        offset: '90%'
      });
    });
  }
  onScrollInit( jQuery('.os-animation') );
  onScrollInit( jQuery('.staggered-animation'), jQuery('.staggered-animation-container'));
});
 
 jQuery(window).scroll(function() {
 
  if (jQuery(this).scrollTop() > 1){  
    jQuery('header').addClass("sticky");
  }
  else{
    jQuery('header').removeClass("sticky");
  }
});