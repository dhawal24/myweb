function digitsOnly(el, error) { // validation numeric only

    el.keydown(function(ev) {

        var n = ev.which || ev.keyCode;

        if (ev.ctrlKey || ev.altKey ||
            $.inArray(n, [8, 9, 13, 46, 27, 110, 116, 190]) !== -1 || //backspace, tab, delete, esc, decimal, F5, enter, 
            (n >= 35 && n <= 40) //home, end, left, right, down, up
        ) {

            $(error).css("display", "none");

        } else if ((ev.shiftKey || (n < 48 || n > 57)) && (n < 96 || n > 105)) {

            ev.preventDefault();
            $(error).css("display", "block");

        } else {

            $(error).css("display", "none");
        }

    });

    el.on('change', function() {
        var value = el.val();

        if (value.match(/[^0-9]/g)) {
            value = value.replace(/[^0-9]/g, "");
            el.val(value);
        }

    });
}

function charactersOnly(el, error) { // validation characters only

    el.keydown(function(ev) {

        var n = ev.which || ev.keyCode;

        if (ev.ctrlKey || ev.altKey ||
            $.inArray(n, [8, 9, 13, 20, 32, 44, 45, 46, 27, 110, 116, 190]) !== -1 || //backspace, tab, delete, caplocks, space, hyphen, comma, esc, decimal, F5, enter, 
            (ev.which && n == 39) || // single quote
            (!ev.which && n >= 35 && n <= 40) || // arrow keys/home/end
            (n >= 65 && n <= 90) // capital alphabets     
        ) {

            $(error).css("display", "none");

        } else if ((n > 48 || n < 57) && (n > 96 || n < 105)) {

            ev.preventDefault();
            $(error).css("display", "block");

        } else {

            $(error).css("display", "none");
        }

    });


    el.on('change', function() {
        var value = el.val();

        if (value.match(/[^A-Za-z]+/g)) {
            value = value.replace(/[^A-Za-z]+/g, "");
            el.val(value);
        }

    });

}

function alphanumericOnly(el, error) { // validation alphanumeric only

    el.keydown(function (ev) {

        var n = ev.which || ev.keyCode;

        if (ev.ctrlKey || ev.altKey ||
        $.inArray(n, [8, 9, 13, 20, 32]) !== -1 || //backspace, tab, enter, caplocks, space
        (ev.which && n == 39) ||                // single quote
        (!ev.which && n >= 35 && n <= 40) ||    // arrow keys/home/end
        (n >= 65 && n <= 90) ||                 // capital alphabets 
        ((n >= 48 && n <= 57)) ||               //allow numbers
        (n >= 97 && n <= 122)){                  // small alphabets 
            return true;
        }

        if ((ev.shiftKey || (n < 48 || n > 57)) || (n == 107 || n == 111 || n == 106 || n == 109)) {
            ev.preventDefault();
            $(error).css("display", "block");
           
        }else{            
            $(error).css("display", "none");
        }
    });
    

}

function disableClipboard(input) {
    input.bind("cut copy paste onpaste", function (e) {
        e.preventDefault();
    });
}





$(function(){
    digitsOnly($("#phoneNumber"), (".phoneErorr"));
    alphanumericOnly($("#coName"), (".coErorr"));
    charactersOnly($("#fullName"), (".nameError"));
    disableClipboard($("#emailAdd"));
});

function formValidate(){
    
    if($("#phoneNumber").val().length <= 0 ){
        $(".phoneBlankErorr").css("display", "block");
        return false;
    }else{
        return true;    
    }

    
}