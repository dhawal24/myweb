<?php 
    $login = "active";
    $title = "Login | Share Holic";
    require_once("header.php");   


    if(isset($_REQUEST['btnLogin'])){

      $sessionid = session_id();
      $user = $_REQUEST['loginEmail']; 
      $password = $_REQUEST['loginPass'];

      $query = $connect->login("ohg_agent","ohg_agent_email  ","ohg_agent_password",$user,$password,"login");

      if($_SESSION['cust_id'] !=""){

       $_SESSION['m_username'] = $user;
       header("location:dashboard.php");  

       } else {
         header("location:login.php?param=0");
       }

   }  
?>
    <section class="whiteBg mt105">
        <div class="container">
            <h2 class="text-center animated fadeInDown">Login <span></span></h2>
            
            <div class="row">
                <div class="col-md-6 offset-md-3 col-lg-6 offset-lg-3 col-xs-12 col-sm-12">
                    <form method="POST" action="dashboard.html">
                       <!--Form without header-->
                        <div class="card">

                            <div class="card-body mx-4">

                                <!--Body-->
                                <div class="md-form">
                                    <input type="email" id="loginEmail" name="loginEmail" class="form-control" required>
                                    <label for="loginEmail">Your email</label>
                                </div>

                                <div class="md-form pb-3">
                                    <input type="password" id="loginPass" name="loginPass" class="form-control" required>
                                    <label for="loginPass">Your password</label>
                                    <p class="font-small blue-text d-flex justify-content-end">Forgot <a href="<?php echo DIR; ?>forgot-password" class="blue-text ml-1"> Password?</a></p>
                                </div>

                                <div class="text-center mb-3">
                                    <button type="submit" class="btn btn-orange btn-block btn-rounded" name="btnLogin" id="btnLogin">Sign in</button>
                                </div>
                               

                            </div>

                            <!--Footer-->
                            <div class="modal-footer mx-5 pt-3 mb-1">
                                <p class="font-small grey-text d-flex justify-content-end">Not a member? <a href="<?php echo DIR; ?>register" class="blue-text ml-1"> Sign Up</a></p>
                            </div>

                        </div>
                        <!--/Form without header-->
                </form>
                </div>
            </div>
        </div>
    </section>

    
   

    <section class="callAction">
        <div class="container">
            <div class="row">
                <div class="col-md-9 col-lg-9 col-xs-12 col-sm-12">
                    <h3>Choosing The Right Social PRESENCE For Your Business</h3>
                    <p>Partner with us No Obligations. Just Deliver High Social Presence</p>
                </div>
                <div class="col-md-3 col-lg-3 col-sm-12 col-xs-12">
                    <a href="register.html">Get Started</a>
                </div>
            </div>
        </div>
    </section>

<?php 
    require_once("footer.php");     
?>
</body>
</html>