<?php 
    $register = "active";
    $title = "Register | Share Holic";
    require_once("header.php");     
?>

   <section class="whiteBg mt105">
        <div class="container">
            <h2 class="text-center animated fadeInDown">Register <span></span></h2>
            
            <div class="row">
                <div class="col-md-6 offset-md-3 col-lg-6 offset-lg-3 col-xs-12 col-sm-12">
                    <form method="POST">
                       <!--Form without header-->
                        <div class="card">

                            <div class="card-body mx-4">

                                <!--Body-->
                                <div class="md-form">
                                    <input type="text" id="registerName" name="registerName" class="form-control" required>
                                    <label for="registerName">Your Name</label>
                                </div>

                                <div class="md-form">
                                    <input type="email" id="loginEmail" name="loginEmail" class="form-control" required>
                                    <label for="loginEmail">Your email</label>
                                </div>

                                <div class="md-form pb-3" style="margin:0; padding:0">
                                    <input type="password" id="loginPass" name="loginPass" class="form-control" required>
                                    <label for="loginPass">Your password</label>                                   
                                </div>

                                <div class="md-form pb-3">
                                    <label class="form-check-label">
                                        <input class="form-check-input" type="checkbox" value="">
                                        I agree to terms and conditions.
                                      </label>                                 
                                </div>
                                <br>
                                <div class="text-center mb-3" style="">
                                    <button type="submit" class="btn btn-orange btn-block btn-rounded">Sign Up</button>
                                </div>
                               

                            </div>

                            <!--Footer-->
                            <div class="modal-footer mx-5 pt-3 mb-1">
                                <p class="font-small grey-text d-flex justify-content-end">Back to <a href="<?php echo DIR; ?>login" class="blue-text ml-1"> Login</a></p>
                            </div>

                        </div>
                        <!--/Form without header-->
                </form>
                </div>
            </div>
        </div>
    </section>

    
   

    <section class="callAction">
        <div class="container">
            <div class="row">
                <div class="col-md-9 col-lg-9 col-xs-12 col-sm-12">
                    <h3>Choosing The Right Social PRESENCE For Your Business</h3>
                    <p>Partner with us No Obligations. Just Deliver High Social Presence</p>
                </div>
                <div class="col-md-3 col-lg-3 col-sm-12 col-xs-12">
                    <a href="register.html">Get Started</a>
                </div>
            </div>
        </div>
    </section>

<?php 
    require_once("footer.php");     
?>
</body>
</html>