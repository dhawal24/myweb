<?php

	date_default_timezone_set("Asia/Kolkata");
	
	define('DIR','http://localhost/Share-Holic/');	
	define('DIRADMIN','http://localhost/Share-Holic/web_admin/');	

	define('DBHOST','localhost');
	define('DBUSER','root');
	define('DBPASS','');
	define('DBNAME','exam_portal');	

	

	try {
		$conn = new PDO("mysql:host=".DBHOST.";dbname=".DBNAME, DBUSER, DBPASS);
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
	catch(PDOException $e)
    {
		echo "Connection failed: " . $e->getMessage();
    }

	include_once 'connect.php';
	$connect = new Connect($conn);

?>