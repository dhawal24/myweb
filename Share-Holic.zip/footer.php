    <footer>
        <div class="container text-center">
                <a href="<?php echo DIR; ?>home"> Home </a> | <a href="<?php echo DIR; ?>login">Login</a> | <a href="<?php echo DIR; ?>register"> Regsiter </a> | <a href="<?php echo DIR; ?>guidelines">Guidelines</a> | <a href="<?php echo DIR; ?>contact">Contact </a> <br>
                &copy; Copyright 2017 | Design By: <a href="http://www.madebydhawal.com" target="_blank" title="Web Designer in Mumbai">Made By Dhawal</a>
        </div>
    </footer>
    
    <!-- SCRIPTS -->
    <!-- JQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Tooltips -->
    <script type="text/javascript" src="<?php echo DIR; ?>js/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="<?php echo DIR; ?>js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="<?php echo DIR; ?>js/mdb.min.js"></script>   

    <script type="text/javascript" src="<?php echo DIR; ?>js/wow.js"></script>
    <script>
        wow = new WOW(
          {
            animateClass: 'animated',
            offset:       100,
            callback:     function(box) {
              console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
            }
          }
        );
    </script>
