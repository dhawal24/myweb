<?php 
    $home = "active";
    $title = "Share Holic";
    require_once("header.php");     
?>
    <section>
        <div class="banner">
            <div class="container text-center animated fadeInDown">
                <h1>Welcome to Shareaholic</h1>
                <h3>Network That Will Help You Grow Your Social Presence</h3>
                <a href="<?php echo DIR; ?>login">Login</a> <a href="<?php echo DIR; ?>register">Register</a>
            </div>
        </div>
    </section>

    <section class="whiteBg">
        <div class="container">
            <h6 class="text-center animated fadeInUp">About</h6>
            <h2 class="text-center animated fadeInDown">ShareaHolic <span></span></h2>
            <p class="text-center animated fadeInUp">We at <strong>ShareAHolic</strong> are a group of people dedicated of bringing more traffic at you social pages. We are building and making a system to make your social pages more popular. </p> 

            <p class="text-center animated fadeInUp">We allow you to look and choose who you want to like, subscribe, follow, view, circle, hit, share and skip those who you are not interested in.  We do not sell or make fake likes, subscribes, friends, followers, views, hits, circles and shares.</p>
        </div>
    </section>

    <section class="greyBg">
        <div class="container">
            <h6 class="text-center animated fadeInUp">Services at</h6>
            <h2 class="text-center animated fadeInDown">ShareaHolic <span></span></h2>
            <div class="row">
   
                <div class="col-lg-4 col-xs-12 col-sm-12 col-md-4 animated fadeInLeft">
                    <a href="">
                       <!--Card-->
                        <div class="card">

                            <!--Card image-->
                            <img class="img-fluid" src="<?php echo DIR; ?>images/fb-img.jpg" alt="Facebook Likes, Share &amp; Views" title="Facebook Likes, Share &amp; Views">

                            <!--Card content-->
                            <div class="card-body">
                                <!--Title-->
                                <h4 class="card-title">Get Free Likes</h4>
                                <!--Text-->
                                <p class="card-text">Get "Free Facebook Likes" on fast, simple and safe way now. Gather real "Facebook Likes", and users without bots.</p>
                                <a href="#" class="readMore">Read More..</a>
                            </div>

                        </div>
                        <!--/.Card-->
                        </a>
                    </div>
       
                <div class="col-lg-4 col-xs-12 col-sm-12 col-md-4 animated fadeInUp">
                    <a href="">
                       <!--Card-->
                        <div class="card">

                            <!--Card image-->
                            <img class="img-fluid" src="<?php echo DIR; ?>images/twitter-img.jpg" alt="Twitter Followers &amp; Views" title="Twitter Followers &amp; Views">

                            <!--Card content-->
                            <div class="card-body">
                                <!--Title-->
                                <h4 class="card-title">Get Free followers</h4>
                                <!--Text-->
                                <p class="card-text">To get the most out of your Twitter, you want to gain free followers, we provide followers which are not fake.</p>
                                <a href="#" class="readMore">Read More..</a>
                            </div>

                        </div>
                        <!--/.Card-->
                    </a>
                </div>
   
                <div class="col-lg-4 col-xs-12 col-sm-12 col-md-4 animated fadeInRight">
                    <a href="">
                       <!--Card-->
                        <div class="card">

                            <!--Card image-->
                            <img class="img-fluid" src="<?php echo DIR; ?>images/youtube-img.jpg" alt="Youtube Likes, Subscribe &amp; Views" title="Youtube Likes, Subscribe &amp; Views">

                            <!--Card content-->
                            <div class="card-body">
                                <!--Title-->
                                <h4 class="card-title">Get Free Youtube Views</h4>
                                <!--Text-->
                                <p class="card-text">The more videos you watch, the more users will watch your videos back! "I watch your Video - you watch mine".</p>
                                <a href="#" class="readMore">Read More..</a>
                            </div>

                        </div>
                        <!--/.Card-->
                    </a>
                </div>
                
              </div>
           
        </div>
    </section>

    <section class="whiteBg">
        <div class="container">
            <div class="row">
                <div class="col-md-5 col-lg-5 col-sm-12 col-xs-12">
                    <h6 class="text-left animated fadeInUp">Talk Close To Your Audience</h6>
                    <h4 class="text-left animated fadeInDown">Increase traffic, <br>strengthen your brand. <span></span></h4>
                    <p class="animated fadeInUp">ShareaHolic can help your company increase your brand awareness and build the relationships that will fill the top of your sales funnel. When you have a steady stream of qualified prospects engaged with your brand, your possibilities are limitless!</p>
                </div>
                <div class="col-md-7 col-md-7 col-xs-12 col-sm-12">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="blueBg text-center">
                                    <h2 class="text-right">1</h2>
                                    <img src="<?php echo DIR; ?>images/register-icon.jpg" class="img-fluid" alt="Register at Share Holic" title="Register at Share Holic">
                                    <h3>Register</h3>
                                    <p>Resigter with simple details</p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="blueBg text-center">
                                    <h2 class="text-right">2</h2>
                                    <img src="<?php echo DIR; ?>images/verify-icon.jpg" class="img-fluid" alt="Verfiy your registration at Share Holic" title="Verfiy your registration Share Holic">
                                    <h3>Verify</h3>
                                    <p>Once register, validate your email</p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="blueBg text-center">
                                    <h2 class="text-right">3</h2>
                                    <img src="<?php echo DIR; ?>images/login-icon.jpg" class="img-fluid" alt="Login at Share Holic" title="Login at Share Holic">
                                    <h3>Login</h3>
                                    <p>Login and start sharing, liking and more..</p>

                                </div>
                            </div>
                        <p class="smallTxt">We will never request for usernames or passwords of your social network accounts and will never post, tweet or update status from your accounts</p>
                        </div>
                </div>
            </div>
        </div>
    </section>

    <section class="callAction">
        <div class="container">
            <div class="row">
                <div class="col-md-9 col-lg-9 col-xs-12 col-sm-12">
                    <h3>Choosing The Right Social PRESENCE For Your Business</h3>
                    <p>Partner with us No Obligations. Just Deliver High Social Presence</p>
                </div>
                <div class="col-md-3 col-lg-3 col-sm-12 col-xs-12">
                    <a href="register.html">Get Started</a>
                </div>
            </div>
        </div>
    </section>

<?php 
    require_once("footer.php");     
?>
</body>
</html>