<?php
    ob_start();
    session_start();
    require_once 'web_admin/db.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags always come first -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php echo @$title; ?></title>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Bootstrap core CSS -->
    <link href="<?php echo DIR; ?>css/bootstrap.min.css" rel="stylesheet"> 
     <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,800" rel="stylesheet"> 
    <!-- Material Design Bootstrap -->
    <link href="<?php echo DIR; ?>css/mdb.min.css" rel="stylesheet">
    <link href="<?php echo DIR; ?>css/shareHolic.css" rel="stylesheet">
    <link href="<?php echo DIR; ?>css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo DIR; ?>css/animate.css">

</head>

<body>
    <header>
            <!--Navbar-->
        <nav class="navbar fixed-top navbar-expand-lg scrolling-navbar">
            <div class="container">
                <!-- Navbar brand -->
                <a class="navbar-brand" href="<?php echo DIR; ?>home"><img src="<?php echo DIR; ?>images/logo.png" alt="Share Holic" title="Share Holic" class="img-fluid"></a>

                <!-- Collapse button -->
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"><i class="fa fa-bars"></i></span></button>

                <!-- Collapsible content -->
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Links -->
                    <ul class="nav navbar-nav ml-auto">
                        <li class="nav-item <?php echo @$home; ?>"><a class="nav-link" href="<?php echo DIR; ?>home">Home</a></li>
                        <li class="nav-item <?php echo @$login; ?>"><a class="nav-link" href="<?php echo DIR; ?>login">Login</a></li>
                        <li class="nav-item <?php echo @$register; ?>"><a class="nav-link" href="<?php echo DIR; ?>register">Register</a></li>
                        <li class="nav-item <?php echo @$guidelines; ?>"><a class="nav-link" href="<?php echo DIR; ?>guidelines">Guidelines</a></li>
                        <li class="nav-item <?php echo @$contact; ?>"><a class="nav-link" href="<?php echo DIR; ?>contact">Contact</a></li>
                    </ul>
                    <!-- Links -->
                </div>
                <!-- Collapsible content -->
            </div>
        </nav>
        <!--/.Navbar-->
      
    </header>
