import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { User } from '../_models/index'

@Injectable()
export class UserService {

  users = [
    new User(1, 'user1', 'user1', 'John', 'Cena'),
    new User(2, 'user2', 'user2', 'Randy', 'Orton'),
    new User(3, 'user3', 'user3', 'Jeff', 'Hardy'),
    new User(4, 'user4', 'user4', 'Matt', 'Hardy'),
    new User(5, 'user5', 'user5', 'AJ', 'Styles')
  ];

  private isUserLoggedIn;
  private username;

  firstName: string;
  authenticatedUser: any = {};
  loading = false;

  constructor() {
  }

  onLogout() {
    localStorage.clear();
    //this.isUserLoggedIn = false;
  }


  login(usernameTxt: string, passwordTxt: string) {

    var data = this.users;
    var authenticatedUser = data.find(u => u.username === usernameTxt);

    if (authenticatedUser && authenticatedUser.password === passwordTxt) {

      this.firstName = authenticatedUser.firstName;
      localStorage.setItem('currentUser', this.firstName);
      return authenticatedUser;
      
    } else {
      return 'Invalid';
    }

  }


}

