import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from '../_service/user.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  loggedUser: string;
  isLoggedIn = false;

  constructor() {
    
  }

  ngOnInit() {
    this.loggedUser = localStorage.getItem('currentUser');
    
    if (localStorage.getItem('currentUser')) {
      
        this.isLoggedIn = true;
        
      } else {

        this.isLoggedIn = false;

      }

  }


}
