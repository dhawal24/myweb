import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from '../_service/user.service';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';


@Component({
  selector: 'login',
  //moduleId: module.id,
  templateUrl: './login.component.html',
})

export class LoginComponent implements OnInit {

  prmForm: FormGroup;
  usernameTxt: string;
  passwordTxt: string;
  loggedUser;
  loading = false;
  wrongLogin = false;

  constructor(private router: Router, private userData: UserService, private fb: FormBuilder) {
    this.createForm();
  }

  createForm() {
    this.prmForm = this.fb.group({
      'usernameTxt': [null, Validators.required],
      'passwordTxt': [null, Validators.required]
    })
  }

  ngOnInit() {
    this.loading = false;
    this.userData.onLogout();
    localStorage.removeItem('currentUser');

    this.createForm();

  }

  isFieldValid(field: string) {
    return !this.prmForm.get(field).valid && this.prmForm.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  login(form: FormGroup) {

    if (this.prmForm.valid) {

      this.loading = true;
      this.loggedUser = this.userData.login(form.value.usernameTxt, form.value.passwordTxt);
      console.log('form submitted ' + this.loggedUser);

      if (this.loggedUser == "Invalid") {
        this.loading = false;
        this.wrongLogin = true;
      } else {
        this.router.navigate(['./dashboard']);
      }

    } else {
      this.loading = false;
      this.validateAllFormFields(this.prmForm);
    }
  }

  validateAllFormFields(prmForm: FormGroup) {
    Object.keys(prmForm.controls).forEach(field => {
      console.log(field);
      const control = prmForm.get(field);

      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }

    });
  }


}
