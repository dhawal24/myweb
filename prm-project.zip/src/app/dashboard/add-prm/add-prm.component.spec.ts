import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddPrmComponent } from './add-prm.component';

describe('AddPrmComponent', () => {
  let component: AddPrmComponent;
  let fixture: ComponentFixture<AddPrmComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddPrmComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddPrmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
