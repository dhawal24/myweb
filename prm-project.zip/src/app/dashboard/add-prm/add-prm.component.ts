import { Component, OnInit } from '@angular/core';
import { UserService } from '../../_service/user.service';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'app-add-prm',
  templateUrl: './add-prm.component.html',
  styleUrls: ['./add-prm.component.css']
})
export class AddPRMComponent implements OnInit {

  loggedUser: string;
  addForm: FormGroup;

  constructor(private user: UserService, private fb: FormBuilder) {
    this.createForm();
   }

  ngOnInit() {
    this.loggedUser = localStorage.getItem('currentUser');
    this.createForm();
  }

  createForm() {
    this.addForm = this.fb.group({
      'fromUser': [{value: null, disabled: true}, Validators.required],
      'toUser': [null, Validators.required],
      'dateCurrent': [null, Validators.required],
      'costCenter': [null, Validators.required],
      'locationTxt': [null, Validators.required],
      'paymentMode': [null, Validators.required],
      'poNoTxt': [null, Validators.required],
      'accountHead': [null, Validators.required],
      'expensesTxt': [null, Validators.required],
      'billNoTxt': [null, Validators.required],
      'billDateTxt': [null, Validators.required],
      'billAmtTxt': [null, Validators.required],
      'apprAmtTxt': [null, Validators.required],
      'grossAmtTxt': [null, Validators.required],
      'remrksTxt': [null, Validators.required]
    })
  }

}
